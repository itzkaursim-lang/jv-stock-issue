/* JV Stock Issue – app logic */
'use strict';
const N = window.JVS || null;
const WEB_VERSION = '3.0';
const SLIP_RE = /^(?=.*\d).{2,10}$/;
const MON = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];

/* ================= storage ================= */
function blank() {
  return { v: 2, me: { name: '', emp: '', desig: '', storeName: 'Ration Store' }, mgr: { on: false, name: '', desig: '' },
    stores: {}, areas: [], stock: {}, stockAt: null, lines: [], entries: [], returns: [], hold: {}, nextId: 1,
    sync: { url: '', at: null, auto: true }, queue: false, lastLoginAt: null, lastUpdateCheck: 0, updateInfo: null };
}
function load() {
  try {
    const t = N ? N.storeGet() : localStorage.getItem('jvStockIssue');
    if (t) return Object.assign(blank(), JSON.parse(t));
  } catch (e) {}
  return blank();
}
let S = load();
let syncTimer = null;
function writeLocal() { DATAVER++; const t = JSON.stringify(S); try { if (N) N.storeSet(t); else localStorage.setItem('jvStockIssue', t); } catch (e) {} }
function normCodes() {
  const f = v => { const n = normRcv(v); return n || v; };
  (S.lines || []).forEach(l => { if (l.rcv) l.rcv = f(l.rcv); }); (S.entries || []).forEach(e => { if (e.rcv) e.rcv = f(e.rcv); }); (S.returns || []).forEach(r => { if (r.by) r.by = f(r.by); });
  Object.values(S.stores || {}).forEach(x => { if (x.rcv) x.rcv = f(x.rcv); }); Object.values(S.manReqs || {}).forEach(x => { if (x.rcv) x.rcv = f(x.rcv); });
}
let saveT = null;
function flushLocal() { if (!saveT) return; clearTimeout(saveT); saveT = null; try { normCodes(); } catch (e) {} writeLocal(); }
document.addEventListener('visibilitychange', () => { if (document.visibilityState === 'hidden') flushLocal(); });
window.addEventListener('pagehide', flushLocal); window.addEventListener('beforeunload', flushLocal);
function save(noSync) {
  if (!noSync && ui.pendUndo) undoFire();
  S.sync.dirty = true; S.sync.changedAt = new Date().toISOString();
  try { DATAVER++; } catch (e) {}
  clearTimeout(saveT); saveT = setTimeout(() => { saveT = null; try { normCodes(); } catch (e) {} writeLocal(); }, 400);
  if (!S.sync.firstDirty) S.sync.firstDirty = Date.now();
  paintSync();
}
let syncBusy = false, syncErr = '';
function syncLabel() {
  if (S.testMode) return ['offline', 'Test mode · backup paused'];
  if (!S.sync.url) return ['off', 'Cloud not set'];
  if (syncBusy) return ['busy', 'Syncing…'];
  if (!navigator.onLine) return ['offline', 'Offline · saved on phone'];
  if (S.sync.dirty || !S.sync.at) { const left = Math.max(0, Math.ceil(((S.sync.firstDirty || Date.now()) + (S.sync.delay != null ? S.sync.delay : 5) * 60000 - Date.now()) / 60000)); return [syncErr ? 'error' : 'pending', syncErr ? 'Will retry · saved on phone' : 'Saved on phone · upload in ' + (left ? left + ' min' : 'a moment')]; }
  return ['ok', 'Synced ' + (S.sync.at ? ago(S.sync.at) : '')];
}
function ago(ts) { const m = Math.round((Date.now() - new Date(ts)) / 60000); return m < 1 ? 'just now' : m < 60 ? m + ' min ago' : m < 1440 ? Math.round(m / 60) + ' h ago' : fmtDT(ts); }
function paintSync() { const el = document.getElementById('syncline'); if (!el) return; const [k, t] = syncLabel(); el.className = 'sync s-' + k; el.lastChild.textContent = t; }
window.addEventListener('online', () => { paintSync(); if (S.sync.dirty) syncNow(true); });
window.addEventListener('offline', paintSync);
function syncDue() { return S.sync.url && S.sync.auto && S.sync.dirty && navigator.onLine && !syncBusy && Date.now() - (S.sync.firstDirty || 0) >= (S.sync.delay != null ? S.sync.delay : 5) * 60000; }
setInterval(() => { paintSync(); if (syncDue()) syncNow(true); else if (S.sync.url && S.sync.auto && navigator.onLine && allPaper().some(x => !x.p.cloud)) syncPhotos(true); }, 20000);
document.addEventListener('visibilitychange', () => { if (document.hidden && S.sync.url && S.sync.auto && S.sync.dirty && navigator.onLine) syncNow(true); });
const nid = () => S.nextId++;

/* ================= utils ================= */
const esc = s => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const num = x => { const v = Math.round(Number(x) * 1000) / 1000; return isFinite(v) ? String(v) : ''; };
const pad = n => String(n).padStart(2, '0');
const isoOf = d => d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate());
const today = () => isoOf(new Date());
const timeNow = () => { const d = new Date(); return pad(d.getHours()) + ':' + pad(d.getMinutes()); };
const P = iso => { const [y, m, d] = String(iso).split('-').map(Number); return { y, m, d }; };
const fmtLong = iso => { const p = P(iso); return MON[p.m - 1] + ' ' + pad(p.d) + ', ' + p.y; };
const fmtShort = iso => { const p = P(iso); return p.d + ' ' + MON[p.m - 1]; };
const fmtDT = ts => { const d = new Date(ts); return d.getDate() + ' ' + MON[d.getMonth()] + ' ' + d.getFullYear() + ', ' + d.toLocaleTimeString('en-IN', { hour: 'numeric', minute: '2-digit' }); };
const days = iso => Math.round((new Date(today() + 'T00:00:00') - new Date(iso + 'T00:00:00')) / 864e5);
const remarkFor = iso => iso === today() ? '' : 'Requisition Requested on ' + fmtLong(iso);
const itemName = c => (S.stock[c] && S.stock[c].name) || (findItemAnywhere(c) || {}).name || 'Unknown item';
const itemUom = c => (S.stock[c] && S.stock[c].uom) || (findItemAnywhere(c) || {}).uom || '';
function findItemAnywhere(c) {
  for (const e of S.entries) for (const i of e.items) if (i.code === c && i.name) return i;
  for (const r of S.returns) for (const i of r.items) if (i.code === c && i.name) return i;
  return null;
}
function groupBy(a, f) { const m = {}; a.forEach(x => (m[f(x)] = m[f(x)] || []).push(x)); return m; }
/* Receiver / employee codes: 6 digits = GA code, 1–5 digits = E code. You may also type GA… or E… */
function normRcv(x) { const s = String(x == null ? '' : x).toUpperCase().replace(/[\s\-]+/g, ''); if (/^GA\d{6}$/.test(s)) return s.slice(2); if (/^\d{6}$/.test(s)) return s; if (/^E\d{1,5}$/.test(s)) return s; if (/^\d{1,5}$/.test(s)) return 'E' + s; return ''; }
function validRcv(x) { return !!normRcv(x); }
function rcvLabel(x) { const n = normRcv(x); if (!n) return String(x || ''); return /^E/.test(n) ? n : 'GA' + n; }
function rcvKind(x) { const n = normRcv(x); return !n ? '' : /^E/.test(n) ? 'E code' : 'GA code'; }
function toast(m, force) { if (!force && (ui.undoAt && Date.now() - ui.undoAt < 1500)) return; return toast0(m); }
function toast0(m) { const t = document.getElementById('toast'); t.textContent = m; t.style.display = 'block'; clearTimeout(toast.h); toast.h = setTimeout(() => t.style.display = 'none', 3200); }
function meTag() { return { name: S.me.name || '', emp: S.me.emp || '' }; }

/* ================= allocation =================
   Tier 1 = today's requests, Tier 2 = everything older (only leftover stock).
   In each tier: first complete as many whole requests as possible, then
   remaining lines (today: smaller first; older: oldest first). No partial lines. */
function plan() {
  const res = {}, avail = {};
  for (const c in S.stock) avail[c] = S.stock[c].qty;
  const t = today();
  const waiting = S.lines.filter(l => l.status === 'waiting' && !(l.date > t));
  S.lines.forEach(l => { if (l.status === 'waiting' && l.date > t) res[l.id] = 'later'; });
  [waiting.filter(l => l.date === t), waiting.filter(l => l.date !== t)].forEach((tier, ti) => {
    const byReq = groupBy(tier, l => l.req);
    const reqs = Object.values(byReq).sort((a, b) => ti === 0 ? (a.length - b.length || a[0].id - b[0].id) : (a[0].date.localeCompare(b[0].date) || a.length - b.length));
    tier.forEach(l => { if (S.hold[l.id]) res[l.id] = 'hold'; else if (!(l.code in avail)) res[l.id] = 'missing'; });
    for (const ls of reqs) {
      if (ls.some(l => res[l.id])) continue;
      const need = {}; ls.forEach(l => need[l.code] = (need[l.code] || 0) + l.qty);
      if (Object.keys(need).every(c => avail[c] + 1e-9 >= need[c])) ls.forEach(l => { res[l.id] = 'issue'; avail[l.code] -= l.qty; });
    }
    tier.filter(l => !res[l.id]).sort((a, b) => ti === 0 ? (a.qty - b.qty || a.id - b.id) : (a.date.localeCompare(b.date) || a.qty - b.qty || a.id - b.id))
      .forEach(l => { if (avail[l.code] + 1e-9 >= l.qty) { res[l.id] = 'issue'; avail[l.code] -= l.qty; } else res[l.id] = 'short'; });
  });
  return res;
}
const STATUS = { issue: ['Can issue', 'c-ok'], short: ['Not enough stock', 'c-pt'], missing: ['Not in stock sheet', 'c-gy'], hold: ['On hold', 'c-pt'], issued: ['Issued', 'c-in'] };
const chip = k => '<span class="chip ' + STATUS[k][1] + '">' + STATUS[k][0] + '</span>';
const ICONS = { x: '<path d="M6 6l12 12M18 6L6 18"/>', up: '<path d="M6 15l6-6 6 6"/>', down: '<path d="M6 9l6 6 6-6"/>', right: '<path d="M9 6l6 6-6 6"/>', lock: '<rect x="5" y="11" width="14" height="10" rx="2.5"/><path d="M8 11V7a4 4 0 0 1 8 0v4"/>', alert: '<circle cx="12" cy="12" r="9"/><path d="M12 8v5M12 16.5v.5"/>', ext: '<path d="M14 4h6v6M20 4l-9 9M18 14v5a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V7a1 1 0 0 1 1-1h5"/>' };
const ico = (n, sz) => '<svg viewBox="0 0 24 24" width="' + (sz || 20) + '" height="' + (sz || 20) + '" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' + ICONS[n] + '</svg>';
const meta = arr => '<div class="meta">' + arr.filter(Boolean).map(x => '<span>' + x + '</span>').join('<i></i>') + '</div>';
function unavail(lines, PL) {
  const c = { issue: 0, short: 0, missing: 0, hold: 0, later: 0 };
  lines.forEach(l => { const k = PL[l.id]; if (c[k] != null) c[k]++; });
  const out = [];
  if (c.issue) out.push('<span class="sc ok">' + c.issue + ' ready</span>');
  if (c.short) out.push('<span class="sc no">' + c.short + ' short</span>');
  if (c.missing) out.push('<span class="sc no">' + c.missing + ' not in stock</span>');
  if (c.hold) out.push('<span class="sc gd">' + c.hold + ' on hold</span>');
  if (c.later && !c.issue && !c.short && !c.missing) return '';
  return out.length ? '<div class="scrow">' + out.join('') + '</div>' : '';
}
const serFmt = v => { const s = String(v || ''); if (!s || s === '–') return '<span class="ser">–</span>'; return '<span class="ser">' + esc(s.slice(0, -2)) + '<b>' + esc(s.slice(-2)) + '</b></span>'; };
const pill = (txt, cls) => '<span class="chip ' + (cls || 'c-gy') + '">' + esc(txt) + '</span>';
function linePills(l, k) {
  const s = S.stock[l.code], u = itemUom(l.code), out = [];
  if (k === 'issued') { l.issued.forEach(x => out.push(pill('Slip ' + x.slip + (x.serial ? ' · #' + x.serial : ''), 'c-in'))); return out.join(' '); }
  if (k === 'issue') { out.push(pill('Can issue', 'c-ok')); if (s) out.push(pill(num(s.qty) + ' ' + u + ' in stock', 'c-gy')); }
  else if (k === 'short') { out.push(pill('Short', 'c-pt')); if (s) out.push(pill('Have ' + num(s.qty) + ' ' + u, 'c-gy')); }
  else if (k === 'missing') out.push(pill('Not in stock sheet', 'c-no'));
  else if (k === 'hold') out.push(pill('On hold', 'c-pt'));
  const d = days(l.date); if (d > 0) out.push(pill(d + (d === 1 ? ' day' : ' days') + ' old', d > 2 ? 'c-no' : 'c-pt'));
  if (l.date !== today() && k === 'issue') out.push(pill('Remark added', 'c-gy'));
  return out.join(' ');
}

function requests() {
  const by = groupBy(S.lines.filter(l => l.status !== 'dropped'), l => l.req);
  return Object.entries(by).map(([req, ls]) => ({ req, store: ls[0].store, date: ls[0].date, src: ls[0].src, lines: ls }));
}
function reqState(r, PL) {
  const w = r.lines.filter(l => l.status === 'waiting'), iss = r.lines.filter(l => l.status === 'issued');
  const can = w.filter(l => PL[l.id] === 'issue');
  let st = 'wait';
  if (!w.length) st = 'done'; else if (can.length === w.length) st = 'full'; else if (can.length) st = 'part';
  return { w, iss, can, st };
}
function isPending(l) {
  if (l.status !== 'waiting') return false;
  if (l.date > today()) return false;
  if (l.date !== today() || l.src === 'old') return true;
  return S.lines.some(x => x.req === l.req && x.status === 'issued');
}
function allSlips() { const s = new Set(); S.entries.forEach(e => s.add(String(e.slip).toUpperCase())); return s; }
function nextSlip() {
  const e = S.entries.filter(x => x.slip).slice().sort((a, b) => (b.at || '').localeCompare(a.at || ''))[0];
  const used = allSlips();
  let base = e ? e.slip : 'JV/1';
  let m = base.match(/^(.*?)(\d+)$/);
  if (!m) return '';
  let n = parseInt(m[2], 10);
  for (let i = 0; i < 500; i++) { n++; const s = m[1] + String(n).padStart(m[2].length, '0'); if (!used.has(s.toUpperCase()) && SLIP_RE.test(s)) return s; }
  return '';
}
function plannedSlip(ids) {
  const used = allSlips();
  const ls = S.lines.filter(l => ids.includes(l.id) && l.slip);
  for (const l of ls) if (!used.has(l.slip.toUpperCase())) return l.slip;
  return '';
}
function slipProblem(s) {
  if (!s) return 'Enter a Slip No.';
  if (!SLIP_RE.test(s)) return 'Slip No must be 2–10 characters with at least one digit.';
  const hit = S.entries.find(e => String(e.slip).toUpperCase() === s.toUpperCase());
  if (hit) return s + ' was already used on ' + fmtDT(hit.at) + ' for ' + hit.store + '.';
  return '';
}

/* ================= file parsing ================= */
function readWorkbook(file) {
  return new Promise((ok, bad) => {
    const fr = new FileReader();
    fr.onload = () => { try { ok(XLSX.read(new Uint8Array(fr.result), { type: 'array', cellDates: false, raw: true })); } catch (e) { bad(e); } };
    fr.onerror = bad; fr.readAsArrayBuffer(file);
  });
}
function rowsOf(ws) { return XLSX.utils.sheet_to_json(ws, { header: 1, raw: true, defval: '' }); }
function toISO(v) {
  if (typeof v === 'number' && v > 20000) { const d = new Date(Math.round((v - 25569) * 864e5)); return d.getUTCFullYear() + '-' + pad(d.getUTCMonth() + 1) + '-' + pad(d.getUTCDate()); }
  if (v instanceof Date) return isoOf(v);
  const s = String(v).trim(); if (!s) return null;
  let m = s.match(/^(\d{1,2})[\/\-.](\d{1,2})[\/\-.](\d{2,4})$/);
  if (m) { let y = +m[3]; if (y < 100) y += 2000; return y + '-' + pad(+m[2]) + '-' + pad(+m[1]); }
  m = s.match(/^(\d{4})-(\d{2})-(\d{2})/); if (m) return m[1] + '-' + m[2] + '-' + m[3];
  const d = new Date(s); return isNaN(d) ? null : isoOf(d);
}
function findSheet(wb, re) { const n = wb.SheetNames.find(x => re.test(x)); return n ? wb.Sheets[n] : null; }
function headerMap(rows, must) {
  for (let i = 0; i < Math.min(rows.length, 15); i++) {
    const hd = rows[i].map(c => String(c).trim().toLowerCase());
    if (must.every(re => hd.some(c => re.test(c)))) return { h: i, hd };
  }
  return null;
}
function parseRequests(wb, kind) {
  const isNew = kind !== 'old';
  const prefer = isNew ? /new.?request/i : /old.?pending/i;
  const avoid = isNew ? /read.?me|old.?pending/i : /read.?me|new.?request/i;
  const names = [...wb.SheetNames.filter(n => prefer.test(n)), ...wb.SheetNames.filter(n => !prefer.test(n) && !avoid.test(n))];
  let last = null;
  for (const n of names) {
    const r = parseReqSheet(wb.Sheets[n], kind, n);
    if (r.rows && r.rows.length) return r;
    if (!last || (r.info && !last.info)) last = r;
  }
  return last || { error: 'No sheet found in this file.' };
}
function parseReqSheet(ws, kind, sheetName) {
  const rows = rowsOf(ws);
  const hm = headerMap(rows, [/request|slip|req/, /store|mess|project|area/, /code/, /qty|quant/]);
  if (!hm) return { error: 'Sheet "' + sheetName + '": columns not found. Row 1 must have: Request No, Store, Request date, Item code, Qty.' };
  const col = re => hm.hd.findIndex(c => re.test(c));
  const reqI = col(/request/) >= 0 ? col(/request/) : col(/slip|req/);
  const slipI = hm.hd.findIndex((c, k) => k !== reqI && /slip/.test(c) && !/earlier/.test(c));
  const ci = { req: reqI, slip: slipI, store: col(/store|mess|project|area/), date: col(/date/), code: col(/item code|^code|code/), qty: col(/qty|quant/), rcv: col(/receiver/), earlier: col(/earlier/) };
  const have = new Set(S.lines.map(l => l.req.toUpperCase() + '|' + l.code));
  const out = [], dup = [], warn = new Set(), badQty = [], skipped = [], notes = [];
  let ex = 0, data = 0;
  const skip = (i, r, why, inApp) => skipped.push({ inApp, row: i + 1, req: String(r[ci.req] == null ? '' : r[ci.req]).trim(), store: String(r[ci.store] == null ? '' : r[ci.store]).trim(), code: String(r[ci.code] == null ? '' : r[ci.code]).trim().toUpperCase(), qty: String(r[ci.qty] == null ? '' : r[ci.qty]).trim(), why });
  for (let i = hm.h + 1; i < rows.length; i++) {
    const r = rows[i];
    const req = String(r[ci.req]).trim(), code = String(r[ci.code]).trim().toUpperCase(), qty = parseFloat(String(r[ci.qty]).replace(/[^\d.]/g, ''));
    if (!req && !code) continue;
    data++;
    if (/^EX[-\/]/i.test(req)) { ex++; skip(i, r, 'Example row (EX-…) from the template'); continue; }
    if (!req || !code) { skip(i, r, !req ? 'Request No is empty' : 'Item code is empty'); continue; }
    if (!(qty > 0)) { skip(i, r, String(r[ci.qty]).trim() === '' ? 'Qty is empty' : 'Qty is not a number above 0'); continue; }
    const key = req.toUpperCase() + '|' + code;
    if (have.has(key)) {
      const ex0 = S.lines.find(l => l.req.toUpperCase() + '|' + l.code === key);
      let inApp = null;
      if (ex0) { const fileStore = String(r[ci.store]).trim().toUpperCase(); const e = S.entries.find(e2 => e2.items.some(it => it.lineId === ex0.id));
        inApp = { req: ex0.req, store: ex0.store, date: ex0.date, qty: ex0.qty, status: ex0.status, slip: e ? e.slip : (ex0.issued[0] || {}).slip || '', serial: e ? e.serial : (ex0.issued[0] || {}).serial || '', made: ex0.fromFile ? 'file' : '', other: fileStore && fileStore !== ex0.store }; }
      skip(i, r, ex0 ? (inApp.other ? 'Request No already used in the app for a different store' : 'Already in the app (same Request No + item)') : 'Same Request No + item appears twice in this file', inApp); dup.push(req + ' ' + code); continue; }
    have.add(key);
    const store = String(r[ci.store]).trim().toUpperCase();
    if (!store) { skip(i, r, 'Store is empty'); continue; }
    const date = (ci.date >= 0 && toISO(r[ci.date])) || today();
    const rcv = ci.rcv >= 0 ? (normRcv(r[ci.rcv]) || String(r[ci.rcv]).trim()) : '';
    const nb = [];
    if (rcv && !validRcv(rcv)) nb.push('Receiver "' + r[ci.rcv] + '" is not a GA or E code, so the store default is used');
    if (Object.keys(S.stock).length && !S.stock[code]) nb.push('Item code is not in the current stock sheet');
    const slip = ci.slip >= 0 ? String(r[ci.slip]).trim().toUpperCase() : '';
    if (slip && !SLIP_RE.test(slip)) nb.push('Slip No ' + slip + ' is not valid, so it is left empty');
    if (ci.date >= 0 && String(r[ci.date]).trim() && !toISO(r[ci.date])) nb.push('Date "' + r[ci.date] + '" not understood, so today is used');
    nb.forEach(w => notes.push({ row: i + 1, req, store, code, qty: String(qty), why: w }));
    out.push({ req, store, date, code, qty, rcv: validRcv(rcv) ? normRcv(rcv) : '', slip: slip && SLIP_RE.test(slip) ? slip : '', src: kind, earlier: ci.earlier >= 0 ? String(r[ci.earlier]).trim() : '' });
  }
  const info = 'Read sheet "' + sheetName + '", headers on row ' + (hm.h + 1) + ', ' + data + ' filled rows' + (ex ? ', ' + ex + ' example rows (EX-…) skipped' : '') + '.';
  return { rows: out, dup, warn: [...warn], info, skipped, notes };
}
const nmKey = n => String(n || '').toUpperCase().replace(/[^A-Z0-9]+/g, ' ').trim();
function stockDiff(file, linkBy) {
  linkBy = linkBy || 'both';
  const cur = S.stock || {}, byName = {}, dupName = new Set();
  const exN = v => String(v.raw != null ? v.raw : (v.name == null ? '' : v.name));
  Object.entries(cur).forEach(([c, v]) => { const k = exN(v); if (!k) return; if (byName[k] && byName[k] !== c) dupName.add(k); byName[k] = c; });
  const fileNames = {}; Object.values(file).forEach(v => { const k = exN(v); fileNames[k] = (fileNames[k] || 0) + 1; });
  const D = { linkBy, code: [], name: [], up: [], down: [], same: [], fresh: [], gone: [], dupNames: [] }, used = new Set();
  Object.entries(file).forEach(([c, v]) => {
    let to = linkBy !== 'name' && cur[c] ? c : null, how = 'code';
    if (!to && linkBy !== 'code') { let k = exN(v); if (!byName[k] && byName[k.trim()] && cur[byName[k.trim()]].raw == null) k = k.trim();
      if (k && byName[k] && !used.has(byName[k]) && (linkBy === 'name' || !file[byName[k]])) { if (dupName.has(k) || fileNames[k] > 1) D.dupNames.push(k); else { to = byName[k]; how = linkBy === 'name' && byName[k] === c ? 'code' : 'name'; } } }
    if (!to) { D.fresh.push({ code: c, v }); return; }
    used.add(to); const o = cur[to], x = { code: to, fileCode: c, name: o.name, uom: o.uom, from: Number(o.qty) || 0, to: Number(v.qty) || 0, how };
    D[how].push(x); if (x.to > x.from + 1e-9) D.up.push(x); else if (x.to < x.from - 1e-9) D.down.push(x); else D.same.push(x);
  });
  Object.keys(cur).forEach(c => { if (!used.has(c)) D.gone.push({ code: c, v: cur[c] }); });
  return D;
}
function stockDiffHtml(u) {
  const D = u.diff, mode = u.stockMode || 'update', R = (ui.sdOpen = ui.sdOpen || {});
  const tile = (n, l, cls) => '<div class="tile ' + cls + '"><b>' + n.toLocaleString('en-IN') + '</b><span>' + l + '</span></div>';
  const list = (k, arr, fmt) => { if (!arr.length) return ''; const op = !!R[k]; return '<button class="leftbtn retl" data-a="sdTog" data-v="' + k + '" style="border-radius:16px"><span>' + (op ? 'Hide' : 'Show') + ' ' + fmt[0] + ' · ' + arr.length + '</span>' + ico(op ? 'up' : 'down', 18) + '</button>' + (op ? '<div class="card tblwrap"><table><tr>' + fmt[1] + '</tr>' + arr.slice(0, 300).map(fmt[2]).join('') + '</table>' + (arr.length > 300 ? '<div class="note pad">Showing 300 of ' + arr.length + '.</div>' : '') + '</div>' : ''); };
  const chg = x => '<tr><td class="mono">' + esc(x.code) + (x.how === 'name' ? '<div class="note">' + (/^#NOCODE/.test(x.fileCode) ? 'file: no code' : 'file: ' + esc(x.fileCode)) + '</div>' : '') + '</td><td>' + esc(x.name) + '</td><td>' + num(x.from) + '</td><td><b>' + num(x.to) + '</b></td><td style="color:' + (x.to > x.from ? '#0B5E3D' : x.to < x.from ? '#B4123B' : 'var(--mute)') + ';font-weight:700">' + (x.to === x.from ? '–' : (x.to > x.from ? '+' : '') + num(Math.round((x.to - x.from) * 1000) / 1000)) + '</td></tr>';
  const hd = '<th>Code</th><th>Item</th><th>Now</th><th>File</th><th>Change</th>';
  const newRow = x => '<tr><td class="mono">' + (/^#NOCODE/.test(x.code) ? '–' : esc(x.code)) + '</td><td>' + esc(x.v.name) + '</td><td><b>' + num(x.v.qty) + '</b> ' + esc(x.v.uom) + '</td></tr>';
  const nm = D.code.length + D.name.length;
  const lb = D.linkBy || 'both', NC = !!(u.result && u.result.noCode);
  let h = '<div class="card pad col" style="gap:10px"><b>Link items by</b><div class="seg">' + (NC ? [['name', 'Item name (exact)']] : [['code', 'Item code'], ['name', 'Item name'], ['both', 'Code, then name']]).map(([k, l]) => '<button data-a="sdLink" data-v="' + k + '" class="' + (lb === k ? 'on' : '') + '">' + l + '</button>').join('') + '</div>' +
    '<div class="note">' + (lb === 'code' ? 'Only rows with exactly the same item code are linked.' : lb === 'name' ? 'Only rows whose item name is exactly the same, letter by letter, including spaces, capitals and every character, are linked. Codes are ignored.' : 'Same item code first. If the code is not in the app, the item name must be exactly the same, letter by letter, including spaces and every character.') + '</div>' +
    ((D.dupNames || []).length ? '<div class="err" style="font-weight:500">' + [...new Set(D.dupNames)].length + ' names appear more than once, so they were not linked by name: ' + esc([...new Set(D.dupNames)].slice(0, 6).join(', ')) + ([...new Set(D.dupNames)].length > 6 ? '…' : '') + '</div>' : '') + '</div>';
  h += '<div class="card pad col" style="gap:10px"><b>How to use this report</b><div class="seg"><button data-a="sdMode" data-v="update" class="' + (mode === 'update' ? 'on' : '') + '">Update closing only</button>' + (NC ? '' : '<button data-a="sdMode" data-v="fresh" class="' + (mode === 'fresh' ? 'on' : '') + '">Totally fresh report</button>') + '</div>' +
    '<div class="note">' + (mode === 'update' ? 'Only the closing qty of matching items changes. Items not in this file stay exactly as they are. Names, units and your other items are kept.' : 'The whole stock list is replaced by this file. Items not in the file are removed from the stock list.') + '</div>' +
    (mode === 'update' && D.fresh.length && !NC ? '<label class="chk"><input type="checkbox" data-a="sdAddNew"' + (u.addNew ? ' checked' : '') + '> Also add the ' + D.fresh.length + ' new items from the file</label>' : '') + '</div>';
  h += '<div class="grid3">' + tile(nm, 'Matched', 't-in') + tile(D.up.length, 'Qty up', 't-ok') + tile(D.down.length, 'Qty down', 't-pt') + '</div>';
  h += '<div class="grid3">' + tile(D.same.length, 'No change', 't-in') + tile(D.fresh.length, 'New in file', 't-ok') + tile(D.gone.length, mode === 'fresh' ? 'Will be removed' : 'Not in file (kept)', 't-pt') + '</div>';
  h += '<div class="note">Linked by item code: <b>' + D.code.length + '</b> · by exact item name' + (lb === 'name' ? '' : ' (code differs)') + ': <b>' + D.name.length + '</b></div>';
  h += list('up', D.up, ['qty up', hd, chg]) + list('down', D.down, ['qty down', hd, chg]) + list('name', D.name, ['linked by name', hd, chg]) + list('fresh', D.fresh, ['new items in file', '<th>Code</th><th>Item</th><th>Qty</th>', newRow]) + list('gone', D.gone, [mode === 'fresh' ? 'items that will be removed' : 'items not in file (kept)', '<th>Code</th><th>Item</th><th>Qty now</th>', newRow]);
  return h;
}
function parseStock(wb) {
  const rows = rowsOf(wb.Sheets[wb.SheetNames[0]]);
  const hm = headerMap(rows, [/item code|^code$/, /closing|stock|qty|quantity/]);
  if (!hm) return { error: 'This is not the CUIMS Item Stock Statement (no "Item Code" and "Closing" columns).' };
  const f = re => hm.hd.findIndex(c => re.test(c));
  const ci = { code: f(/item code|^code$/), name: f(/name/), uom: f(/uom|unit/), qty: f(/closing/) >= 0 ? f(/closing/) : f(/stock|qty|quantity/) };
  const st = {}, skippedS = [];
  let withCode = 0, withName = 0; for (let i = hm.h + 1; i < rows.length; i++) { const r = rows[i]; if (String(r[ci.code] == null ? '' : r[ci.code]).includes('-')) withCode++; else if (ci.name >= 0 && String(r[ci.name] == null ? '' : r[ci.name]).trim() && !isNaN(parseFloat(r[ci.qty]))) withName++; }
  if (!withCode && withName) {
    let k = 0;
    for (let i = hm.h + 1; i < rows.length; i++) { const r = rows[i]; const nm = String(r[ci.name] == null ? '' : r[ci.name]), q = parseFloat(r[ci.qty]); if (!nm.trim() || isNaN(q)) continue;
      st['#NOCODE-' + (++k)] = { raw: nm, name: nm.trim(), uom: ci.uom >= 0 ? String(r[ci.uom]).trim().toUpperCase().replace(/^KGS$/, 'KG').replace(/^LT$/, 'LTR') : '', qty: q, row: i + 1 }; }
    return { stock: st, count: k, skipped: [], notes: [], noCode: true };
  }
  for (let i = hm.h + 1; i < rows.length; i++) {
    const r = rows[i]; const code = String(r[ci.code]).trim().toUpperCase(); const q = parseFloat(r[ci.qty]);
    if (!code.includes('-') || isNaN(q)) { if (code && code !== 'ITEM CODE' && !/total/i.test(code)) skippedS.push({ row: i + 1, code, qty: String(r[ci.qty] == null ? '' : r[ci.qty]), why: !code.includes('-') ? 'Not an item code' : 'Closing stock is not a number' }); continue; }
    st[code] = { raw: ci.name >= 0 ? String(r[ci.name] == null ? '' : r[ci.name]) : code, name: ci.name >= 0 ? String(r[ci.name]).trim() : code, uom: ci.uom >= 0 ? String(r[ci.uom]).trim().toUpperCase().replace(/^KGS$/, 'KG').replace(/^LT$/, 'LTR') : '', qty: q };
  }
  return { stock: st, count: Object.keys(st).length, skipped: skippedS, notes: [] };
}

/* ================= UI state ================= */
let ui = { picker: null, doneOpen: {}, lastReq: null, locked: true, setPage: null, openStore: {}, sort: { home: 'priority', pend: 'custom', reg: 'time' }, tab: 'home', view: null, req: null, store: null, sheet: null, reg: { type: 'issue', date: today(), items: false }, search: { q: '', type: 'all', from: '', to: '', store: '', open: null }, upload: null, form: null };

const ICON = {
  home: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 11l9-7 9 7"/><path d="M5 10v10h14V10"/></svg>',
  pend: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></svg>',
  reg: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><rect x="5" y="3" width="14" height="18" rx="2"/><path d="M9 8h6M9 12h6M9 16h4"/></svg>',
  find: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><circle cx="11" cy="11" r="6"/><path d="M20 20l-4.5-4.5"/></svg>',
  set: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.7 1.7 0 0 0 .3 1.8l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.7 1.7 0 0 0-1.8-.3 1.7 1.7 0 0 0-1 1.5V21a2 2 0 1 1-4 0v-.1a1.7 1.7 0 0 0-1.1-1.5 1.7 1.7 0 0 0-1.8.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.7 1.7 0 0 0 .3-1.8 1.7 1.7 0 0 0-1.5-1H3a2 2 0 1 1 0-4h.1a1.7 1.7 0 0 0 1.5-1.1 1.7 1.7 0 0 0-.3-1.8l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.7 1.7 0 0 0 1.8.3H9a1.7 1.7 0 0 0 1-1.5V3a2 2 0 1 1 4 0v.1a1.7 1.7 0 0 0 1 1.5 1.7 1.7 0 0 0 1.8-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.7 1.7 0 0 0-.3 1.8V9a1.7 1.7 0 0 0 1.5 1H21a2 2 0 1 1 0 4h-.1a1.7 1.7 0 0 0-1.5 1z"/></svg>'
};
const TABS = [['home', 'Home'], ['pend', 'Pending'], ['find', 'Search'], ['reg', 'Registers'], ['set', 'Settings']];

function slipRow(e, req) {
  const man = e.kind === 'manual', cu = e.kind === 'cuims';
  if (cu) return '<button class="slipline tap cu" data-a="editEntry" data-v="' + e.id + '"><span class="stag cu">CUIMS</span><span class="sl">' + esc(e.slip) + '</span>' + serFmt(e.serial) + '<span class="st">' + esc(fmtShort(entryDate(e))) + ' · ' + esc(entryTime(e)) + ' · ' + entryCount(e, req) + ' art.' + ((e.by || {}).name ? ' · ' + esc(e.by.name.split(' ')[0]) : '') + '</span></button>';
  return '<button class="slipline tap ' + (man ? 'man' : 'app') + '" data-a="editEntry" data-v="' + e.id + '"><span class="stag">' + (man ? '<svg viewBox="0 0 24 24" width="13" height="13" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"><path d="M4 20h4L19 9l-4-4L4 16z"/></svg>Manual' : '<svg viewBox="0 0 24 24" width="13" height="13" fill="currentColor"><path d="M13 2L4 14h7l-1 8 9-12h-7z"/></svg>App') + '</span><span class="sl">' + esc(e.slip) + '</span>' + serFmt(e.serial) +
    '<span class="st">' + esc(fmtShort(entryDate(e))) + ' · ' + esc(entryTime(e)) + ' · ' + entryCount(e, req) + ' art.' + ((e.by || {}).name ? ' · ' + esc(e.by.name.split(' ')[0]) : '') + '</span></button>';
}
function rqCard(o) {
  const key = 'rq:' + o.where + ':' + o.req, open = !!(ui.rqOpen || {})[key];
  let h = '<div class="card rcard' + (o.cont ? ' contcard' : '') + (ui.lastReq === o.req ? ' sel' : '') + '"><div class="scard"><' + (o.tap === false ? 'div' : 'button data-a="' + (o.tapA || 'openReq') + '" data-v="' + esc(o.tapV != null ? o.tapV : o.req) + '"') + ' class="main"><div class="row"><span class="reqno" data-req="' + esc(o.req) + '">' + esc(o.req) + '</span>' + (o.status ? pill(o.status[0], o.status[1]) : '') + '</div>' +
    '<b class="ttl">' + esc(o.store) + '</b>' + meta(o.meta || []) + (o.chips || '') + '</' + (o.tap === false ? 'div' : 'button') + '>' +
    (o.x ? '<div class="side"><button class="xbtn" data-a="' + o.x + '" data-v="' + esc(o.req) + '" aria-label="Remove">' + ico('x', 18) + '</button></div>' : '') + '</div>';
  if (o.slips) h += '<div class="slips">' + (o.slips.length ? o.slips.map(e => slipRow(e, o.req)).join('') : '<div class="slipline none">No slip entered yet</div>') + '</div>';
  if (o.btns) h += '<div class="rqbtns">' + o.btns + '</div>';
  if (o.left && o.left.length) {
    const lw = o.leftWord || 'pending article', lws = o.leftWords || (lw + 's');
    h += '<button class="leftbtn' + (o.leftCls ? ' ' + o.leftCls : '') + '" data-a="rqTog" data-v="' + esc(key) + '"><span>' + (open ? 'Hide' : 'Show') + ' ' + o.left.length + ' ' + (o.left.length > 1 ? lws : lw) + '</span>' + ico(open ? 'up' : 'down', 18) + '</button>';
    if (open) h += '<div class="leftbox' + (o.leftCls ? ' ' + o.leftCls : '') + '">' + o.left.map(l => '<div class="leftrow"><span><b>' + esc(itemName(l.code)) + '</b><span class="mono">' + esc(l.code) + '</span></span><b class="qty">' + num(l.qty) + ' ' + esc(itemUom(l.code)) + '</b></div>').join('') + '</div>';
  }
  if (o.cta) h += '<div class="cta">' + o.cta + '</div>';
  return h + '</div>';
}
function entryHasReq(e, req) { return e.items.some(i => i.req === req) || (!!e.reqs && String(e.reqs).split(/\s*,\s*/).includes(req)); }
function entryCount(e, req) { if (!e.items.length) return Number(e.count) || 0; if (!req) return e.items.length; const n = e.items.filter(i => i.req === req).length; return n || (e.items.some(i => i.req) ? 0 : e.items.length); }
function reqSlips(req, onlyDate) { return S.entries.filter(e => entryHasReq(e, req) && (!onlyDate || entryDate(e) === onlyDate)).sort((a, b) => (a.at || '').localeCompare(b.at || '')); }
function reqCard(r, cont) {
  const PL = plan(), later = r.date > today();
  const tag = later ? ['Scheduled · ' + fmtShort(r.date), 'c-in'] : r.st === 'full' ? ['Ready', 'c-ok'] : r.st === 'part' ? [r.can.length + ' of ' + r.w.length + ' ready', 'c-gd'] : r.st === 'done' ? ['Done', 'c-in'] : ['Waiting', 'c-no'];
  const slip = (r.w.find(l => l.slip) || {}).slip, rcv = (r.lines.find(l => l.rcv) || {}).rcv || (S.stores[r.store] || {}).rcv || '';
  const sl = reqSlips(r.req);
  return rqCard({ where: 'home', req: r.req, store: r.store, status: tag, cont, x: 'dropReq',
    meta: [fmtShort(r.date), slip ? 'next slip ' + esc(slip) : '<em>No slip</em>', rcv ? esc(rcvLabel(rcv)) : '<em>No receiver</em>', r.lines.length + ' articles', paperList(r.req).length ? '<span class="pbadge">paper ' + paperList(r.req).length + '</span>' : ''], chips: unavail(r.w, PL),
    slips: sl.length ? sl : null, cta: later && isBaseKitchen(r.store) ? (advLines(r).length ? '<button class="btn adv full" data-a="advIssue" data-v="' + esc(r.req) + '">Issue on CUIMS now · ' + advLines(r).length + ' in stock</button>' : '<div class="note" style="text-align:center">Nothing in stock yet for this advance request.</div>') : later ? '<div class="note" style="text-align:center">Fills from ' + fmtLong(r.date) + '. No stock is kept for it before then.</div>' : (r.can && r.can.length ? '<button class="btn main full" data-a="fillReq" data-v="' + esc(r.req) + '">Fill on CUIMS · ' + r.can.length + ' available</button>' : '') });
}
function appBar() {
  const lk = '<svg viewBox="0 0 24 24" width="21" height="21" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"><rect x="5" y="11" width="14" height="10" rx="2.5"/><path d="' + (ui.locked ? 'M8 11V7a4 4 0 0 1 8 0v4' : 'M8 11V7a4 4 0 0 1 7.5-1.8') + '"/></svg>';
  const d = new Date();
  return '<div class="appbar">' +
    '<button class="avbtn" data-a="goProfile" aria-label="Profile">' + avatar(false) + '</button>' +
    '<div class="t"><b>' + (S.me.name ? 'Hello, ' + esc(S.me.name.split(' ')[0]) : 'JV Stock Issue') + '</b><span>Today ' + d.getDate() + ' ' + d.toLocaleString('en-GB', { month: 'short' }) + '.</span><button id="syncline" class="sync" data-a="syncTap"><span class="sd"></span><span></span></button></div>' +
    '<button class="cbtn' + (ui.locked ? '' : ' open') + '" data-a="lockTap" aria-label="' + (ui.locked ? 'Unlock editing' : 'Lock editing') + '">' + lk + '</button>' +
    '<button class="cbtn" data-a="drawer" aria-label="Open menu"><svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"><path d="M4 7h16M4 12h16M4 17h10"/></svg></button></div>';
}
function stockAge() { return S.stockAt ? 'Stock from ' + fmtDT(S.stockAt) : 'No stock uploaded yet'; }
function stockCard() {
  const box = '<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 8l-9-5-9 5 9 5 9-5z"/><path d="M3 8v8l9 5 9-5V8"/><path d="M12 13v8"/></svg>';
  if (!S.stockAt) return '<div class="stockcard warn"><button class="scmain" data-a="stockOpen"><span class="sci">' + box + '</span><span class="sct"><b>No stock yet</b><span>Fetch live stock from CUIMS to plan issues</span></span></button><button class="scgo" data-a="openMgr">Get stock</button></div>';
  const mins = Math.round((Date.now() - new Date(S.stockAt)) / 60000), old = mins > 360;
  const check = '<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12.5l4.5 4.5L19 7.5"/></svg>';
  const clock = '<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></svg>';
  const when = new Date(S.stockAt), tm = when.toLocaleTimeString('en-IN', { hour: 'numeric', minute: '2-digit' }), sameDay = isoOf(when) === today();
  return '<div class="stockcard ' + (old ? 'warn' : 'fresh') + '"><button class="scmain" data-a="stockOpen"><span class="sci">' + (old ? clock : check) + '</span><span class="sct"><b>' + (old ? 'Stock needs an update' : 'Stock is up to date') + '</b>' +
    '<span class="l1">Updated ' + esc(ago(S.stockAt)) + (mins >= 1 ? ' · ' + (sameDay ? tm : fmtShort(isoOf(when)) + ', ' + tm) : '') + '</span>' +
    '<span class="l2">' + Object.keys(S.stock).length.toLocaleString('en-IN') + ' items · ' + (S.stockSrc === 'auto' ? 'from CUIMS' : 'from a file') + '</span></span></button><button class="scgo" data-a="openMgr">' + (old ? 'Update' : 'Refresh') + '</button></div>';
}

/* ---------------- Home ---------------- */
function dayRange(d) {
  const E = S.entries.filter(e => entryDate(e) === (d || today())).slice().sort((a, b) => (a.at || '').localeCompare(b.at || ''));
  if (!E.length) return null;
  const reqs = [...new Set(E.flatMap(e => e.items.map(i => i.req)).filter(Boolean))].sort((a, b) => String(a).localeCompare(String(b), undefined, { numeric: true }));
  const sers = E.map(e => e.serial).filter(Boolean);
  return { slip: [E[0].slip, E[E.length - 1].slip], ser: sers.length ? [sers[0], sers[sers.length - 1]] : null, req: [reqs[0], reqs[reqs.length - 1]], n: E.length };
}
function vHome() {
  const PL = plan();
  const t = ui.homeDate || today(), isToday = t === today();
  const R = requests();
  const dayReqs = R.filter(r => r.date === t).map(r => Object.assign(r, reqState(r, PL)));
  const todays = dayReqs.filter(r => r.st !== 'done' && (r.src !== 'old' || !isToday));
  sortBy(todays, getSort('home'), r => ({ req: r.req, store: r.store, date: r.date, ready: r.can.length, size: r.lines.length }));
  const dayWait = dayReqs.flatMap(r => r.lines.filter(l => l.status === 'waiting'));
  const readyNow = dayWait.filter(l => PL[l.id] === 'issue').length;
  const dayEntries = S.entries.filter(e => entryDate(e) === t);
  const pend = S.lines.filter(isPending);
  const pendCan = pend.filter(l => PL[l.id] === 'issue').length;
  const issuedToday = dayEntries.length;
  const rg = dayRange(t);
  const dl = fmtShort(t);
  let h = '<main style="padding-top:6px">';
  h += '<section class="hero"><img class="hlogo" src="icon.png" alt="">' +
    '<div class="hcopy"><div class="hkick">' + (isToday ? 'Today' : dl) + '</div><div class="htitle">Daily<br>issue work</div>' +
    '<div class="hsub">' + (dayReqs.length ? todays.length + ' of ' + dayReqs.length + ' requests still open' : 'No requests on ' + dl) + '</div></div>' +
    '<div class="hstat"><div><b>' + todays.length + '</b><span>open requests</span></div><div><b>' + readyNow + '</b><span>ready to issue</span></div><div><b>' + dayWait.length + '</b><span>articles left</span></div><div><b>' + issuedToday + '</b><span>slips done</span></div></div>' +
    (rg ? '<div class="hrange"><div><span>Slips</span><b>' + esc(rg.slip[0]) + (rg.n > 1 ? '<i>to</i>' + esc(rg.slip[1]) : '') + '</b></div><div><span>Serials</span><b>' + (rg.ser ? esc(rg.ser[0]) + (rg.ser[1] !== rg.ser[0] ? '<i>to</i>' + esc(rg.ser[1]) : '') : '–') + '</b></div><div><span>Requests</span><b>' + esc(rg.req[0] || '–') + (rg.req[1] && rg.req[1] !== rg.req[0] ? '<i>to</i>' + esc(rg.req[1]) : '') + '</b></div></div>' : '<div class="hrange empty">No slips entered on ' + dl + ' yet.</div>') +
    '<div class="hcredit">JV Stock Issue · Built by ' + esc(S.me.builder || S.me.name || 'JV') + '</div></section>';
  const base = new Date(t + 'T12:00');
  h += '<div class="dstrip">';
  for (let k = -3; k <= 3; k++) { const dd = new Date(base); dd.setDate(base.getDate() + k); const iso = isoOf(dd); const has = R.some(r => r.date === iso && r.lines.some(l => l.status === 'waiting'));
    h += '<button class="dday' + (iso === t ? ' on' : '') + (iso === today() ? ' today' : '') + '" data-a="homeDate" data-v="' + iso + '"><i' + (has ? ' class="dot"' : '') + '></i><span>' + dd.toLocaleString('en-GB', { weekday: 'short' }) + '</span><b>' + dd.getDate() + '</b></button>'; }
  h += '</div>';
  h += stockCard();
  { const RQ = dayReqs, withP = RQ.filter(r => paperList(r.req).length), photos = RQ.reduce((n, r) => n + paperList(r.req).length, 0);
    if (RQ.length) h += '<button class="papercard" data-a="paperDay" data-v="' + t + '"><span class="pcic">' + '<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="5" width="18" height="15" rx="3"/><circle cx="12" cy="12.5" r="3.5"/><path d="M8 5l1.5-2h5L16 5"/></svg></span>' +
      '<span class="pct"><b>Paper photos · ' + withP.length + ' of ' + RQ.length + ' requests</b><span>' + photos + ' photo' + (photos === 1 ? '' : 's') + ' · ' + (RQ.length - withP.length ? (RQ.length - withP.length) + ' without a photo' : 'all requests covered') + '</span><span class="pcbar"><i style="width:' + Math.round(withP.length / RQ.length * 100) + '%"></i></span></span>' + ico('right', 18) + '</button>'; }
  if (!isToday) h += '<button class="banner tap" data-a="homeDate" data-v="' + today() + '" style="border:0;background:var(--lavBg);color:var(--lavInk)"><b>Showing ' + fmtLong(t) + '.</b> Tap to go back to today.</button>';
  if (S.updateInfo && S.updateInfo.newer) h += '<button class="banner t-in tap" data-a="goUpdate" style="border:0"><b>Update ' + esc(S.updateInfo.tag) + ' available.</b> Tap to install.</button>';
  if (!S.me.name) h += '<button class="banner t-pt tap" data-a="goProfile" style="border:0"><b>Add your name and emp code</b> so entries and PDFs show who made them.</button>';
  if (!S.lines.length && !S.stockAt) {
    return h + '<div class="card pad col"><h2>Start here</h2><div class="note">Upload the CUIMS stock report and your requests sheet.</div><button class="btn main" data-a="upload">Upload a file</button><button class="btn" data-a="template">Download data template</button></div></main>';
  }
  const qi = (a, label, d) => '<button class="qc" data-a="' + a + '" aria-label="' + label + '"><svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">' + d + '</svg></button>';
  const oldest = pend.reduce((m, l) => Math.max(m, days(l.date)), 0);
  h += '<div class="shead"><div><h2>Your work</h2></div></div><div class="plan">' +
    '<button class="pt orange" data-a="tab" data-v="pend"><span class="ptag">' + (oldest > 2 ? 'Urgent' : 'All days') + '</span><b>Pending</b><span class="pbig">' + pend.length + '</span><span>articles waiting</span><span>' + pendCan + ' can be issued now</span>' + (oldest ? '<span>oldest ' + oldest + (oldest === 1 ? ' day' : ' days') + '</span>' : '') + '<span class="pfoot">Open Pending</span></button>' +
    '<button class="pt blue" data-a="doneOpenDay" data-v="' + t + '"><span class="ptag">' + (isToday ? 'Today' : dl) + '</span><b>Done</b><span class="pbig">' + issuedToday + '</span><span>slips entered</span></button>' +
    '<div class="pt pink">' + qi('upload', 'Upload', '<path d="M12 21V9M7 14l5-5 5 5M4 3h16"/>') + qi('newReq', 'Add request', '<path d="M12 5v14M5 12h14"/>') + qi('batchReq', 'Batch add', '<rect x="3" y="3" width="18" height="18" rx="2"/><path d="M3 9h18M9 3v18"/>') + '</div></div>';
  h += '<div class="grid2"><button class="btn main" data-a="openSite">Issue CUIMS</button><button class="btn lav" data-a="openMgr">' + (autoStockCfg().on ? 'Update live stock' : 'Live stock') + '</button></div>';
  h += zwHomeCard();
  const ex = expiryRows().filter(r => r.left <= expDays());
  if (ex.length) { const e0 = ex.filter(r => r.left < 0).length; h += '<button class="alertcard" data-a="expOpen"><span class="ai">' + ico('alert', 22) + '</span><span style="flex:1;min-width:0"><b>Expiry Tracker</b><span>' + ex.length + ' batches within ' + expDays() + ' days' + (e0 ? ' · ' + e0 + ' expired' : '') + '</span></span>' + ico('right', 18) + '</button>'; }
  h += tasksCard();
  h += '<div class="shead"><div><h2>' + (t === today() ? 'Today\'s requests' : 'Requests of ' + fmtShort(t)) + '</h2><span>' + todays.length + ' open</span></div>' + sortPick('home') + '</div>';
  if (dayWait.length) h += '<button class="stockcard lite" data-a="artsOpenDay" data-v="' + t + '"><span class="sci">' + ico('right', 18).replace('M9 6l6 6-6 6', 'M8 6h13M8 12h13M8 18h13M3 6h.01M3 12h.01M3 18h.01') + '</span><span class="sct"><b>Pending articles of ' + (t === today() ? 'today' : fmtShort(t)) + '</b><span>' + dayWait.length + ' articles · ' + new Set(dayWait.map(l => l.code)).size + ' items · item-wise list</span></span>' + ico('right', 18) + '</button>';
  if (todays.length) {
    const fresh = todays.filter(r => !r.iss.length), cont = todays.filter(r => r.iss.length);
    if (fresh.length) { h += '<div class="sgroup"><span class="sdot new"></span><b>New on CUIMS</b><span>' + fresh.length + ' never entered yet</span></div>'; fresh.forEach(r => { h += reqCard(r); }); }
    if (cont.length) { h += '<div class="sgroup"><span class="sdot cont"></span><b>Continue</b><span>' + cont.length + ' entered once, articles left</span></div>'; cont.forEach(r => { h += reqCard(r, true); }); }
  } else h += '<div class="card pad note">No open requests for today. Upload today\'s requests, add one, or check Pending.</div>';
  h += '<button class="card pad tap row" data-a="tab" data-v="pend"><span><b class="ttl" style="font-size:16.5px">Older pending</b>' + meta([pend.length + ' articles waiting', pendCan + ' in stock now']) + '</span>' + ico('right', 18) + '</button>';
  const te = dayEntries.slice().reverse().slice(0, 5);
  if (te.length) {
    h += '<div class="shead"><div><h2>Done ' + (isToday ? 'today' : 'on ' + dl) + '</h2><span>Latest ' + te.length + '</span></div><button class="btn sm ghost" data-a="doneOpen">Done list</button></div><div class="card" style="overflow:hidden">';
    te.forEach(e => { const rq = [...new Set(e.items.map(i => i.req).filter(Boolean))].join(', ');
      h += '<div class="line' + (rq.split(', ').includes(ui.lastReq) ? ' selrow' : '') + '"><div class="row"><span class="reqno" data-req="' + esc(rq.split(', ')[0]) + '">' + esc(rq || '–') + '</span>' + serFmt(e.serial) + '</div>' + meta([esc(e.store), 'Slip ' + esc(e.slip), e.items.length + ' items', esc(entryTime(e))]) + '</div>'; });
    h += '</div>';
  }
  h += '<button class="btn" data-a="bulkEdit">Edit all requests</button>';
  return h + '</main>';
}

/* ---------------- Request detail ---------------- */
const PAPER_MEM = {};
function paperList(req) { return ((S.paper || {})[req] || []); }
function paperDeadline(date) { const d = new Date(date + 'T12:00'); d.setDate(d.getDate() + 1); return isoOf(d); }
function paperOpen(date) { return today() <= paperDeadline(date); }
function paperSrc(id) { if (PAPER_MEM[id]) return PAPER_MEM[id]; if (N && N.paperGet) { const b = N.paperGet(id); if (b) return (PAPER_MEM[id] = 'data:image/jpeg;base64,' + b); } return (S.paperImg || {})[id] || ''; }
function allPaper() { const out = []; Object.entries(S.paper || {}).forEach(([req, P]) => P.forEach(p => out.push({ req, p }))); return out; }
let photoBusy = false;
async function syncPhotos(quiet) {
  if (!S.sync.url || S.testMode || photoBusy || !navigator.onLine) return;
  const todo = allPaper().filter(x => !x.p.cloud); if (!todo.length) return;
  photoBusy = true; let n = 0;
  try {
    for (const { req, p } of todo.slice(0, 8)) {
      const src = paperSrc(p.id); if (!src) continue;
      const r = (requests().find(x => x.req === req) || {});
      const res = await apiPost({ action: 'photo', id: p.id, req, store: r.store || '', date: r.date || '', at: p.at, by: p.by || '', b64: src.split(',')[1] });
      if (res.fileId) { p.cloud = res.fileId; n++; writeLocal(); }
    }
    if (!quiet && n) toast(n + ' paper photo' + (n > 1 ? 's' : '') + ' backed up.');
  } catch (e) { if (!quiet) toast('Photo backup failed: ' + e.message + '. It will retry by itself.'); }
  photoBusy = false;
  if (todo.length > 8 && n) setTimeout(() => syncPhotos(true), 1500);
}
async function loadCloudPhoto(p) {
  if (!p.cloud || !S.sync.url) return '';
  try { const j = await apiGet('action=photo&fileId=' + encodeURIComponent(p.cloud)); if (j.b64) { if (N && N.paperSave) N.paperSave(p.id, j.b64); PAPER_MEM[p.id] = 'data:image/jpeg;base64,' + j.b64; return PAPER_MEM[p.id]; } } catch (e) {}
  return '';
}
function paperCard(r) {
  const P = paperList(r.req), can = paperOpen(r.date), dl = paperDeadline(r.date);
  let h = '<div class="card pad col" style="gap:12px"><div class="row"><span><b class="ttl" style="font-size:17px">Paper request</b><div class="meta"><span>' + (P.length ? P.length + ' photo' + (P.length > 1 ? 's' : '') : 'No photo yet') + '</span><i></i><span>' + (can ? 'can add until ' + fmtShort(dl) : 'closed on ' + fmtShort(dl)) + '</span></div></span>' + (can ? '<button class="btn sm main" data-a="paperAdd" data-v="' + esc(r.req) + '">+ Photo</button>' : pill('Locked', 'c-gy')) + '</div>';
  if (P.length) h += '<div class="pgrid">' + P.map((p, i) => { const src = paperSrc(p.id); return '<button class="pthumb" data-a="paperView" data-v="' + esc(r.req) + '|' + i + '">' + (src ? '<img src="' + src + '" alt="Paper photo ' + (i + 1) + '" loading="lazy">' : '<i class="pcloud">' + (p.cloud ? 'In cloud · tap to load' : 'Not on this phone') + '</i>') + '<span>' + esc(fmtDT(p.at)) + (p.cloud ? ' · backed up' : '') + '</span></button>'; }).join('') + '</div>';
  else h += '<div class="note">' + (can ? 'Optional. Take a photo of the paper request so it stays with this Request No.' : 'Photos can only be added on the request date or the next day.') + '</div>';
  return h + '</div>';
}
function openPaperViewer(req, i) {
  const P = paperList(req); if (!P[i]) return;
  let el = document.getElementById('pview'); if (!el) { el = document.createElement('div'); el.id = 'pview'; document.body.appendChild(el); }
  const r = requests().find(x => x.req === req) || {}, can = r.date && paperOpen(r.date);
  el.innerHTML = '<div class="pvbg"></div><div class="pvbox"><div class="pvbar"><span><b>' + esc(req) + ' · ' + esc(r.store || '') + '</b><span>Photo ' + (i + 1) + ' of ' + P.length + ' · ' + esc(fmtDT(P[i].at)) + (P[i].by ? ' · ' + esc(P[i].by) : '') + '</span></span><button class="xbtn" data-pv="close" aria-label="Close">' + ico('x', 18) + '</button></div>' +
    '<div class="pvimg"><img src="' + paperSrc(P[i].id) + '" alt="Paper request"></div>' +
    '<div class="pvnav"><button class="btn sm" data-pv="prev"' + (i ? '' : ' disabled') + '>Previous</button>' + (can ? '<button class="btn sm danger-t" data-pv="del">Delete</button>' : '') + '<button class="btn sm" data-pv="next"' + (i < P.length - 1 ? '' : ' disabled') + '>Next</button></div></div>';
  el.querySelectorAll('[data-pv]').forEach(b => b.onclick = async e => { e.stopPropagation(); const k = b.dataset.pv;
    if (k === 'close') el.innerHTML = ''; else if (k === 'prev') openPaperViewer(req, i - 1); else if (k === 'next') openPaperViewer(req, i + 1);
    else if (k === 'del') { if (!(await uiConfirm('Delete this paper photo?', 'Delete', true))) return; const p = P[i]; S.paper[req] = P.filter((x, j) => j !== i); if (N && N.paperDel) N.paperDel(p.id); if (p.cloud && S.sync.url) apiPost({ action: 'photoDel', fileId: p.cloud }).catch(() => {}); delete PAPER_MEM[p.id]; if (S.paperImg) delete S.paperImg[p.id]; save(); el.innerHTML = ''; render(); } });
  let z = 1;
  { let sx = 0; const box = el.querySelector('.pvimg'); box.addEventListener('touchstart', e => { sx = e.touches[0].clientX; }, { passive: true }); box.addEventListener('touchend', e => { const dx = e.changedTouches[0].clientX - sx; if (Math.abs(dx) > 70 && z === 1) { if (dx < 0 && i < P.length - 1) openPaperViewer(req, i + 1); else if (dx > 0 && i > 0) openPaperViewer(req, i - 1); } }, { passive: true }); }
  const img = el.querySelector('.pvimg img'); img.onclick = () => { z = z === 1 ? 2.2 : 1; img.style.transform = 'scale(' + z + ')'; };
}
function reqNeighbours() {
  const L = (ui.reqList || []).filter(q => requests().some(r => r.req === q)), i = L.indexOf(ui.req);
  if (i < 0) return null;
  const info = q => { const r = requests().find(x => x.req === q); return r ? { req: q, store: r.store } : null; };
  return { i, n: L.length, prev: i > 0 ? info(L[i - 1]) : null, next: i < L.length - 1 ? info(L[i + 1]) : null };
}
function goReq(dir) {
  const nb = reqNeighbours(); if (!nb) return;
  const t = dir > 0 ? nb.next : nb.prev; if (!t) { const a = document.getElementById('app'); if (a && a.animate) a.animate([{ transform: 'translateX(0)' }, { transform: 'translateX(' + (dir > 0 ? -18 : 18) + 'px)' }, { transform: 'translateX(0)' }], { duration: 260 }); return; }
  ui.req = t.req; ui.lastReq = t.req; render(); window.scrollTo(0, 0);
  const m = document.querySelector('#app main'); if (m && m.animate) m.animate([{ opacity: 0.2, transform: 'translateX(' + (dir > 0 ? 60 : -60) + 'px)' }, { opacity: 1, transform: 'none' }], { duration: 260, easing: 'cubic-bezier(.2,.8,.2,1)' });
}
function reqNavBar() {
  const nb = reqNeighbours(); if (!nb) return '';
  const side = (o, d) => o ? '<button class="rnav ' + (d < 0 ? 'l' : 'r') + '" data-a="reqGo" data-v="' + d + '">' + (d < 0 ? ico('up', 16).replace('M6 15l6-6 6 6', 'M15 6l-6 6 6 6') : '') + '<span><b>' + esc(o.req) + '</b><small>' + esc(o.store) + '</small></span>' + (d > 0 ? ico('right', 16) : '') + '</button>' : '<span class="rnav none"></span>';
  return '<div class="rnavbar">' + side(nb.prev, -1) + '<span class="rpos">' + (nb.i + 1) + ' / ' + nb.n + '<small>swipe</small></span>' + side(nb.next, 1) + '</div>';
}
(function swipe() {
  let x0 = 0, y0 = 0, t0 = 0, on = false;
  document.addEventListener('touchstart', e => { if (ui.view !== 'req' || ui.sheet || ui.picker || e.touches.length !== 1 || e.target.closest('input,textarea,.tblwrap,.pgrid')) { on = false; return; } on = true; x0 = e.touches[0].clientX; y0 = e.touches[0].clientY; t0 = Date.now(); }, { passive: true });
  document.addEventListener('touchmove', e => { if (!on) return; const dx = e.touches[0].clientX - x0, dy = e.touches[0].clientY - y0; const m = document.querySelector('#app main'); if (m && Math.abs(dx) > Math.abs(dy) && Math.abs(dx) > 10) m.style.transform = 'translateX(' + Math.max(-90, Math.min(90, dx * 0.5)) + 'px)'; }, { passive: true });
  document.addEventListener('touchend', e => { if (!on) return; on = false; const m = document.querySelector('#app main'); if (m) m.style.transform = '';
    const t = e.changedTouches[0], dx = t.clientX - x0, dy = t.clientY - y0;
    if (Math.abs(dx) > 70 && Math.abs(dy) < 60 && Date.now() - t0 < 800) goReq(dx < 0 ? 1 : -1); }, { passive: true });
})();
function vReq() {
  const PL = plan();
  const r = requests().find(x => x.req === ui.req);
  if (!r) { ui.view = null; return vHome(); }
  const st = reqState(r, PL);
  const rcv = (r.lines.find(l => l.rcv) || {}).rcv || (S.stores[r.store] || {}).rcv || '';
  let h = reqNavBar() + '<header class="top"><div><button class="btn sm ghost" data-a="back">‹ Back</button><h1 style="margin-top:8px">' + esc(r.store) + '</h1><div class="sub">Request ' + esc(r.req) + ' · ' + fmtLong(r.date) + ' · Receiver ' + (rcv ? esc(rcvLabel(rcv)) : 'not set') + '</div></div></header><main>';
  h += meta([st.can.length + ' ready', (st.w.length - st.can.length) + ' waiting', st.iss.length + ' issued', (st.w.find(l => l.slip) || {}).slip ? 'next slip ' + esc(st.w.find(l => l.slip).slip) : '<em>no slip set</em>']);
  if (r.lines.some(l => l.status === 'waiting')) h += '<button class="btn full" data-a="lkOpen" data-v="' + r.date + '">Already issued on CUIMS? Link serials</button>';
  if (isBaseKitchen(r.store) && r.date > today()) { const A = advLines(r); h += '<div class="advbox"><b>' + esc(r.store) + ' · advance request for ' + fmtLong(r.date) + '</b><span>Only you can issue this early, by tapping below. It uses any stock in hand (' + A.length + ' of ' + r.lines.filter(l => l.status === 'waiting').length + ' articles available). It is never picked by queue or auto submit.</span><button class="btn adv full" data-a="advIssue" data-v="' + esc(r.req) + '"' + (A.length ? '' : ' disabled') + '>Issue on CUIMS now</button></div>'; }
  h += '<div class="grid2"><button class="btn ret" data-a="verReq" data-v="' + esc(r.req) + '">Verify on CUIMS</button>' + ((S.verified || {})[r.req] ? '<button class="btn" data-a="vrOpen" data-v="' + esc(S.verified[r.req].rep) + '">' + (S.verified[r.req].issues ? S.verified[r.req].issues + ' to check' : 'Verified ✓') + '</button>' : '<span></span>') + '</div>';
  h += paperCard(r);
  h += '<div class="card">';
  const ordr = { issue: 0, short: 1, hold: 2, missing: 3 };
  const lines = r.lines.slice().sort((a, b) => (a.status === 'issued') - (b.status === 'issued') || (ordr[PL[a.id]] || 0) - (ordr[PL[b.id]] || 0));
  lines.forEach(l => {
    const k = l.status === 'issued' ? 'issued' : PL[l.id];
    const st = S.stock[l.code], u = itemUom(l.code);
    const status = k === 'issued' ? pill('Issued', 'c-in') : k === 'later' ? pill('Scheduled', 'c-in') : k === 'issue' ? pill('Ready', 'c-ok') : k === 'short' ? pill('Short', 'c-no') : k === 'missing' ? pill('Not in stock', 'c-no') : pill('On hold', 'c-gd');
    const info = k === 'issued' ? l.issued.map(x => 'Slip ' + esc(x.slip) + (x.serial ? ' · Serial ' + esc(x.serial) : '')) : [esc(l.code), st ? 'stock ' + num(st.qty) + ' ' + esc(u) : '', k === 'short' && st ? '<em>' + (st.qty >= l.qty ? 'kept for higher priority' : 'short by ' + num(l.qty - st.qty)) + '</em>' : '', remarkFor(l.date) && k === 'issue' ? 'remark added' : ''];
    h += '<div class="line"><div class="row"><b>' + esc(itemName(l.code)) + '</b><span class="qty">' + num(l.qty) + ' ' + esc(u) + '</span></div><div class="row" style="align-items:center">' + meta(info) + status + '</div>' +
      (l.status === 'waiting' && k !== 'missing' ? '<label class="chk" style="min-height:34px;font-size:14px;color:var(--mute)"><input type="checkbox" data-a="hold" data-v="' + l.id + '"' + (S.hold[l.id] ? ' checked' : '') + '> Hold this article</label>' : '') + '</div>';
  });
  h += '</div>';
  h += '<button class="btn main full" data-a="fillReq" data-v="' + esc(r.req) + '"' + (st.can.length ? '' : ' disabled') + '>Fill on CUIMS · ' + st.can.length + ' articles</button>';
  h += '<div class="note" style="text-align:center">Articles not issued stay pending with this request\'s date.</div>';
  h += '<button class="btn full" data-a="corrOpen" data-v="' + esc(r.req) + '">Correct quantities after issue</button>';
  h += '<button class="btn ghost full" data-a="markDone" data-v="' + esc(r.req) + '"' + (st.w.length ? '' : ' disabled') + '>Already submitted on CUIMS? Mark as issued</button>';
  h += '<div class="grid2"><button class="btn ghost sm" data-a="editReq" data-v="' + esc(r.req) + '">Edit request</button><button class="btn ghost sm" data-a="dropReq" data-v="' + esc(r.req) + '">Remove waiting articles</button></div>';
  return h + '</main>';
}

/* ---------------- Pending ---------------- */
function fltGet(k) {
  ui.flt = ui.flt || {};
  if (!ui.flt[k]) ui.flt[k] = k === 'done' || k === 'reg' ? { rd: '', id: today() } : { rd: '', id: '' };
  return ui.flt[k];
}
function fltBar(k, must) {
  const f = fltGet(k);
  const cell = (key, label) => '<label class="f fdate"><span>' + label + '</span><span class="fin"><input type="date" data-flt="' + k + '|' + key + '" value="' + esc(f[key] || '') + '">' + (f[key] ? '<button class="fx" data-a="fltClear" data-v="' + k + '|' + key + '" aria-label="Clear ' + label + '">' + ico('x', 14) + '</button>' : '') + '</span></label>';
  return '<div class="fbar">' + cell('rd', 'Request date') + cell('id', 'Issue date') + '</div>' + (!f.rd && !f.id ? '<div class="note">' + (must ? 'Pick at least one date.' : 'Showing all dates.') + '</div>' : '');
}
function regGroups() {
  const f = fltGet('reg'), ents = regEntries();
  const ids = new Set(ents.flatMap(e => e.items.map(i => i.req)).filter(Boolean));
  if (f.rd && !f.id) requests().filter(r => r.date === f.rd).forEach(r => ids.add(r.req));
  const MR = S.manReqs || {};
  Object.values(MR).forEach(m => { if ((!f.rd || m.date === f.rd) && (!f.id || S.entries.some(e => entryHasReq(e, m.req) && entryDate(e) === f.id))) ids.add(m.req); });
  const R = requests().filter(r => ids.has(r.req) && !MR[r.req]);
  const GM = Object.values(MR).filter(m => ids.has(m.req)).map(m => { const sl = reqSlips(m.req); const done = sl.reduce((n, e) => n + entryCount(e, m.req), 0);
    return { req: m.req, store: m.store, date: m.date, man: m, left: [], issued: done, closed: 0, total: m.total || done, slips: sl.filter(e => !f.id || entryDate(e) === f.id), manStatus: m.status }; });
  const G = R.map(r => { const L = r.lines; return { req: r.req, store: r.store, date: r.date, left: L.filter(l => l.status === 'waiting'), issued: L.filter(l => l.status === 'issued').length, closed: L.filter(l => l.status === 'dropped').length, total: L.filter(l => l.status !== 'dropped').length, slips: S.entries.filter(e => e.items.some(i => i.req === r.req) && (!f.id || entryDate(e) === f.id)).sort((a, b) => (a.at || '').localeCompare(b.at || '')) }; });
  return sortBy(G.concat(GM), getSort('reg'), g => ({ req: g.req, store: g.store, date: g.date, ready: g.left.length, size: g.total }));
}
function regEntries() { const f = fltGet('reg'); return S.entries.filter(e => (!f.id || entryDate(e) === f.id) && (!f.rd || e.items.some(i => reqDateOfRaw(i.req) === f.rd))); }
function issuedOn(req, d) { return S.entries.some(e => entryDate(e) === d && e.items.some(i => i.req === req)); }
function reqMatch(r, f) { return (!f.rd || r.date === f.rd) && (!f.id || issuedOn(r.req, f.id)); }
function vPend() {
  const PL = plan(), f = fltGet('pend');
  const R = requests().map(r => Object.assign(r, { pl: r.lines.filter(isPending) })).filter(r => r.pl.length && reqMatch(r, f));
  const all = R.flatMap(r => r.pl), can = all.filter(l => PL[l.id] === 'issue');
  const oldest = all.reduce((m, l) => Math.max(m, days(l.date)), 0);
  let h = '<header class="top"><div><h1>Pending</h1><div class="sub">Each request on its own card. Tap one to see every article and why it waits.</div></div></header><main>';
  h += '<div class="grid3"><div class="tile t-pt"><b>' + all.length + '</b><span>Articles pending</span></div><div class="tile t-ok"><b>' + can.length + '</b><span>Ready now</span></div><div class="tile t-no"><b>' + oldest + ' d</b><span>Oldest</span></div></div>';
  h += stockCard();
  h += fltBar('pend', false);
  const fut = S.lines.filter(l => l.status === 'waiting' && l.date > today());
  if (fut.length) { const fd = [...new Set(fut.map(l => l.date))].sort(); h += '<button class="banner tap" data-a="homeDate" data-v="' + fd[0] + '" style="border:0;background:var(--infoBg);color:var(--infoInk)"><b>' + fut.length + ' articles scheduled</b> for ' + fd.map(fmtShort).join(', ') + '. They are not pending yet and keep no stock until their day. Tap to view.</button>'; }
  h += '<button class="btn main full" data-a="artsOpen">Manage pending articles</button>';
  h += '<div class="grid2"><button class="btn sm" data-a="expPendPdf"' + (all.length ? '' : ' disabled') + '>Pending PDF</button><button class="btn sm" data-a="bulkEdit">Edit all requests</button></div>';
  if (!R.length) return h + '<div class="card pad note">Nothing pending' + (f.rd || f.id ? ' for these dates' : '') + '.</div></main>';
  sortBy(R, getSort('pend'), r => ({ req: r.req, store: r.store, date: r.date, ready: r.pl.filter(l => PL[l.id] === 'issue').length, size: r.pl.length }));
  h += '<div class="shead"><div><h2>' + R.length + ' requests</h2><span>' + all.length + ' articles</span></div>' + sortPick('pend') + '</div>';
  const fresh = R.filter(r => !r.lines.some(l => l.status === 'issued')), cont = R.filter(r => r.lines.some(l => l.status === 'issued'));
  [['new', 'Never entered on CUIMS', fresh], ['cont', 'Entered before, articles left', cont]].forEach(([cls, title, list]) => {
    if (!list.length) return;
    h += '<div class="sgroup"><span class="sdot ' + cls + '"></span><b>' + title + '</b><span>' + list.length + '</span></div>';
    list.forEach(r => {
      const ready = r.pl.filter(l => PL[l.id] === 'issue'), d0 = days(r.date), sl = reqSlips(r.req);
      h += rqCard({ where: 'pend', req: r.req, store: r.store, cont: cls === 'cont', x: 'dropReq', status: ready.length === r.pl.length ? ['All ready', 'c-ok'] : ready.length ? [ready.length + ' of ' + r.pl.length + ' ready', 'c-gd'] : ['Waiting', 'c-no'],
        meta: [fmtShort(r.date), d0 ? d0 + (d0 === 1 ? ' day' : ' days') + ' old' : 'today', r.pl.length + ' pending'], chips: unavail(r.pl, PL), slips: sl.length ? sl : null,
        cta: ready.length ? '<button class="btn main full" data-a="fillReqPend" data-v="' + esc(r.req) + '">Fill on CUIMS · ' + ready.length + ' available</button>' : '' });
    });
  });
  return h + '</main>';
}

/* ---------------- Start fill sheet ---------------- */
const isBaseKitchen = st => /BASE\s*-?\s*KITCHEN|\bEVENTS?\b/i.test(String(st || ''));
function advLines(r) { if (!isBaseKitchen(r.store) || !(r.date > today())) return []; return r.lines.filter(l => l.status === 'waiting' && !S.hold[l.id] && S.stock[l.code] && S.stock[l.code].qty >= l.qty); }
function openStart(store, lineIds, title, adv) {
  const ls = S.lines.filter(l => lineIds.includes(l.id));
  const rcv = (ls.find(l => l.rcv) || {}).rcv || (S.stores[store] || {}).rcv || '';
  ui.sheet = { kind: 'start', store, lineIds, title, slip: plannedSlip(lineIds) || nextSlip(), rcv, off: {}, qty: {}, req: (ls[0] || {}).req, adv: !!adv, advRemark: '' };
  renderSheet();
}
function shStart() {
  const s = ui.sheet;
  const ls = S.lines.filter(l => s.lineIds.includes(l.id));
  const sp = slipProblem(s.slip), rp = validRcv(s.rcv) ? '' : 'Receiver must be 6 digits (GA) or up to 5 digits (E code).';
  const areaOk = !S.areas.length || S.areas.some(a => a.toUpperCase() === s.store.toUpperCase());
  const old = S.lastLoginAt && (Date.now() - new Date(S.lastLoginAt)) > 2 * 3600e3;
  let h = '<div class="row"><h2>' + esc(s.title) + '</h2><button class="btn sm ghost" data-a="closeSheet">Close</button></div>';
  if (s.adv) h += '<div class="advbox"><b>Advance issue · ' + esc(s.store) + '</b><span>Requested for ' + fmtLong((ls[0] || {}).date || today()) + '. Uses any stock in hand. Queue and Auto submit stay off: you tap SUBMIT yourself.</span><label class="f" style="margin-top:8px">Remarks (optional)<input type="text" data-adv="1" value="' + esc(s.advRemark || '') + '" placeholder="Leave blank for no remark"></label></div>';
  h += '<label class="f">Slip No for this entry<input type="text" data-in="slip" value="' + esc(s.slip) + '" class="mono' + (sp ? ' bad' : '') + '" autocomplete="off" autocapitalize="characters" placeholder="e.g. JV/915"></label>' + (sp ? '<div class="err">' + esc(sp) + '</div>' : '<div class="okt">Slip No is free to use.</div>');
  h += '<label class="f">Receiver (GA 6 digits or E code, this entry only)<input type="text" inputmode="numeric" maxlength="6" data-in="rcv" value="' + esc(s.rcv) + '" class="mono' + (rp ? ' bad' : '') + '"></label>' + (rp ? '<div class="err">' + rp + '</div>' : '<div class="note">CUIMS will pick ' + esc(rcvLabel(s.rcv)) + ' … (GA) from the list.</div>');
  if (!areaOk) h += '<div class="err">"' + esc(s.store) + '" is not in the CUIMS Project Area list. Fix the store name in Settings or the request.</div>';
  if (old) h += '<div class="banner t-pt">Your CUIMS login is over 2 hours old. It may log out soon; the app will pause and restart the entry if it does.</div>';
  h += '<div class="row"><span class="sect">Articles for this entry</span><span class="note">' + s.lineIds.filter(id => !s.off[id]).length + ' selected</span></div>';
  h += '<div class="card">' + ls.map(l => '<div class="line"><div class="row" style="align-items:center"><label class="chk" style="min-height:0;gap:10px;flex:1"><input type="checkbox" data-a="stOn" data-v="' + l.id + '"' + (s.off[l.id] ? '' : ' checked') + '><span><b>' + esc(itemName(l.code)) + '</b><div class="note mono">' + esc(l.code) + ' · Req ' + esc(l.req) + '</div></span></label>' +
    '<input type="number" inputmode="decimal" data-stq="' + l.id + '" value="' + esc(s.qty[l.id] != null ? s.qty[l.id] : l.qty) + '" style="width:96px;text-align:right"><span class="note" style="width:38px">' + esc(itemUom(l.code)) + '</span></div>' +
    meta([S.stock[l.code] ? num(S.stock[l.code].qty) + ' in stock' : '', !s.adv && remarkFor(l.date) ? 'remark added' : '']) + '</div>').join('') + '</div>';
  h += '<div class="card pad col"><b>Add an article to this entry</b><div class="grid2"><input type="text" data-stadd="code" value="' + esc(s.addCode || '') + '" placeholder="Item code e.g. GR-198" autocapitalize="characters" class="mono"><input type="number" inputmode="decimal" data-stadd="qty" value="' + esc(s.addQty || '') + '" placeholder="Qty"></div><button class="btn" data-a="stAdd">+ Add article</button></div>';
  if (!s.adv) h += '<label class="chk"><input type="checkbox" data-a="queueToggle"' + (S.queue ? ' checked' : '') + '> Queue mode: after I submit, fill the next request automatically</label>';
  if (S.queue && !s.adv) h += queueBox();
  h += '<button class="btn main full" data-a="startFill"' + (sp || rp ? ' disabled' : '') + '>Start filling on CUIMS</button>';
  h += '<div class="note" style="text-align:center">' + (S.autoSubmit ? 'Auto submit is on: SUBMIT is tapped after a 100% recheck, with a 4-second Stop window.' : 'The app never taps SUBMIT. You check and submit yourself.') + '</div>';
  return h;
}
function startJob(store, slip, rcv, lineIds, adv) {
  rcv = normRcv(rcv) || rcv;
  const ls = S.lines.filter(l => lineIds.includes(l.id) && l.status === 'waiting');
  const nq = S.queue && !adv ? nextQueueJob(lineIds) : null;
  const job = { id: 'J' + Date.now(), fun: !!S.funMode, adv: !!adv, test: !!S.testMode, slip, rcv, store, queue: !!S.queue && !adv, next: nq ? nq.req + ' · ' + nq.store : '', autoSubmit: !!S.autoSubmit && !S.testMode && !adv, phase: 'dup', paused: false, log: [], tries: {},
    items: ls.map(l => ({ lineId: l.id, req: l.req, reqDate: l.date, code: l.code, name: itemName(l.code), uom: itemUom(l.code), qty: l.qty, remark: adv ? adv.remark : (l.remark || remarkFor(l.date)), skip: false })) };
  if (!N) { toast('Open this inside the JV Stock Issue app to fill CUIMS.'); return; }
  N.startJob(jobJson(job));
}
function queueList(skipIds) {
  const PL = plan(), t = today(), skip = new Set(skipIds || []);
  const R = requests().map(r => Object.assign(r, reqState(r, PL))).map(r => {
    const can = r.lines.filter(l => l.status === 'waiting' && PL[l.id] === 'issue' && !skip.has(l.id) && (r.date === t && l.src !== 'old' ? true : S.queuePend && isPending(l)));
    return Object.assign(r, { qcan: can });
  }).filter(r => r.qcan.length);
  sortBy(R, S.queueSort || 'reqdate', r => ({ req: r.req, store: r.store, date: r.date, ready: r.qcan.length, size: r.lines.length }));
  return R.filter(r => validRcv((r.lines.find(l => l.rcv) || {}).rcv || (S.stores[r.store] || {}).rcv || ''));
}
function nextQueueJob(skipIds) {
  const r = queueList(skipIds)[0]; if (!r) return null;
  const rcv = (r.lines.find(l => l.rcv) || {}).rcv || (S.stores[r.store] || {}).rcv || '';
  return { store: r.store, rcv, ids: r.qcan.map(l => l.id), req: r.req };
}
function queueBox() {
  const L = queueList(ui.sheet && ui.sheet.kind === 'start' ? ui.sheet.lineIds : []);
  return '<div class="card pad col" style="gap:10px"><div class="row"><b>Queue order</b>' + pickBtn('queueSort', { title: 'Queue order', opts: SORT_OPTS, val: S.queueSort || 'reqdate', set: v => { S.queueSort = v; save(true); render(); renderSheet(); } }) + '</div>' +
    '<label class="chk" style="min-height:36px"><input type="checkbox" data-a="queuePend"' + (S.queuePend ? ' checked' : '') + '> Also take pending requests (after today\'s)</label>' +
    (L.length ? '<div class="qnext"><span>Next up</span>' + L.slice(0, 6).map((r, i) => '<div class="qrow"><b>' + (i + 1) + '</b><span class="reqno">' + esc(r.req) + '</span><span class="qst">' + esc(r.store) + '</span><span class="note">' + r.qcan.length + '</span></div>').join('') + (L.length > 6 ? '<div class="note">+ ' + (L.length - 6) + ' more</div>' : '') + '</div>' : '<div class="note">Nothing else ready to queue.</div>') + '</div>';
}

/* ---------------- Upload sheet ---------------- */
function reparseUpload() { const u = ui.upload; if (!u || !u.wb) { renderSheet(); return; } u.result = u.kind === 'stock' ? parseStock(u.wb) : parseRequests(u.wb, u.kind); renderSheet(); }
function importReport(r, kind) {
  const sk = r.skipped || [], nt = r.notes || [];
  if (!sk.length && !nt.length) return '<div class="okbox">' + ico('right', 16).replace('M9 6l6 6-6 6', 'M5 12.5l4.5 4.5L19 7.5') + '<span>Nothing will be skipped. Every row is clean.</span></div>';
  const group = list => { const g = {}; list.forEach(x => (g[x.why] = g[x.why] || []).push(x)); return Object.entries(g).sort((a, b) => b[1].length - a[1].length); };
  const where = a => '<div class="inapp">' + '<b>In app: ' + esc(a.store) + '</b><span>' + [fmtShort(a.date), 'qty ' + num(a.qty), a.status === 'issued' ? 'issued' + (a.slip ? ' in ' + a.slip : '') + (a.serial ? ' #' + a.serial : '') : a.status === 'dropped' ? 'removed' : 'waiting', a.made === 'file' ? 'from an earlier file' : ''].filter(Boolean).map(esc).join(' · ') + '</span><span class="inbtns"><button class="btn sm ghost" data-a="impOpenReq" data-v="' + esc(a.req) + '">Open</button><button class="btn sm ghost" data-a="impRenum" data-v="' + esc(a.req) + '">Renumber app\'s request</button>' + (a.status !== 'issued' ? '<button class="btn sm ghost danger-t" data-a="impDrop" data-v="' + esc(a.req) + '">Remove app\'s request</button>' : '') + '</span></div>';
  const table = (list, stock) => '<div class="tblwrap"><table><tr><th>Row</th>' + (stock ? '' : '<th>Request</th><th>Store</th>') + '<th>Item</th><th>Qty</th></tr>' + list.map(x => '<tr><td>' + x.row + '</td>' + (stock ? '' : '<td><b>' + esc(x.req || '–') + '</b></td><td>' + esc(x.store || '–') + '</td>') + '<td class="mono">' + esc(x.code || '–') + (S.stock[x.code] ? '<div class="note">' + esc(S.stock[x.code].name) + '</div>' : '') + '</td><td>' + esc(x.qty || '–') + '</td></tr>' + (x.inApp ? '<tr class="inrow"><td></td><td colspan="4">' + where(x.inApp) + '</td></tr>' : '')).join('') + '</table></div>';
  let h = '';
  if (sk.length) {
    h += '<div class="card" style="overflow:hidden"><div class="pad row"><b class="ttl" style="font-size:17px">Will be skipped</b>' + pill(sk.length + ' row' + (sk.length > 1 ? 's' : ''), 'c-no') + '</div>';
    group(sk).forEach(([why, list], k) => { h += '<details class="ireason"' + (k === 0 ? ' open' : '') + '><summary><span class="dot no"></span><span style="flex:1">' + esc(why) + '</span><b>' + list.length + '</b>' + ico('down', 16) + '</summary>' + table(list, kind === 'stock') + '</details>'; });
    h += '</div>';
  }
  if (nt.length) {
    h += '<div class="card" style="overflow:hidden"><div class="pad row"><b class="ttl" style="font-size:17px">Imported with a note</b>' + pill(nt.length, 'c-gd') + '</div>';
    group(nt).forEach(([why, list]) => { h += '<details class="ireason"><summary><span class="dot gd"></span><span style="flex:1">' + esc(why) + '</span><b>' + list.length + '</b>' + ico('down', 16) + '</summary>' + table(list, false) + '</details>'; });
    h += '</div>';
  }
  return h;
}
function shUpload() {
  const u = ui.upload;
  let h = '<div class="row"><h2>Upload</h2><button class="btn sm ghost" data-a="closeSheet">Close</button></div>';
  if (!u || !u.result) {
    h += '<button class="card pad tap col" style="gap:4px" data-a="upPick" data-v="new"><b>Fresh requests</b><span class="note">"New Requests" tab of the template. One row per article.</span></button>';
    h += '<button class="card pad tap col" style="gap:4px" data-a="upPick" data-v="old"><b>My earlier pending</b><span class="note">"Old Pending" tab. Load once, before you start using the app.</span></button>';
    h += '<button class="card pad tap col" style="gap:4px" data-a="upPick" data-v="stock"><b>CUIMS stock report</b><span class="note">Item Stock Statement exactly as downloaded. Replaces stock fully.</span></button>';
    h += '<button class="btn ghost" data-a="template">Download data template</button>';
    if (u && u.error) h += '<div class="err">' + esc(u.error) + '</div>';
    return h;
  }
  const r = u.result;
  if (u.kind === 'stock') {
    if (r.noCode) { u.linkBy = 'name'; u.stockMode = 'update'; u.addNew = false; }
    if (!u.diff) { u.diff = stockDiff(r.stock, u.linkBy || 'both'); if (!u.stockMode) u.stockMode = Object.keys(S.stock).length ? 'update' : 'fresh'; }
    h += '<div class="card pad col"><b>' + r.count.toLocaleString('en-IN') + ' items in this report</b><div class="note">Current stock: ' + Object.keys(S.stock).length.toLocaleString('en-IN') + ' items, updated ' + (S.stockAt ? esc(ago(S.stockAt)) : 'never') + '.</div></div>';
    if (r.noCode) h += '<div class="banner" style="border:0;background:#FFE4EA;color:#8E1B3A"><b>This report has no Item Codes.</b> The Item Code column is empty in every row, so the app can only update closing qty of items whose name is exactly the same. Fresh replace and adding new items are turned off for this file. Tip: on CUIMS export with the floppy icon → Excel inside the report.</div>';
    if (Object.keys(S.stock).length) h += stockDiffHtml(u);
    else if (r.noCode) h += '<div class="err">You have no stock in the app yet, so a report without Item Codes cannot be used. Please export again with Item Codes.</div>';
  } else {
    const stores = [...new Set(r.rows.map(x => x.store))];
    const reqs = [...new Set(r.rows.map(x => x.req))];
    h += '<div class="card pad col"><b>' + r.rows.length + ' articles will be imported · ' + reqs.length + ' requests · ' + stores.length + ' stores</b><div class="note">' + esc(stores.join(', ')) + '</div>' +
      (r.info ? '<div class="note">' + esc(r.info) + '</div>' : '') + '</div>';
    const unknownStores = S.areas.length ? stores.filter(s => !S.areas.some(a => a.toUpperCase() === s)) : [];
    if (unknownStores.length) r.warn.unshift('Not in the CUIMS Project Area list: ' + unknownStores.join(', '));
    if (r.warn.length) h += '<div class="card pad col" style="gap:4px">' + r.warn.map(w => '<div class="err" style="font-weight:500">' + esc(w) + '</div>').join('') + '</div>';
  }
  if (r.rows && r.rows.length) { const fut = r.rows.filter(x => x.date > today()); if (fut.length) { const fd = [...new Set(fut.map(x => x.date))].sort(); h += '<div class="banner" style="border:0;background:var(--infoBg);color:var(--infoInk)"><b>' + fut.length + ' articles are for ' + fd.map(fmtLong).join(', ') + '.</b> They are saved now as <b>Scheduled</b>: not pending, no stock kept, no Fill button. On that day they become that day\'s requests with top priority.</div>'; } }
  if (u.auto) h = '<div class="okbox" style="background:#ECE6FF;color:#4B3BA8"><span><b>Live stock downloaded from CUIMS</b> · ' + esc((S.autoStock || {}).store || '') + ' · ' + esc(((S.autoStock || {}).fy) || curFY()) + '</span></div>' + h;
  h += importReport(r, u.kind);
  const nImp = u.kind === 'stock' ? r.count : r.rows.length, nSk = (r.skipped || []).length;
  const lbl = u.kind === 'stock' && u.diff && Object.keys(S.stock).length ? (u.stockMode === 'fresh' ? 'Replace with ' + nImp + ' items' : 'Update ' + (u.diff.code.length + u.diff.name.length) + ' items' + (u.addNew && u.diff.fresh.length ? ' + add ' + u.diff.fresh.length : '')) : 'Import ' + nImp + (nSk ? ', skip ' + nSk : '');
  h += '<div class="grid2"><button class="btn" data-a="uploadCancel">Back</button><button class="btn main" data-a="uploadOk"' + (!nImp ? ' disabled' : '') + '>' + lbl + '</button></div>';
  return h;
}

/* ---------------- Registers ---------------- */
function entryDate(e) { return e.date || (e.at || '').slice(0, 10); }
function entryTime(e) { return e.time || (e.at ? pad(new Date(e.at).getHours()) + ':' + pad(new Date(e.at).getMinutes()) : ''); }
function rname(code) { return (S.rnames || {})[code] || ''; }
function vReg() {
  const r = ui.reg;
  let h = '<header class="top"><div><h1>Registers</h1><div class="sub">Daily issue and return registers, editable, with PDF.</div></div></header><main>';
  h += '<button class="btn full" data-a="consOpen">Store-wise consumption</button>';
  h += '<div class="seg"><button data-a="regType" data-v="issue" class="' + (r.type === 'issue' ? 'on' : '') + '">Issue</button><button data-a="regType" data-v="return" class="' + (r.type === 'return' ? 'on' : '') + '">Return</button></div>';
  if (r.type === 'issue') h += fltBar('reg', true); else h += '<label class="f">Return date<input type="date" data-in="regDate" value="' + esc(r.date) + '"></label>';
  if (r.type === 'issue') {
    const G = regGroups();
    const isPend = g => g.man ? g.manStatus !== 'done' : g.left.length > 0;
    const pendN = G.filter(isPend).length;
    h += '<div class="seg">' + [['all', 'All ' + G.length], ['pending', 'Pending ' + pendN], ['done', 'Completed ' + (G.length - pendN)]].map(([k, l]) => '<button data-a="regSt" data-v="' + k + '" class="' + ((r.st || 'all') === k ? 'on' : '') + '">' + l + '</button>').join('') + '</div>';
    const list = G.filter(g => (r.st || 'all') === 'all' || (r.st === 'pending' ? isPend(g) : !isPend(g)));
    h += '<div class="shead"><div><h2>' + list.length + ' requests</h2><span>' + list.reduce((n, g) => n + g.slips.length, 0) + ' slips</span></div>' + sortPick('reg') + '</div>';
    h += '<div class="grid2"><button class="btn main" data-a="pdfIssue"' + (list.length ? '' : ' disabled') + '>Make PDF</button><button class="btn" data-a="newManual">+ Manual entry</button></div>';
    { const vd = fltGet('reg').id || today(); h += '<button class="btn ret full" data-a="verDay" data-v="' + vd + '">Verify all of ' + fmtShort(vd) + ' on CUIMS</button>'; }
    if (!list.length) h += '<div class="card pad note">Nothing for these dates.</div>';
    list.forEach(g => {
      if (g.man) { h += rqCard({ where: 'reg', req: g.req, store: g.store, tap: false, status: g.manStatus === 'done' ? ['Completed', 'c-ok'] : ['Pending · ' + g.issued + ' of ' + (g.total || '?') + ' issued', 'c-gd'],
        meta: ['requested ' + (g.date ? fmtShort(g.date) : '–'), esc(rcvLabel(g.man.rcv || '–')) + (g.man.rname ? ' ' + esc(g.man.rname) : ''), '<span class="stag man" style="position:static">Manual record</span>'], slips: g.slips,
        btns: '<button class="btn sm" data-a="manReqEdit" data-v="' + esc(g.req) + '">Edit slips & status</button><button class="btn sm ghost" data-a="manReqToggle" data-v="' + esc(g.req) + '">' + (g.manStatus === 'done' ? 'Mark pending' : 'Mark completed') + '</button>' }); return; }
      h += rqCard({ where: 'reg', req: g.req, store: g.store, status: g.left.length ? ['Pending · ' + g.left.length + ' of ' + g.total + ' left', 'c-gd'] : g.total ? ['Completed', 'c-ok'] : ['No articles', 'c-gy'],
        meta: ['requested ' + (g.date ? fmtShort(g.date) : '–'), g.issued + ' of ' + g.total + ' issued', g.closed ? g.closed + ' closed' : ''], slips: g.slips, left: g.left,
        chips: verifyBadge(g.req), btns: '<button class="btn sm" data-a="mslips" data-v="' + esc(g.req) + '">+ Add slips & serials</button><button class="btn sm ghost" data-a="reqStatus" data-v="' + esc(g.req) + '">Pending / completed</button><button class="btn sm ret" data-a="verReq" data-v="' + esc(g.req) + '">Verify on CUIMS</button>' });
    });
  } else {
    const fr = fltGet('ret'), st = r.rst || 'all';
    let L = S.returns.filter(x => (!fr.rd || (x.recvDate || x.date) === fr.rd) && (!fr.id || x.date === fr.id));
    const waitN = L.filter(x => !x.serial).length;
    h += '<div class="fbar">' + ['rd|Came on', 'id|Entry date'].map(z => { const [key, label] = z.split('|'); return '<label class="f fdate"><span>' + label + '</span><span class="fin"><input type="date" data-flt="ret|' + key + '" value="' + esc(fr[key] || '') + '">' + (fr[key] ? '<button class="fx" data-a="fltClear" data-v="ret|' + key + '" aria-label="Clear">' + ico('x', 14) + '</button>' : '') + '</span></label>'; }).join('') + '</div>';
    h += '<div class="seg">' + [['all', 'All ' + L.length], ['wait', 'Not on CUIMS ' + waitN], ['done', 'On CUIMS ' + (L.length - waitN)]].map(([k, l]) => '<button data-a="retSt" data-v="' + k + '" class="' + (st === k ? 'on' : '') + '">' + l + '</button>').join('') + '</div>';
    L = L.filter(x => st === 'all' || (st === 'wait' ? !x.serial : !!x.serial));
    L = sortBy(L, getSort('ret'), x => ({ req: x.no, store: x.store, date: x.recvDate || x.date, ready: x.serial ? 0 : 1, size: x.items.length }));
    h += '<div class="shead"><div><h2>' + L.length + ' returns</h2><span>' + L.reduce((n, x) => n + x.items.length, 0) + ' articles</span></div>' + sortPick('ret') + '</div>';
    h += '<div class="grid2"><button class="btn main" data-a="newReturn">+ New return</button><button class="btn" data-a="retBatch">+ Batch add returns</button></div>';
    const Q = retQueue(); if (Q.length) h += '<button class="btn ret full" data-a="retStartAll">Return on CUIMS · ' + Q.length + ' waiting' + (S.queue ? ' (queue on)' : '') + '</button>';
    h += '<button class="btn sm ghost" data-a="pdfReturn"' + (L.length ? '' : ' disabled') + '>Make PDF</button>';
    if (!L.length) h += '<div class="card pad note">No returns for these filters.</div>';
    L.forEach(x => {
      const nm = x.byName || rcvName(x.by), rem = retRemark(x);
      h += rqCard({ where: 'ret', req: x.no, store: x.store, tapA: 'editReturn', tapV: x.id, status: x.serial ? ['On CUIMS', 'c-ok'] : ['Not on CUIMS yet', 'c-gd'],
        meta: ['came ' + fmtShort(x.recvDate || x.date), esc(rcvLabel(x.by)) + (nm ? ' ' + esc(nm) : ''), x.items.length + (x.items.length === 1 ? ' article' : ' articles')],
        chips: x.serial ? '<div class="scrow"><span class="stag ret" style="position:static">Serial</span>' + serFmt(x.serial) + '</div>' : '',
        left: x.items.map(i => ({ code: i.code, qty: i.qty })), leftWord: x.serial ? 'returned article' : 'article to return', leftWords: x.serial ? 'returned articles' : 'articles to return', leftCls: x.serial ? 'okl' : 'retl',
        cta: x.serial ? '<button class="btn sm ret full" data-a="verRet" data-v="' + x.id + '">' + (x.verified ? (x.verified.issues ? 'Verify again · ' + x.verified.issues + ' to check' : 'Verified ✓ · check again') : 'Verify on CUIMS') + '</button>' : '<button class="btn ret full" data-a="retCuims" data-v="' + x.id + '">Return on CUIMS · ' + x.items.length + ' articles</button>' });
    });
  }
  return h + '</main>';
}
function itemRowsHtml(items, noRemark) {
  return items.map((it, i) => '<div class="card pad col" style="gap:6px"><div class="row"><b>Item ' + (i + 1) + (it.name ? ': ' + esc(it.name) : '') + '</b><button class="btn sm warn" data-a="rmItem" data-v="' + i + '">Remove</button></div>' +
    '<div class="grid2"><label class="f">Item code<input type="text" data-it="' + i + '|code" value="' + esc(it.code) + '" autocapitalize="characters" class="mono"></label><label class="f">Qty' + (it.uom ? ' (' + esc(it.uom) + ')' : '') + '<input type="number" inputmode="decimal" data-it="' + i + '|qty" value="' + esc(it.qty) + '"></label></div>' +
    (noRemark ? '' : '<label class="f">Item remarks<input type="text" data-it="' + i + '|remark" value="' + esc(it.remark || '') + '" maxlength="100"></label>') + '</div>').join('');
}
function shEntry() {
  const f = ui.form;
  let h = '<div class="row"><h2>' + (f.kind === 'manual' ? (f._new ? 'New manual entry' : 'Manual entry') : 'Issue entry') + '</h2><button class="btn sm ghost" data-a="closeSheet">Close</button></div>';
  if (f.kind !== 'manual') h += '<div class="note">Editing changes the register record only, not stock or pending.</div>';
  h += '<div class="grid2"><label class="f">Slip No<input type="text" data-f="slip" value="' + esc(f.slip) + '" class="mono"></label><label class="f">Serial No<input type="text" data-f="serial" value="' + esc(f.serial || '') + '" class="mono" inputmode="numeric"></label></div>';
  h += '<label class="f">Store (Project Area)<input type="text" data-f="store" list="areaList" value="' + esc(f.store) + '" autocapitalize="characters"></label>' + areaDatalist();
  h += '<div class="grid2"><label class="f">Issued to (GA or E code)<input type="text" data-f="rcv" value="' + esc(f.rcv) + '" class="mono" inputmode="numeric" maxlength="6"></label><label class="f">Receiver name<input type="text" data-f="rname" value="' + esc(f.rname || '') + '"></label></div>';
  h += '<div class="grid2"><label class="f">Date<input type="date" data-f="date" value="' + esc(f.date) + '"></label><label class="f">Time<input type="time" data-f="time" value="' + esc(f.time) + '"></label></div>';
  h += '<label class="f">Request No(s)<input type="text" data-f="reqs" value="' + esc(f.reqs || '') + '"></label>';
  h += '<label class="f">Remarks<input type="text" data-f="remarks" value="' + esc(f.remarks || '') + '"></label>';
  h += '<div class="grid2"><label class="f">Entered by (name)<input type="text" data-f="byName" value="' + esc(f.byName) + '"></label><label class="f">Emp code<input type="text" data-f="byEmp" value="' + esc(f.byEmp) + '"></label></div>';
  h += '<div class="sect">Items</div>' + itemRowsHtml(f.items) + '<button class="btn ghost" data-a="addItem">+ Add item</button>';
  h += '<div class="grid2">' + (f._new ? '<span></span>' : '<button class="btn warn" data-a="delEntry">Delete</button>') + '<button class="btn main" data-a="saveEntry">Save</button></div>';
  return h;
}
function shReturn() {
  const f = ui.form;
  let h = '<div class="row"><h2>' + (f._new ? 'New return' : 'Return ' + esc(f.no)) + '</h2><button class="btn sm ghost" data-a="closeSheet">Close</button></div>';
  if (f._new && f._autoNo) f.no = nextReturnNo(f.recvDate || today());
  const dupNo = S.returns.some(x => String(x.no).toUpperCase() === String(f.no || '').trim().toUpperCase() && x.id !== f.id);
  h += '<div class="grid2"><label class="f">Return No (yours)<input type="text" data-f="no" data-retno="1" value="' + esc(f.no) + '" class="mono" autocapitalize="characters"><span class="rcvname ' + (dupNo ? 'new' : 'ok') + '">' + (dupNo ? 'Already used. Next free: ' + esc(nextReturnNo(f.recvDate || today())) : RET_RE.test(f.no || '') ? 'Free to use' : 'Format R-DDMM-NN, e.g. ' + esc(nextReturnNo(f.recvDate || today()))) + '</span></label><label class="f">Against Issue No<input type="text" data-f="against" value="' + esc(f.against) + '" class="mono" inputmode="numeric"></label></div>';
  h += '<label class="f">Store (Project Area)<input type="text" data-f="store" list="areaList" value="' + esc(f.store) + '" autocapitalize="characters"></label>' + areaDatalist();
  h += '<div class="grid2"><label class="f">Returned by (GA or E code)<input type="text" data-f="by" value="' + esc(f.by) + '" class="mono" inputmode="numeric" maxlength="6"></label><label class="f">Name<input type="text" data-f="byName" value="' + esc(f.byName || '') + '"></label></div>';
  h += '<label class="f">Return came on (used in the remark)<input type="date" data-f="recvDate" value="' + esc(f.recvDate || f.date || today()) + '"></label>';
  h += '<div class="advbox" style="background:#E3EEFF;border-color:#5B9BFF"><b style="color:#173A7A">Remark on every article</b><span style="color:#2A4E8F" class="mono">' + esc(retRemark({ store: f.store, recvDate: f.recvDate || f.date })) + '</span></div>';
  h += '<div class="grid2"><label class="f">Entry date<input type="date" data-f="date" value="' + esc(f.date) + '"></label><label class="f">Time<input type="time" data-f="time" value="' + esc(f.time) + '"></label></div>';
  h += '<label class="f">Serial No (after you submit on CUIMS)<input type="text" data-f="serial" value="' + esc(f.serial || '') + '" class="mono" inputmode="numeric"></label>';
  h += '<label class="f">Overall remarks<input type="text" data-f="remarks" value="' + esc(f.remarks || '') + '"></label>';
  h += '<div class="grid2"><label class="f">Entered by (name)<input type="text" data-f="ebName" value="' + esc(f.ebName) + '"></label><label class="f">Emp code<input type="text" data-f="ebEmp" value="' + esc(f.ebEmp) + '"></label></div>';
  h += '<div class="sect">Items</div>' + itemRowsHtml(f.items) + '<button class="btn ghost" data-a="addItem">+ Add item</button>';
  h += '<button class="btn ret full" data-a="saveReturnCuims">Save & return on CUIMS</button>';
  h += '<div class="grid2">' + (f._new ? '<span></span>' : '<button class="btn warn" data-a="delReturn">Delete</button>') + '<button class="btn main" data-a="saveReturn">Save only</button></div>';
  return h;
}
function areaDatalist() {
  const opts = [...new Set([...Object.keys(S.stores), ...S.areas])];
  return '<datalist id="areaList">' + opts.map(a => '<option value="' + esc(a) + '">').join('') + '</datalist>';
}
const MON3 = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
function cuimsDate(iso) { const p = String(iso || today()).split('-'); return MON3[+p[1] - 1] + ' ' + p[2] + ', ' + p[0]; }
function retRemark(r) { return 'Returned from ' + String(r.store || '').trim() + ' on ' + cuimsDate(r.recvDate || r.date); }
function retQueue(skipId) { return S.returns.filter(r => !r.serial && r.id !== skipId && r.store && validRcv(r.by) && r.items.length).sort((a, b) => String(a.recvDate || a.date).localeCompare(String(b.recvDate || b.date)) || String(a.no).localeCompare(String(b.no), undefined, { numeric: true })); }
function jobJson(o) { flushLocal(); if (o && o.fun == null) o.fun = !!S.funMode; return JSON.stringify(o); }
function startReturnJob(r) {
  if (!r.store || !validRcv(r.by) || !r.items.length) { toast('Store, a By employee code (GA or E) and at least one item are needed.'); return; }
  const rem = retRemark(r);
  const nx = S.queue ? retQueue(r.id)[0] : null;
  const job = { id: 'J' + Date.now(), fun: !!S.funMode, kind: 'return', retId: r.id, slip: r.no, rcv: normRcv(r.by) || r.by, rname: r.byName || rcvName(r.by), store: r.store, retDateText: cuimsDate(r.recvDate || r.date), test: !!S.testMode, queue: !!S.queue, autoSubmit: !!S.autoSubmit && !S.testMode, phase: 'fill', paused: false, log: [], tries: {}, next: nx ? nx.no + ' · ' + nx.store : '',
    items: r.items.map((i, k) => ({ lineId: 'r' + r.id + '_' + k, req: '', reqDate: '', code: i.code, name: i.name || itemName(i.code), uom: i.uom || itemUom(i.code), qty: Number(i.qty), remark: rem, skip: false })) };
  if (!N) { toast('Open this inside the JV Stock Issue app to fill CUIMS.'); return; }
  N.startJob(jobJson(job));
}
function retPrefix(iso) { const p = String(iso || today()).split('-'); return 'R-' + p[2] + p[1] + '-'; }
const RET_RE = /^R-\d{4}-\d{2,3}$/i;
function nextReturnNo(iso, alsoUsed) {
  const pre = retPrefix(iso), used = new Set(S.returns.map(r => String(r.no).toUpperCase()).concat((alsoUsed || []).map(x => String(x).toUpperCase())));
  let max = 0; used.forEach(n => { if (n.startsWith(pre)) { const m = n.slice(pre.length).match(/^(\d+)$/); if (m) max = Math.max(max, +m[1]); } });
  let k = max + 1; while (used.has(pre + String(k).padStart(2, '0'))) k++;
  return pre + String(k).padStart(2, '0');
}

/* ---------------- Search ---------------- */
let DATAVER = 1, SIDX = null;
function searchIndex() {
  if (SIDX && SIDX.ver === DATAVER) return SIDX.recs;
  const rd = {}; S.lines.forEach(l => { if (!(l.req in rd)) rd[l.req] = l.date; });
  const out = [];
  S.entries.forEach(e => out.push({ type: 'Issue', id: 'e' + e.id, date: entryDate(e), time: entryTime(e), store: e.store, who: rcvLabel(e.rcv) + (e.rname ? ' ' + e.rname : ''), no: e.slip, serial: e.serial || '', reqs: e.reqs || [...new Set(e.items.map(i => i.req).filter(Boolean))].join(', '), by: e.by || {}, remarks: e.remarks || '', items: e.items, kind: e.kind }));
  S.returns.forEach(r => out.push({ type: 'Return', id: 'r' + r.id, date: r.date, time: r.time, store: r.store, who: rcvLabel(r.by) + (r.byName ? ' ' + r.byName : ''), no: r.no, serial: r.serial || '', reqs: 'Against ' + r.against, by: r.enteredBy || {}, remarks: r.remarks || '', items: r.items }));
  const R0 = {}; S.lines.forEach(l => { if (l.status === 'dropped') return; (R0[l.req] = R0[l.req] || []).push(l); });
  Object.values(S.manReqs || {}).forEach(m => out.push({ type: 'Request', id: 'm' + m.req, date: m.date, time: '', store: m.store, who: (m.status === 'done' ? 'completed' : 'pending') + ' · manual record', no: m.req, serial: '', reqs: m.req, by: m.by || {}, remarks: 'manual', items: [] }));
  Object.entries(R0).forEach(([req, L]) => { const w = L.filter(l => l.status === 'waiting').length;
    out.push({ type: 'Request', id: 'q' + req, date: L[0].date, time: '', store: L[0].store, who: w ? w + ' waiting · ' + (L.length - w) + ' issued' : 'all ' + L.length + ' issued', no: req, serial: '', reqs: req, by: {}, remarks: L.some(l => l.fromFile) ? '' : 'added in app', items: L.map(l => ({ code: l.code, name: itemName(l.code), qty: l.qty, uom: itemUom(l.code), req, remark: l.status })) }); });
  out.forEach(x => { x.rdates = new Set(x.items.map(i => rd[i.req]).filter(Boolean)); x.hay = [x.type, x.date, x.date ? fmtLong(x.date) : '', x.store, x.who, x.no, x.serial, x.reqs, x.by.name, x.by.emp, x.remarks, ...x.items.map(i => i.code + ' ' + (i.name || itemName(i.code)) + ' ' + (i.remark || ''))].join(' ').toLowerCase(); x.sk = (x.date || '') + (x.time || ''); });
  out.sort((a, b) => b.sk.localeCompare(a.sk));
  SIDX = { ver: DATAVER, recs: out }; return out;
}
function searchRecords() {
  const s = ui.search, terms = s.q.toLowerCase().split(/\s+/).filter(Boolean);
  return searchIndex().filter(x => (!s.rd || (x.type === 'Issue' && x.rdates.has(s.rd)) || (x.type === 'Request' && x.date === s.rd)) && (s.type === 'all' || x.type.toLowerCase() === s.type) && (!s.from || x.date >= s.from) && (!s.to || x.date <= s.to) && (!s.store || x.store === s.store) && terms.every(t => x.hay.includes(t)));
}
function searchRecordsOld() {
  const out = [];
  S.entries.forEach(e => out.push({ type: 'Issue', id: 'e' + e.id, date: entryDate(e), time: entryTime(e), store: e.store, who: rcvLabel(e.rcv) + (e.rname ? ' ' + e.rname : ''), no: e.slip, serial: e.serial || '', reqs: e.reqs || [...new Set(e.items.map(i => i.req).filter(Boolean))].join(', '), by: e.by || {}, remarks: e.remarks || '', items: e.items, kind: e.kind }));
  S.returns.forEach(r => out.push({ type: 'Return', id: 'r' + r.id, date: r.date, time: r.time, store: r.store, who: rcvLabel(r.by) + (r.byName ? ' ' + r.byName : ''), no: r.no, serial: r.serial || '', reqs: 'Against ' + r.against, by: r.enteredBy || {}, remarks: r.remarks || '', items: r.items }));
  const s = ui.search;
  const terms = s.q.toLowerCase().split(/\s+/).filter(Boolean);
  return out.filter(x => {
    if (s.rd && x.type === 'Issue' && !x.items.some(i => reqDateOfRaw(i.req) === s.rd)) return false;
    if (s.rd && x.type === 'Return') return false;
    if (s.type !== 'all' && x.type.toLowerCase() !== s.type) return false;
    if (s.from && x.date < s.from) return false;
    if (s.to && x.date > s.to) return false;
    if (s.store && x.store !== s.store) return false;
    if (!terms.length) return true;
    const hay = [x.type, x.date, fmtLong(x.date || today()), x.store, x.who, x.no, x.serial, x.reqs, x.by.name, x.by.emp, x.remarks, ...x.items.map(i => i.code + ' ' + (i.name || '') + ' ' + (i.remark || ''))].join(' ').toLowerCase();
    return terms.every(t => hay.includes(t));
  }).sort((a, b) => (b.date + b.time).localeCompare(a.date + a.time));
}
function sResults(res) {
  const s = ui.search; let h = '';
  h += '<div class="shead"><div><h2>' + res.length.toLocaleString('en-IN') + ' results</h2><span>' + (s.q ? 'for "' + esc(s.q) + '"' : 'latest first') + '</span></div><button class="btn sm ghost" data-a="expSearch"' + (res.length ? '' : ' disabled') + '>Export</button></div>';
  if (!res.length) return h + '<div class="card pad note">Nothing found. Try a Request No, slip, serial, store or item.</div>';
  res.slice(0, 120).forEach(x => {
    if (x.type === 'Request') {
      const L = S.lines.filter(l => l.req === x.no && l.status !== 'dropped'), w = L.filter(l => l.status === 'waiting'), sl = reqSlips(x.no), m = (S.manReqs || {})[x.no];
      h += rqCard({ where: 'find', req: x.no, store: x.store, tap: !m, status: m ? (m.status === 'done' ? ['Completed', 'c-ok'] : ['Pending', 'c-gd']) : w.length ? [w.length + ' of ' + L.length + ' pending', 'c-gd'] : ['Completed', 'c-ok'],
        meta: ['requested ' + (x.date ? fmtShort(x.date) : '–'), m ? 'manual record' : L.length + ' articles'], slips: sl.length ? sl : null, left: w,
        btns: m ? '<button class="btn sm" data-a="manReqEdit" data-v="' + esc(x.no) + '">Edit</button><button class="btn sm ghost" data-a="renumReq" data-v="' + esc(x.no) + '">Renumber</button>' : '<button class="btn sm" data-a="openReq" data-v="' + esc(x.no) + '">Open request</button><button class="btn sm ghost" data-a="renumReq" data-v="' + esc(x.no) + '">Renumber</button>' });
      return;
    }
    const isRet = x.type === 'Return', e = isRet ? null : S.entries.find(z => 'e' + z.id === x.id), open = s.open === x.id;
    const man = e && e.kind === 'manual';
    h += '<div class="card rcard"><button class="main srch" data-a="sOpen" data-v="' + x.id + '"><div class="row"><span class="stag ' + (isRet ? 'ret' : man ? 'man' : 'appt') + '" style="position:static">' + (isRet ? 'Return' : man ? 'Manual slip' : 'App slip') + '</span>' + serFmt(x.serial) + '</div>' +
      '<b class="ttl">' + esc(x.store) + '</b>' + meta([esc(x.no), (x.date ? fmtShort(x.date) : '') + ' ' + esc(x.time || ''), esc(x.who), (e ? entryCount(e) : x.items.length) + ' articles']) +
      (x.reqs && !isRet ? '<div class="scrow">' + String(x.reqs).split(/\s*,\s*/).filter(Boolean).map(r => '<span class="reqno sm" data-req="' + esc(r) + '">' + esc(r) + '</span>').join('') + '</div>' : '') + '</button>' +
      (open && x.items.length ? '<div class="leftbox" style="background:var(--soft)">' + x.items.map(i => '<div class="leftrow"><span><b>' + esc(i.name || itemName(i.code)) + '</b><span class="mono">' + esc(i.code) + (i.remark ? ' · ' + esc(i.remark) : '') + '</span></span><b class="qty">' + num(i.qty) + ' ' + esc(i.uom || '') + '</b></div>').join('') + '</div>' : '') +
      (open && e ? '<div class="rqbtns"><button class="btn sm" data-a="editEntry" data-v="' + e.id + '">Edit slip</button>' + (x.reqs ? '<button class="btn sm ghost" data-a="openReq" data-v="' + esc(String(x.reqs).split(/\s*,\s*/)[0]) + '">Open request</button>' : '') + '</div>' : '') + '</div>';
  });
  if (res.length > 120) h += '<div class="note" style="text-align:center">Showing 120 of ' + res.length + '. Narrow the search or export all.</div>';
  return h;
}
function vFind() {
  const s = ui.search;
  const res = searchRecords();
  const stores = [...new Set([...S.entries.map(e => e.store), ...S.returns.map(r => r.store), ...S.lines.map(l => l.store)])].sort();
  let h = '<header class="top"><div><h1>Search</h1><div class="sub">Requests, slips and returns. Type a Request No, slip, serial, store, item or person.</div></div></header><main>';
  h += '<div class="sbox big">' + '<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"><circle cx="11" cy="11" r="7"/><path d="M20 20l-4-4"/></svg><input type="search" data-in="q" value="' + esc(s.q) + '" placeholder="Item, slip, serial, store, request…" autocomplete="off" enterkeyhint="search"></div>';
  h += '<div class="seg">' + [['all', 'All'], ['request', 'Requests'], ['issue', 'Issues'], ['return', 'Returns']].map(([k, l]) => '<button data-a="sType" data-v="' + k + '" class="' + (s.type === k ? 'on' : '') + '">' + l + '</button>').join('') + '</div>';
  h += '<label class="f fdate"><span>Request date</span><span class="fin"><input type="date" data-in="sRd" value="' + esc(s.rd || '') + '">' + (s.rd ? '<button class="fx" data-a="sRdClear" aria-label="Clear request date">' + ico('x', 14) + '</button>' : '') + '</span></label>';
  h += '<div class="note" style="margin-top:-6px">Issue date range:</div>';
  h += '<div class="grid2"><label class="f">From<input type="date" data-in="sFrom" value="' + esc(s.from) + '"></label><label class="f">To<input type="date" data-in="sTo" value="' + esc(s.to) + '"></label></div>';
  h += pickBtn('sStore', { title: 'Store', search: true, full: true, opts: [['', 'All stores']].concat(stores.map(x => [x, x])), val: s.store || '', set: v => { ui.search.store = v; render(); } }, 'Store');
  h += '<button class="stockcard lite" data-a="stockOpen"><span class="sci">' + ico('right', 18).replace('M9 6l6 6-6 6', 'M4 7h16M4 12h16M4 17h10') + '</span><span class="sct"><b>Search live stock</b><span>Any item: closing qty, needed and free</span></span>' + ico('right', 18) + '</button>';
  h += '<button class="btn full" data-a="mgOpen">Select many · delete · complete</button>';
  h += '<div id="sres">' + sResults(res) + '</div>';
  return h + '</main>';
}

/* ---------------- Settings ---------------- */
let INFO = {};
try { INFO = N ? JSON.parse(N.info()) : { version: 'browser', mode: 'online' }; } catch (e) {}
const SETPAGES = [
  ['profile', 'Profile', 'Photo, name, emp code, designation', '#E5EDFD', '#1D4ED8', '<circle cx="12" cy="8" r="4"/><path d="M4 21c1.5-4 4.5-6 8-6s6.5 2 8 6"/>'],
  ['pdf', 'PDF and signatures', 'Store name, manager signature', '#F7EFD9', '#8A6A1F', '<path d="M6 3h9l3 3v15H6z"/><path d="M9 13h6M9 17h4"/>'],
  ['stores', 'Stores and receivers', 'Project Areas, GA / E codes', '#E3F4EC', '#0B5E3D', '<path d="M3 10l9-6 9 6v10H3z"/><path d="M9 20v-6h6v6"/>'],
  ['fill', 'Filling and automation', 'Queue mode', '#FCF1DA', '#8A5A00', '<path d="M13 2L4 14h7l-1 8 9-12h-7z"/>'],
  ['cuims', 'CUIMS logins and pages', 'Issue ID, manager ID, desktop zoom', '#E3F4EC', '#0B5E3D', '<rect x="3" y="4" width="18" height="13" rx="2"/><path d="M8 21h8M12 17v4"/>'],
  ['cloud', 'Cloud backup', 'Google Drive + Sheet, restore', '#E5EDFD', '#1E3A8A', '<path d="M7 18a5 5 0 1 1 1-9.9A6 6 0 0 1 19 10a4 4 0 0 1-1 8z"/>'],
  ['data', 'Downloads and data', 'Excel exports, template, clear data', '#EFEDE8', '#3A3E45', '<path d="M12 3v12M7 10l5 5 5-5M4 21h16"/>'],
  ['security', 'Security', 'Fingerprint / PIN lock', '#FBE6E9', '#8E1B2A', '<rect x="5" y="11" width="14" height="10" rx="2"/><path d="M8 11V7a4 4 0 0 1 8 0v4"/>'],
  ['app', 'App and updates', 'Version, updates, rollback', '#F7EFD9', '#8A6A1F', '<path d="M21 12a9 9 0 1 1-3-6.7L21 8"/><path d="M21 3v5h-5"/>']
];
function initials(n) { return String(n || 'JV').trim().split(/\s+/).map(x => x[0]).slice(0, 2).join('').toUpperCase(); }
function avatar(big) { return S.me.photo ? '<img class="avatar' + (big ? ' big' : '') + '" src="' + S.me.photo + '" alt="Profile photo">' : '<span class="avatar' + (big ? ' big' : '') + '">' + esc(initials(S.me.name)) + '</span>'; }
function vSet() {
  const pg = ui.setPage;
  let h = '';
  if (!pg) {
    h += '<header class="top"><div><h1>Settings</h1></div></header><main>';
    h += '<button class="card pad tap" data-a="setPage" data-v="profile" style="display:flex;align-items:center;gap:14px">' + avatar(true) + '<span style="flex:1"><b style="font-size:19px">' + esc(S.me.name || 'Add your name') + '</b><div class="note">' + esc([S.me.desig, S.me.emp].filter(Boolean).join(' · ') || 'Tap to set up your profile') + '</div></span><span class="chev">' + ico('right', 18) + '</span></button>';
    const groups = [['Account', ['profile', 'pdf']], ['Work', ['stores', 'fill', 'cuims']], ['Data', ['cloud', 'data']], ['App', ['security', 'app']]];
    groups.forEach(([g, keys]) => {
      h += '<div class="sect">' + g + '</div><div class="card" style="overflow:hidden">';
      keys.forEach(k => { const p = SETPAGES.find(x => x[0] === k);
        h += '<button class="srow" data-a="setPage" data-v="' + k + '"><span class="ic" style="background:' + p[3] + ';color:' + p[4] + '">' + '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">' + p[5] + '</svg></span><span class="tx"><b>' + p[1] + '</b><span>' + p[2] + '</span></span><span class="chev">' + ico('right', 18) + '</span></button>'; });
      h += '</div>';
    });
    h += '<div class="note" style="text-align:center;padding:8px 0 4px">JV Stock Issue ' + esc(INFO.version || '') + ' · Built by ' + esc(S.me.builder || S.me.name || 'JV') + '</div>';
    return h + '</main>';
  }
  const P0 = SETPAGES.find(x => x[0] === pg);
  h += '<header class="top"><div><button class="btn sm ghost" data-a="setBack">‹ Settings</button><h1 style="margin-top:10px">' + P0[1] + '</h1></div></header><main>';
  if (ui.locked) h += '<button class="banner tap" data-a="lockTap" style="border:0;background:var(--goldBg);color:var(--goldInk)"><span style="display:inline-flex;gap:8px;align-items:center">' + ico('lock', 18) + '<span><b>View only.</b> Tap to unlock with fingerprint to make changes.</span></span></button>';
  h += '<fieldset ' + (ui.locked ? 'disabled ' : '') + 'style="border:0;padding:0;margin:0;min-width:0;display:flex;flex-direction:column;gap:16px">';
  if (pg === 'profile') {
    h += '<div class="card pad col" style="align-items:center;text-align:center">' + avatar(true) + '<div class="grid2" style="width:100%"><button class="btn sm" data-a="photo">Change photo</button><button class="btn sm ghost" data-a="photoDel"' + (S.me.photo ? '' : ' disabled') + '>Remove photo</button></div></div>';
    h += '<div class="card pad col"><h3>My details</h3><div class="note">Entries made through the app get these. Also printed on PDFs.</div>' +
      '<label class="f">Name<input type="text" data-set="me.name" value="' + esc(S.me.name) + '"></label>' +
      '<div class="grid2"><label class="f">Emp code<input type="text" data-set="me.emp" value="' + esc(S.me.emp) + '" autocapitalize="characters"></label><label class="f">Designation<input type="text" data-set="me.desig" value="' + esc(S.me.desig) + '"></label></div>' +
      '<label class="f">"Built by" name in the top bar<input type="text" data-set="me.builder" value="' + esc(S.me.builder || '') + '" placeholder="' + esc(S.me.name || 'Your name') + '"></label></div>';
  }
  if (pg === 'data') {
    h += '<div class="card pad col"><h3>Test mode</h3><div class="note">Try new features or practise entries without touching your real requests, slips or stock. Your real data is put aside and comes back exactly as it was. Cloud backup pauses while testing.</div><button class="btn ' + (S.testMode ? 'main' : '') + '" data-a="testToggle" type="button">' + (S.testMode ? 'Leave Test mode' : 'Turn on Test mode') + '</button>' + (S.testMode ? '<button class="btn ghost" data-a="testClear" type="button">Delete all test data</button>' : '') + '</div>';
    h += '<div class="card pad col"><h3>Data check</h3><div class="note">Finds Request No clashes, repeated items, mixed dates, incomplete rows and repeated Slip Nos, with fix buttons.</div><button class="btn" data-a="dcOpen" type="button">Run data check</button></div>';
  }
  if (pg === 'stores') h += '<div class="card pad col" style="gap:8px"><h3>Receiver names from CUIMS</h3><div class="note">6 digits = GA code, 1–5 digits = E code (you can also type GA… or E…). The app can read the exact names from the CUIMS list for every code you use.</div><button class="btn" data-a="nameLookup" data-v="*" type="button">Check all receiver names on CUIMS</button></div>';
  if (pg === 'cuims') {
    h += '<div class="card pad col"><h3>Two CUIMS logins</h3><div class="note">Issue CUIMS uses your emp ID to fill entries. Manager CUIMS has its own separate login for the live stock report.' + (INFO.mgrSeparate === false ? ' <b>Your phone\'s WebView is too old for separate logins; both share one login until Android System WebView is updated.</b>' : '') + '</div>' +
      '<label class="f">Issue page (opens after login)<input type="text" data-url="emp" value="' + esc(ui.urlEmp != null ? ui.urlEmp : INFO.urlEmp || 'https://staff.cuchd.in/frmStoreIssueReceiveLC.aspx') + '"></label>' +
      '<label class="f">Manager page: live stock report<input type="text" data-url="mgr" value="' + esc(ui.urlMgr != null ? ui.urlMgr : INFO.urlMgr || 'https://staff.cuchd.in/frmItemStatementLC.aspx') + '"></label>' +
      '<button class="btn main" data-a="saveUrls">Save pages</button><div class="note">After every login, the app goes straight to these pages. No extra clicks.</div></div>';
    let ci = {}; try { ci = N && N.credInfo ? JSON.parse(N.credInfo()) : {}; } catch (e) {}
    const cred = (w, title) => { const c = ci[w] || {}; const f = (ui.cred || {})[w] || {};
      return '<div class="card pad col"><h3>' + title + ' login</h3><div class="grid2"><label class="f">User ID<input type="text" data-cr="' + w + '|u" value="' + esc(f.u != null ? f.u : c.u || '') + '" autocomplete="off" autocapitalize="none"></label><label class="f">Password<input type="password" data-cr="' + w + '|p" value="' + esc(f.p || '') + '" placeholder="' + (c.has ? 'saved (type to change)' : '') + '" autocomplete="new-password"></label></div>' +
        '<label class="chk"><input type="checkbox" data-a="credAuto" data-v="' + w + '"' + ((f.auto != null ? f.auto : c.auto !== false) ? ' checked' : '') + '> Log in by itself (fills and taps Login)</label><div class="grid2"><button class="btn main" data-a="credSave" data-v="' + w + '">Save</button><button class="btn" data-a="credDel" data-v="' + w + '"' + (c.has || c.u ? '' : ' disabled') + '>Remove</button></div></div>'; };
    h += cred('emp', 'Issue CUIMS (your emp ID)') + cred('mgr', 'Manager CUIMS');
    h += '<div class="note">Saved only on this phone (private app storage). Never included in cloud backups or exports. If CUIMS shows a captcha, the app fills ID and password and leaves the Login tap to you.</div>';
    { const c = autoStockCfg();
      h += '<div class="card pad col"><h3>Live stock auto update</h3><label class="chk"><input type="checkbox" data-a="autoStockTog"' + (c.on ? ' checked' : '') + '> When I tap Live stock, fetch the stock report by itself</label>' +
        '<div class="note">Opens Manager CUIMS full screen, picks the store and financial year, taps SHOW, waits for the full report, exports Excel and brings it to the upload screen for you to confirm.</div>' +
        '<div class="grid2"><label class="f">Store<input type="text" data-asc="store" value="' + esc(c.store) + '"></label><label class="f">Financial year<input type="text" data-asc="fy" value="' + esc(c.fy) + '" placeholder="' + curFY() + ' (auto)"></label></div></div>'; }
    h += '<div class="card pad col"><h3>Open</h3><div class="grid2"><button class="btn" data-a="openSite" type="button">Issue CUIMS</button><button class="btn" data-a="openMgr" type="button">Manager CUIMS</button></div></div>';
    h += '<div class="card pad col"><h3>Desktop view and zoom</h3><div class="note">CUIMS always opens in desktop view. Your zoom level is remembered after reloads. Pinch to set it once.</div><button class="btn" data-a="resetZoom">Reset zoom to default</button></div>';
  }
  if (pg === 'pdf') {
    { const PT = Object.keys(REPORTS).filter(t => REPORTS[t].pdf);
    h += '<div class="card pad col" style="gap:10px"><h3>PDF reports</h3><div class="note">Headings and store name printed at the top of every PDF. You can still change them for one report in its options.</div>' +
      '<label class="f">Store name (all PDFs)<input type="text" data-pdfall="sub" value="' + esc(S.pdfStore != null ? S.pdfStore : (rptPref('counts').sub || S.me.storeName || '')) + '" placeholder="e.g. Ration Store"></label>' +
      PT.map(t => '<label class="f">Heading · ' + esc(REPORTS[t].name) + '<input type="text" data-pdfhead="' + t + '" value="' + esc(rptPref(t).title) + '"></label>').join('') +
      '<label class="chk"><input type="checkbox" data-a="pdfSignAll" data-k="sign"' + (S.pdfSign !== false ? ' checked' : '') + '> My signature box (Prepared & checked / Received & reported) on all PDFs</label>' +
      '<label class="chk"><input type="checkbox" data-a="pdfSignAll" data-k="mgr"' + (S.pdfMgr ? ' checked' : '') + '> Manager signature box on all PDFs</label></div>'; }

  h += '<div class="card pad col"><h3>Manager signature on PDFs</h3><label class="chk"><input type="checkbox" data-a="mgrToggle"' + (S.mgr.on ? ' checked' : '') + '> Add manager signature line</label>' +
    (S.mgr.on ? '<div class="grid2"><label class="f">Manager name<input type="text" data-set="mgr.name" value="' + esc(S.mgr.name) + '"></label><label class="f">Emp code<input type="text" data-set="mgr.emp" value="' + esc(S.mgr.emp || '') + '" autocapitalize="characters"></label></div><label class="f">Designation<input type="text" data-set="mgr.desig" value="' + esc(S.mgr.desig) + '"></label>' : '') + '</div>';
  }
  if (pg === 'stores') {
    const allSt = [...new Set([...(S.storeOrder || []), ...Object.keys(S.stores), ...S.lines.map(l => l.store)])].sort(byStore);
    h += '<div class="card"><div class="pad col" style="gap:4px"><h3>My store order</h3><div class="note">Used everywhere when sort is "My order". Move stores up or down.</div></div>' +
      allSt.map((st, i) => '<div class="line row" style="flex-direction:row"><b style="flex:1">' + (i + 1) + '. ' + esc(st) + '</b><button class="xbtn" data-a="moveStore" data-v="' + esc(st) + '" data-d="-1"' + (i ? '' : ' disabled') + ' aria-label="Move up">' + ico('up', 18) + '</button><button class="xbtn" data-a="moveStore" data-v="' + esc(st) + '" data-d="1"' + (i < allSt.length - 1 ? '' : ' disabled') + ' aria-label="Move down">' + ico('down', 18) + '</button></div>').join('') + '</div>';
  const stores = Object.keys(S.stores).sort();
  h += '<div class="card"><div class="pad col" style="gap:4px"><h3>Stores and receivers</h3><div class="note">Store = exact CUIMS Project Area. Receiver = 6 digits; change anytime. ' + (S.areas.length ? S.areas.length + ' Project Areas known from CUIMS.' : 'Open CUIMS once to load the Project Area list.') + '</div></div>';
  stores.forEach(s => {
    const v = S.stores[s].rcv || ''; const bad = v && !validRcv(v);
    const known = !S.areas.length || S.areas.some(a => a.toUpperCase() === s);
    h += '<div class="line"><div class="row"><b>' + esc(s) + '</b><button class="btn sm ghost" data-a="rmStore" data-v="' + esc(s) + '">Remove</button></div>' + (known ? '' : '<div class="err">Not in the CUIMS Project Area list</div>') +
      '<div class="grid2"><input type="text" inputmode="numeric" maxlength="6" data-store-rcv="' + esc(s) + '" value="' + esc(v) + '" placeholder="6-digit receiver" class="mono' + (bad ? ' bad' : '') + '"><input type="text" data-store-name="' + esc(s) + '" value="' + esc(S.stores[s].rname || rname(v)) + '" placeholder="Receiver name"></div></div>';
  });
  h += '<div class="pad col"><input type="text" id="newStore" list="areaList" placeholder="Add store: type or pick Project Area" autocapitalize="characters">' + areaDatalist() + '<button class="btn" data-a="addStore">+ Add store</button></div></div>';
  }
  if (pg === 'fill') {
  h += '<div class="card pad col"><h3>Kitty mode (spy mode)</h3><label class="chk"><input type="checkbox" data-a="funToggle"' + (S.funMode ? ' checked' : '') + '> Hide all work behind Kitty while CUIMS runs</label><div class="note">For issues, returns, verify, linking serials and name checks. The CUIMS screen shows only a kitten game, with no words about stock or entries, and no notifications. Peek, Hide, errors and leaving need your fingerprint or phone PIN. When everything is done, Kitty waits until you tap Close the door and unlock.</div></div></div>';
  h += '<div class="card pad col"><h3>Auto submit</h3><label class="chk"><input type="checkbox" data-a="autoSubToggle"' + (S.autoSubmit ? ' checked' : '') + '> Tap SUBMIT automatically when the recheck matches 100%</label><div class="note">A 4-second countdown with a Stop button appears first. You can also switch this in the CUIMS bar.</div></div>';
  h += '<div class="card pad col"><h3>Filling</h3><label class="chk"><input type="checkbox" data-a="queueToggle"' + (S.queue ? ' checked' : '') + '> Queue mode: after each submit, fill the next request automatically</label></div>';
    h += queueBox();
  }
  if (pg === 'cloud') {
  h += '<div class="card pad col"><h3>Cloud backup (Google Drive + Sheet)</h3><label class="f">Apps Script web app URL<input type="text" data-set="sync.url" value="' + esc(S.sync.url) + '" placeholder="https://script.google.com/macros/s/…/exec"></label>' +
    '<div class="card pad col" style="gap:8px;background:var(--soft);box-shadow:none"><div class="row"><b>Paper photos</b><span class="note">' + allPaper().filter(x => x.p.cloud).length + ' of ' + allPaper().length + ' backed up</span></div><div class="note">Saved in your Drive folder "JV Stock Issue backups / Paper photos / month", named by date, Request No and store. Full photo quality is kept.</div><button class="btn sm" data-a="photoSync" type="button"' + (S.sync.url ? '' : ' disabled') + '>Back up photos now</button></div>' +
    '<label class="f">Upload changes after</label>' + pickBtn('syncDelay', { title: 'Upload changes after', full: true, opts: [['0', 'Right away'], ['1', '1 minute'], ['5', '5 minutes'], ['15', '15 minutes'], ['30', '30 minutes'], ['60', '1 hour']], val: String(S.sync.delay != null ? S.sync.delay : 5), set: v => { S.sync.delay = parseFloat(v); writeLocal(); render(); } }) + '<div class="note">Everything is saved on the phone instantly. Cloud upload waits this long after a change (and always happens when you leave the app).</div>' +
    '<label class="chk"><input type="checkbox" data-a="syncAuto"' + (S.sync.auto ? ' checked' : '') + '> Back up automatically after changes</label>' +
    '<div class="note">' + (S.sync.at ? 'Last backup ' + fmtDT(S.sync.at) : 'Not backed up yet') + '</div>' +
    '<div class="grid2"><button class="btn" data-a="syncNow"' + (S.sync.url ? '' : ' disabled') + '>Back up now</button><button class="btn main" data-a="backups"' + (S.sync.url ? '' : ' disabled') + '>Manage backups</button></div></div>';
  }
  if (pg === 'data') {
  h += '<div class="card pad col"><h3>Downloads</h3><div class="grid2">' +
    [['expRequests', 'Requests register'], ['expEntries', 'Entries log'], ['expItems', 'Entry items'], ['expPendXlsx', 'Pending (Excel)'], ['expPendPdf', 'Pending (PDF)'], ['expStock', 'Stock now'], ['expReturns', 'Returns'], ['expAll', 'Full backup']].map(([a, l]) => '<button class="btn sm" data-a="' + a + '">' + l + '</button>').join('') +
    '</div><button class="btn sm ghost" data-a="template">Download data template</button></div>';
  h += '<div class="card pad col"><h3>Data</h3><div class="note">' + S.lines.length + ' request articles · ' + S.entries.length + ' issue entries · ' + S.returns.length + ' returns · ' + Object.keys(S.stock).length + ' stock items</div><button class="btn warn" data-a="wipe">Clear all data on this phone</button></div>';
  }
  if (pg === 'security') {
  h += '<div class="card pad col"><h3>Security</h3><label class="chk"><input type="checkbox" data-a="lockToggle"' + (INFO.lock ? ' checked' : '') + '> Fingerprint / PIN lock when opening</label></div>';
  }
  if (pg === 'app') {
  const ui2 = S.updateInfo;
  h += '<div class="card pad col" id="upd"><h3>App updates</h3><div class="note">Installed ' + esc(INFO.version || '–') + '. ' + (ui2 ? (ui2.newer ? 'New version ' + esc(ui2.tag) + ' is available.' : 'You have the latest version (checked ' + fmtDT(ui2.at) + ').') : '') + '</div>' +
    '<div class="grid2"><button class="btn" data-a="checkUpdate">Check now</button><button class="btn main" data-a="installUpdate"' + (ui2 && ui2.newer ? '' : ' disabled') + '>Install update</button></div>' +
    '<div class="note">Screens update by themselves from GitHub. If a new screen version misbehaves, switch to the built-in version.</div>' +
    '<div class="seg"><button data-a="mode" data-v="online" class="' + (INFO.mode !== 'bundled' ? 'on' : '') + '">Latest online</button><button data-a="mode" data-v="bundled" class="' + (INFO.mode === 'bundled' ? 'on' : '') + '">Built-in (rollback)</button></div></div>';
  }
  return h + '</fieldset></main>';
}

/* ---------------- exports ---------------- */
function saveBlobB64(b64, name, mime) {
  if (N) { const r = N.saveFile(b64, name, mime); if (r !== 'ok') toast('Could not save: ' + r); return; }
  const a = document.createElement('a'); a.href = 'data:' + mime + ';base64,' + b64; a.download = name; a.click();
}
const XMIME = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet';
function saveWb(sheets, name) {
  if (!window.XLSX) { toast('Excel tools not loaded yet. Check internet and try again.'); return; }
  const wb = XLSX.utils.book_new();
  sheets.forEach(([n, rows]) => XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(rows.length ? rows : [{ Note: 'No data' }]), n));
  saveBlobB64(XLSX.write(wb, { type: 'base64', bookType: 'xlsx' }), name, XMIME);
}
function rowsRequests() {
  return requests().map(r => {
    const iss = r.lines.filter(l => l.status === 'issued'), w = r.lines.filter(l => l.status === 'waiting');
    const slips = [...new Set(iss.flatMap(l => l.issued.map(x => x.slip)))];
    return { 'Request No': r.req, Store: r.store, 'Request date': fmtLong(r.date), Source: r.src === 'old' ? 'Earlier pending' : 'New', Articles: r.lines.length, Issued: iss.length, Pending: w.length,
      Status: !w.length ? 'Complete' : iss.length ? 'Partial ' + iss.length + ' of ' + r.lines.length : 'Pending', 'Slips used': slips.join(', ') };
  });
}
function rowsEntries(list) {
  return (list || S.entries).map(e => ({ Date: fmtLong(entryDate(e)), Time: entryTime(e), 'Slip No': e.slip, 'Serial No': e.serial || '', Store: e.store, 'Issued to': rcvLabel(e.rcv), 'Receiver name': e.rname || '',
    'Request Nos': e.reqs || [...new Set(e.items.map(i => i.req).filter(Boolean))].join(', '), Items: e.items.length, Remarks: e.remarks || '', 'Entered by': (e.by || {}).name || '', 'Emp code': (e.by || {}).emp || '', Type: e.kind === 'manual' ? 'Manual' : 'App' }));
}
function rowsItems() {
  const out = [];
  S.entries.forEach(e => e.items.forEach(i => out.push({ Date: fmtLong(entryDate(e)), 'Slip No': e.slip, 'Serial No': e.serial || '', Store: e.store, 'Request No': i.req || '', 'Item code': i.code, Item: i.name || itemName(i.code), Qty: Number(i.qty), UOM: i.uom || itemUom(i.code), Remark: i.remark || '' })));
  return out;
}
function rowsPending() {
  return S.lines.filter(isPending).sort((a, b) => a.store.localeCompare(b.store) || a.date.localeCompare(b.date))
    .map(l => ({ Store: l.store, 'Request No': l.req, 'Item code': l.code, Item: itemName(l.code), Qty: l.qty, UOM: itemUom(l.code), 'Requested on': fmtLong(l.date), 'Days pending': days(l.date), 'Earlier slips': [l.earlier, ...l.issued.map(x => x.slip)].filter(Boolean).join(', ') }));
}
function rowsStock() { return Object.entries(S.stock).map(([c, s]) => ({ 'Item code': c, Item: s.name, UOM: s.uom, 'Stock now': s.qty })); }
function rowsReturns() {
  const out = [];
  S.returns.forEach(r => r.items.forEach(i => out.push({ Date: fmtLong(r.date), Time: r.time, 'Return No': r.no, 'Against Issue No': r.against, 'Serial No': r.serial || '', Store: r.store, 'Returned by': rcvLabel(r.by), Name: r.byName || '', 'Item code': i.code, Item: i.name || itemName(i.code), Qty: Number(i.qty), UOM: i.uom || itemUom(i.code), 'Item remark': i.remark || '', Remarks: r.remarks || '', 'Entered by': (r.enteredBy || {}).name || '', 'Emp code': (r.enteredBy || {}).emp || '' })));
  return out;
}
function rowsAllLines() { return S.lines.map(l => ({ 'Request No': l.req, Store: l.store, 'Request date': fmtLong(l.date), 'Item code': l.code, Item: itemName(l.code), Qty: l.qty, Status: l.status, Source: l.src, Receiver: l.rcv || '', 'Issued in': l.issued.map(x => x.slip + (x.serial ? ' #' + x.serial : '')).join(', '), 'Earlier slips': l.earlier || '' })); }
function template() {
  saveWb([['New Requests', [{ 'Request No': 'EX-1201', Store: 'LC MESS', 'Request date': '12-10-2026', 'Item code': 'KM-187', Qty: 50, 'Receiver (optional)': '', 'Slip No (optional)': 'JV/920' }]],
    ['Old Pending', [{ 'Request No': 'EX-1150', Store: 'LC MESS', 'Request date': '09-10-2026', 'Item code': 'GR-887', 'Qty pending': 5, 'Earlier Slip Nos (optional)': 'JV/880' }]]], 'JV-Stock-Issue-template.xlsx');
}

/* ---------------- PDFs ---------------- */
let LOGO = null;
(function loadLogo() { try { const im = new Image(); im.onload = () => { try { const c = document.createElement('canvas'); c.width = c.height = 128; c.getContext('2d').drawImage(im, 0, 0, 128, 128); LOGO = c.toDataURL('image/png'); } catch (e) {} }; im.src = 'icon.png'; } catch (e) {} })();
function pdfDoc(landscape) {
  if (!window.jspdf) { toast('PDF tools not loaded yet. Check internet and try again.'); return null; }
  return new window.jspdf.jsPDF({ orientation: landscape ? 'landscape' : 'portrait', unit: 'mm', format: 'a4' });
}
const NAVY = [15, 23, 42], GOLD = [201, 162, 75], INK = [20, 22, 26];
function pdfHead(doc, title, sub, chips) {
  const W = doc.internal.pageSize.getWidth();
  doc.setFillColor(...NAVY); doc.rect(0, 0, W, 26, 'F');
  doc.setFillColor(...GOLD); doc.rect(0, 26, W, 1.2, 'F');
  let x = 12;
  if (LOGO) { try { doc.addImage(LOGO, 'PNG', 12, 5, 16, 16); x = 32; } catch (e) {} }
  doc.setTextColor(255, 255, 255); doc.setFont('helvetica', 'bold'); doc.setFontSize(15); doc.text(title, x, 12.5);
  doc.setFont('helvetica', 'normal'); doc.setFontSize(9); doc.setTextColor(201, 206, 214); doc.text(sub, x, 19);
  doc.setTextColor(...GOLD); doc.setFont('helvetica', 'bold'); doc.setFontSize(9); doc.text('JV STOCK ISSUE', W - 12, 12.5, { align: 'right' });
  doc.setFont('helvetica', 'normal'); doc.setTextColor(201, 206, 214); doc.text('Built by ' + (S.me.builder || S.me.name || 'JV'), W - 12, 19, { align: 'right' });
  let cx = 12; const cy = 32;
  doc.setFontSize(8.5);
  (chips || []).forEach(([k, v]) => {
    doc.setFont('helvetica', 'normal'); doc.setFontSize(7); const kw = doc.getTextWidth(String(k).toUpperCase());
    doc.setFont('helvetica', 'bold'); doc.setFontSize(9); const vw = doc.getTextWidth(String(v));
    const w = kw + vw + 11;
    doc.setFillColor(247, 239, 217); doc.roundedRect(cx, cy, w, 8, 4, 4, 'F');
    doc.setTextColor(138, 106, 31); doc.setFont('helvetica', 'normal'); doc.setFontSize(7); doc.text(String(k).toUpperCase(), cx + 4, cy + 5.2);
    doc.setTextColor(...INK); doc.setFont('helvetica', 'bold'); doc.setFontSize(9); doc.text(String(v), cx + 4 + kw + 3, cy + 5.4);
    cx += w + 3;
  });
  return cy + 13;
}
function pdfSign(doc, showMe, showMgr) {
  if (showMe === undefined) showMe = true; if (showMgr === undefined) showMgr = S.mgr.on;
  const W = doc.internal.pageSize.getWidth(), H = doc.internal.pageSize.getHeight();
  let y = (doc.lastAutoTable ? doc.lastAutoTable.finalY : 40) + 10;
  if (y + 30 > H - 13) { doc.addPage(); y = 20; }
  const box = (x, label, name, sub) => {
    doc.setDrawColor(232, 229, 223); doc.setFillColor(250, 249, 246); doc.roundedRect(x, y, 80, 28, 3, 3, 'FD');
    doc.setFontSize(8); doc.setTextColor(138, 106, 31); doc.setFont('helvetica', 'bold'); doc.text(label.toUpperCase(), x + 5, y + 6);
    doc.setDrawColor(180); doc.line(x + 5, y + 17, x + 75, y + 17);
    doc.setTextColor(...INK); doc.setFont('helvetica', 'bold'); doc.setFontSize(9.5); doc.text(name || ' ', x + 5, y + 22.5);
    doc.setFont('helvetica', 'normal'); doc.setFontSize(8); doc.setTextColor(107, 111, 118); doc.text(sub || ' ', x + 5, y + 26.2);
  };
  if (showMe) box(12, 'Prepared & checked by', S.me.name || '', [S.me.emp, S.me.desig].filter(Boolean).join(' · '));
  if (showMgr) box(showMe ? W - 92 : 12, 'Manager', S.mgr.name || '', [S.mgr.emp, S.mgr.desig].filter(Boolean).join(' · '));
}
function pdfFoot(doc, label) {
  const n = doc.getNumberOfPages(), W = doc.internal.pageSize.getWidth(), H = doc.internal.pageSize.getHeight();
  for (let i = 1; i <= n; i++) {
    doc.setPage(i); doc.setDrawColor(...GOLD); doc.setLineWidth(0.4); doc.line(12, H - 11, W - 12, H - 11);
    doc.setFontSize(7.5); doc.setTextColor(107, 111, 118);
    doc.text('JV Stock Issue · ' + label + ' · ' + (S.me.storeName || '') + ' · generated ' + fmtDT(new Date().toISOString()), 12, H - 6.5);
    doc.text('Page ' + i + ' of ' + n, W - 12, H - 6.5, { align: 'right' });
  }
}
function pdfSave(doc, name) { saveBlobB64(doc.output('datauristring').split(',')[1], name, 'application/pdf'); }
const TSTYLE = { headStyles: { fillColor: NAVY, textColor: 255, fontStyle: 'bold', fontSize: 8.5, cellPadding: { top: 2.2, bottom: 2.2, left: 1.8, right: 1.8 }, valign: 'middle' }, styles: { fontSize: 8.5, cellPadding: { top: 1.6, bottom: 1.6, left: 1.8, right: 1.8 }, lineColor: [232, 229, 223], lineWidth: 0.2, textColor: INK, valign: 'middle' }, alternateRowStyles: { fillColor: [250, 249, 246] }, margin: { left: 12, right: 12 } };
function issueGroups(list) {
  const G = new Map();
  list.forEach(e => {
    const reqs = [...new Set(e.items.map(i => i.req).filter(Boolean))];
    const keys = reqs.length ? reqs : (e.reqs ? e.reqs.split(/\s*,\s*/).filter(Boolean) : ['—' + e.slip]);
    keys.forEach(k => {
      if (!G.has(k)) G.set(k, { req: k.startsWith('—') ? '' : k, store: e.store, to: new Set(), slips: [], items: [], remarks: new Set(), by: new Set(), date: entryDate(e) });
      const g = G.get(k);
      g.to.add(rcvLabel(e.rcv) + (e.rname ? ' ' + e.rname : ''));
      g.slips.push({ slip: e.slip, serial: e.serial || '', time: entryTime(e) });
      e.items.filter(i => !reqs.length || i.req === k).forEach(i => g.items.push(Object.assign({ slip: e.slip }, i)));
      g.count = (g.count || 0) + (e.items.length ? e.items.filter(i => !reqs.length || i.req === k).length : (Number(e.count) || 0));
      if (e.remarks) g.remarks.add(e.remarks); if (e.kind === 'manual') g.remarks.add('Manual');
      if ((e.by || {}).name) g.by.add(e.by.name + (e.by.emp ? ' (' + e.by.emp + ')' : ''));
    });
  });
  return [...G.values()].sort((a, b) => byStore(a.store, b.store) || a.req.localeCompare(b.req, undefined, { numeric: true }));
}
function pdfIssue() {
  const d = ui.reg.date, list = S.entries.filter(e => entryDate(e) === d);
  const doc = pdfDoc(true); if (!doc) return;
  const G = issueGroups(list);
  const items = list.reduce((s, e) => s + e.items.length, 0);
  const y0 = pdfHead(doc, 'Daily Issue Register', (S.me.storeName || 'Store') + ' · Issue · Department · Offline · HOSTEL MESS (GA)', [['Date', fmtLong(d)], ['Requests', G.length], ['Slips', list.length], ['Items', items]]);
  doc.autoTable(Object.assign({}, TSTYLE, { startY: y0,
    head: [['#', 'Request No', 'Store', 'Issued to', 'Slip No', 'Serial No', 'Time', 'Items', 'Remarks', 'Entered by']],
    body: G.map((g, i) => [i + 1, g.req || '–', g.store, [...g.to].join('\n'), g.slips.map(x => x.slip).join('\n'), g.slips.map(x => x.serial || '______').join('\n'), g.slips.map(x => x.time).join('\n'), g.items.length, [...g.remarks].join(', ') || '–', [...g.by].join('\n')]),
    columnStyles: { 0: { cellWidth: 8, halign: 'center' }, 1: { fontStyle: 'bold' }, 2: { fontStyle: 'bold' }, 4: { textColor: [30, 58, 138], fontStyle: 'bold' }, 5: { textColor: [11, 94, 61], fontStyle: 'bold' }, 7: { halign: 'center' } } }));
  if (ui.reg.items) G.forEach(g => {
    doc.autoTable(Object.assign({}, TSTYLE, { startY: doc.lastAutoTable.finalY + 6, headStyles: { fillColor: [30, 41, 59], textColor: 255, fontStyle: 'bold', fontSize: 8.5 },
      head: [[{ content: 'Request ' + (g.req || '–') + '   ·   ' + g.store + '   ·   ' + [...g.to].join(', ') + '   ·   Slips ' + g.slips.map(x => x.slip + (x.serial ? ' #' + x.serial : '')).join(', '), colSpan: 7 }], ['S.No', 'Slip No', 'Item code', 'Item', 'UOM', 'Qty', 'Item remarks']],
      body: g.items.map((x, i) => [i + 1, x.slip, x.code, x.name || itemName(x.code), x.uom || itemUom(x.code), num(x.qty), x.remark || '–']) }));
  });
  pdfSign(doc); pdfFoot(doc, 'Issue Register'); pdfSave(doc, 'Issue-Register-' + d + '.pdf');
}
function pdfReturn() {
  const d = ui.reg.date, list = S.returns.filter(x => x.date === d).sort((a, b) => byStore(a.store, b.store) || (a.time || '').localeCompare(b.time || ''));
  const doc = pdfDoc(false); if (!doc) return;
  const items = list.reduce((s, r) => s + r.items.length, 0);
  const y0 = pdfHead(doc, 'Daily Return Register', (S.me.storeName || 'Store') + ' · Return · Department · Against Issue No 1111', [['Date', fmtLong(d)], ['Returns', list.length], ['Items', items]]);
  doc.autoTable(Object.assign({}, TSTYLE, { startY: y0,
    head: [['#', 'Return No', 'Store', 'Returned by', 'Date & time', 'Against', 'Serial No', 'Items', 'Entered by']],
    body: list.map((r, i) => [i + 1, r.no, r.store, rcvLabel(r.by) + (r.byName ? '\n' + r.byName : ''), fmtShort(r.date) + ' ' + (r.time || ''), r.against, r.serial || '______', r.items.length, ((r.enteredBy || {}).name || '') + ((r.enteredBy || {}).emp ? '\n' + r.enteredBy.emp : '')]),
    columnStyles: { 0: { cellWidth: 8, halign: 'center' }, 1: { fontStyle: 'bold' }, 2: { fontStyle: 'bold' }, 6: { textColor: [11, 94, 61], fontStyle: 'bold' }, 7: { halign: 'center' } } }));
  list.forEach(r => {
    doc.autoTable(Object.assign({}, TSTYLE, { startY: doc.lastAutoTable.finalY + 6, headStyles: { fillColor: [30, 41, 59], textColor: 255, fontStyle: 'bold', fontSize: 8.5 },
      head: [[{ content: r.no + '   ·   ' + r.store + '   ·   Returned by ' + rcvLabel(r.by) + '   ·   Serial ' + (r.serial || '____') + (r.remarks ? '   ·   ' + r.remarks : ''), colSpan: 6 }], ['S.No', 'Item code', 'Item', 'UOM', 'Qty', 'Item remarks']],
      body: r.items.map((x, i) => [i + 1, x.code, x.name || itemName(x.code), x.uom || itemUom(x.code), num(x.qty), x.remark || '–']) }));
  });
  pdfSign(doc); pdfFoot(doc, 'Return Register'); pdfSave(doc, 'Return-Register-' + d + '.pdf');
}
function pdfPending() {
  const rows = rowsPending(); const doc = pdfDoc(true); if (!doc) return;
  const stores = new Set(rows.map(r => r.Store)).size;
  const y0 = pdfHead(doc, 'Pending Report', (S.me.storeName || 'Store') + ' · articles waiting for stock', [['Date', fmtLong(today())], ['Stores', stores], ['Articles', rows.length]]);
  doc.autoTable(Object.assign({}, TSTYLE, { startY: y0,
    head: [['Store', 'Request No', 'Item code', 'Item', 'Qty', 'UOM', 'Requested on', 'Days', 'Earlier slips']],
    body: rows.sort((a, b) => byStore(a.Store, b.Store)).map(r => [r.Store, r['Request No'], r['Item code'], r.Item, r.Qty, r.UOM, r['Requested on'], r['Days pending'], r['Earlier slips']]),
    columnStyles: { 0: { fontStyle: 'bold' }, 7: { halign: 'center', textColor: [142, 27, 42], fontStyle: 'bold' } } }));
  pdfSign(doc); pdfFoot(doc, 'Pending'); pdfSave(doc, 'Pending-' + today() + '.pdf');
}

/* ---------------- tasks ---------------- */
const BUILTIN_TASKS = [
  ['count', 'Daily Count Cycle', 'Count your list · any time, many times'],
  ['stock', 'Upload fresh stock', 'CUIMS stock report'],
  ['requests', "Upload today's requests", 'Requests sheet'],
  ['backup', 'Cloud backup', 'Back up to Google Drive']
];
function taskList() { return BUILTIN_TASKS.concat((S.customTasks || []).map(t => [t.id, t.title, 'Your task'])); }
function autoDone(id, d) {
  if (id === 'count') return (S.counts || []).some(c => c.date === d && c.status === 'done');
  if (id === 'stock') return !!(S.stockAt && isoOf(new Date(S.stockAt)) === d);
  if (id === 'requests') return S.lines.some(l => l.date === d);
  if (id === 'backup') return !!(S.sync.at && isoOf(new Date(S.sync.at)) === d);
  return false;
}
function taskStatus(id, d) {
  const m = ((S.taskLog || {})[d] || {})[id];
  if (m && m.status === 'done') return 'done';
  if (m && m.status === 'skip') return 'skip';
  if (autoDone(id, d)) return 'done';
  return d < today() ? 'notdone' : 'pending';
}
const TSTAT = { done: ['Done', 'c-ok'], pending: ['Pending', 'c-gd'], notdone: ['Not done', 'c-no'], skip: ['Skipped', 'c-gy'] };
function tasksCard() {
  const d = today(), L = taskList();
  const done = L.filter(t => taskStatus(t[0], d) === 'done').length;
  const open = !!(S.uiPrefs || {}).tasksOpen;
  let h = '<div class="card taskcard" style="overflow:hidden"><div class="row" style="padding:14px 12px 10px 18px"><button class="tmain thead" data-a="tasksTog" aria-expanded="' + open + '"><b class="ttl">Today\'s tasks</b><span>' + done + ' of ' + L.length + ' done' + (done === L.length ? ' · all clear' : '') + '</span></button><button class="btn sm ghost" data-a="taskLog">Log</button><button class="xbtn" data-a="tasksTog" aria-label="' + (open ? 'Collapse' : 'Expand') + ' tasks">' + ico(open ? 'up' : 'down', 18) + '</button></div>';
  h += '<div class="bar" style="margin:0 18px ' + (open ? '6px' : '16px') + '"><div style="width:' + Math.round(done / L.length * 100) + '%;background:linear-gradient(90deg,#10B981,#34D399)"></div></div>';
  if (!open) return h + '</div>';
  L.forEach(([id, title, sub]) => {
    const st = taskStatus(id, d);
    h += '<div class="line" style="flex-direction:row;align-items:center;gap:12px"><button class="tcheck' + (st === 'done' ? ' on' : '') + '" data-a="taskTog" data-v="' + esc(id) + '" aria-label="Mark ' + esc(title) + ' done">' + (st === 'done' ? '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12.5l4.5 4.5L19 7.5"/></svg>' : '') + '</button>' +
      '<button class="tmain" data-a="taskOpen" data-v="' + esc(id) + '"><b>' + esc(title) + '</b><span>' + esc(sub) + '</span></button>' + pill(TSTAT[st][0], TSTAT[st][1]) + '</div>';
  });
  return h + '</div>';
}
function vTaskLog() {
  const L = taskList();
  const daysSet = new Set(Object.keys(S.taskLog || {})); (S.counts || []).forEach(c => daysSet.add(c.date)); daysSet.add(today());
  const ds = [...daysSet].sort().reverse().slice(0, 60);
  let h = '<header class="top"><div><button class="btn sm ghost" data-a="back">‹ Back</button><h1 style="margin-top:10px">Task log</h1><div class="sub">Every day, every task: done, pending or not done.</div></div></header><main>';
  h += '<div class="card pad col"><b>Add your own daily task</b><div class="grid2"><input type="text" data-tk="new" value="' + esc(ui.newTask || '') + '" placeholder="e.g. Check expiry dates"><button class="btn" data-a="taskAdd">Add task</button></div>' +
    ((S.customTasks || []).length ? (S.customTasks.map(t => '<div class="row" style="padding:4px 0"><span>' + esc(t.title) + '</span><button class="xbtn" data-a="taskDel" data-v="' + esc(t.id) + '" aria-label="Delete task">' + ico('x', 16) + '</button></div>').join('')) : '') + '</div>';
  ds.forEach(d => {
    const done = L.filter(t => taskStatus(t[0], d) === 'done').length;
    h += '<div class="card" style="overflow:hidden"><div class="pad row" style="padding-bottom:6px"><b>' + fmtLong(d) + (d === today() ? ' · Today' : '') + '</b>' + pill(done + ' of ' + L.length, done === L.length ? 'c-ok' : d < today() ? 'c-no' : 'c-gd') + '</div>' +
      L.map(([id, title]) => { const st = taskStatus(id, d), m = ((S.taskLog || {})[d] || {})[id];
        return '<div class="line" style="flex-direction:row;align-items:center;justify-content:space-between;padding:10px 18px"><span>' + esc(title) + (m && m.at ? '<div class="meta"><span>' + fmtDT(m.at) + (m.by ? ' · ' + esc(m.by) : '') + '</span></div>' : '') + '</span>' + pill(TSTAT[st][0], TSTAT[st][1]) + '</div>'; }).join('') + '</div>';
  });
  return h + '</main>';
}

/* ---------------- Daily Count Cycle ---------------- */
function seededPick(arr, n, seed) {
  let x = 0; for (const ch of seed) x = (x * 31 + ch.charCodeAt(0)) >>> 0;
  const rnd = () => { x ^= x << 13; x >>>= 0; x ^= x >> 17; x ^= x << 5; x >>>= 0; return x / 4294967296; };
  const a = arr.slice(); for (let i = a.length - 1; i > 0; i--) { const j = Math.floor(rnd() * (i + 1)); [a[i], a[j]] = [a[j], a[i]]; }
  return a.slice(0, n);
}
const COUNT_EXCL = { prefixes: ['VEG-'], words: ['CYLINDER', 'LPG', 'GAS', 'MILK', 'CURD', 'DAHI', 'PANEER', 'BUTTER', 'CHEESE', 'CREAM', 'GHEE', 'YOGURT', 'YOGHURT', 'KHOYA', 'LASSI', 'CHAACH', 'CHHACH'] };
function countExcl() { S.countExcl = S.countExcl || JSON.parse(JSON.stringify(COUNT_EXCL)); return S.countExcl; }
function excluded(code) {
  const ex = countExcl(), c = String(code).toUpperCase(), n = String((S.stock[code] || {}).name || '').toUpperCase();
  return ex.prefixes.some(p => p && c.startsWith(p.toUpperCase())) || ex.words.some(w => w && new RegExp('\\b' + w.toUpperCase().replace(/[^A-Z0-9 ]/g, '') + '\\b').test(n));
}
function countLocked(c) { return c && (c.status === 'done' || c.status === 'old'); }
function countRetire() {
  S.counts = S.counts || []; let ch = false;
  S.counts = S.counts.filter(c => {
    if ((c.status === 'open' || c.status === 'draft') && c.mode !== 'fixed' && c.mode !== 'emp') {
      const has = c.items.some(i => (i.physical !== '' && i.physical != null) || (i.variants && i.variants.length));
      ch = true; if (!has) return false; c.status = 'old';
    }
    return true;
  });
  if (ch) save(true);
}
function countDraft() { countRetire(); return S.counts.filter(c => (c.status === 'open' || c.status === 'draft') && c.mode === 'fixed').sort((a, b) => String(b.startedAt || b.date).localeCompare(String(a.startedAt || a.date)))[0] || null; }
function todayCount() { return countDraft(); }
function countSaved() { return (S.counts || []).filter(c => c.status === 'done' && c.mode !== 'emp').sort((a, b) => String(b.doneAt || b.date).localeCompare(String(a.doneAt || a.date))); }
function countPick() {
  S.countMode = 'fixed';
  S.countList = (S.countList || []).map(countKey); const L = S.countList.filter(k => S.stock[k]);
  if (!L.length) { ui.clWhy = (S.countList || []).length ? 'none' : 'empty'; return null; }
  const per = Math.max(0, parseInt(S.countPerDay, 10) || 0); let pick = L;
  if (per && per < L.length) { const done = countSaved().filter(x => x.mode === 'fixed').length; const st = (done * per) % L.length; pick = L.slice(st).concat(L.slice(0, st)).slice(0, per); }
  return pick;
}
function lastCounted(code) {
  for (const c of countSaved()) { const it = c.items.find(i => i.code === code && i.physical !== '' && i.physical != null); if (it) return it; }
  return null;
}
function newCount(from) {
  const pick = countPick(); if (!pick) return null;
  const src = from && from !== 'recent' && from !== 'blank' ? (S.counts || []).find(x => String(x.id) === String(from)) : null;
  const c = { id: nid(), date: today(), status: 'draft', mode: 'fixed', listSig: countListSig(), startedAt: new Date().toISOString(), by: meTag(), stockAt: S.stockAt, fill: src ? 'copy' : from === 'recent' ? 'recent' : 'blank', from: src ? src.id : null,
    items: pick.map(k => { const it = { code: k, name: S.stock[k].name, uom: S.stock[k].uom, system: S.stock[k].qty, physical: '' };
      const o = src ? src.items.find(i => i.code === k) : from === 'recent' ? lastCounted(k) : null;
      if (o) { it.physical = o.physical == null ? '' : o.physical; if (o.variants && o.variants.length) it.variants = JSON.parse(JSON.stringify(o.variants)); }
      return it; }) };
  if (src) src.items.forEach(o => { if (!c.items.some(i => i.code === o.code) && S.stock[o.code]) c.items.push({ code: o.code, name: S.stock[o.code].name, uom: S.stock[o.code].uom, system: S.stock[o.code].qty, physical: o.physical, variants: o.variants ? JSON.parse(JSON.stringify(o.variants)) : undefined }); });
  S.counts = S.counts || []; S.counts.push(c); save(); return c;
}
function countLive(c) {
  if (!c || countLocked(c)) return;
  c.items.forEach(i => { const st = S.stock[i.code]; if (st) { i.system = st.qty; i.name = st.name; i.uom = st.uom; } });
  c.stockAt = S.stockAt;
}
function openCountCycle() {
  ui.drawer = false; ui.clWhy = null;
  const d = countDraft();
  if (d) { ui.countId = d.id; ui.view = 'count'; } else ui.view = 'countStart';
  render(); window.scrollTo(0, 0);
}
function countPend(code) { const L = S.lines.filter(l => l.code === code && l.status === 'waiting' && !S.hold[l.id] && l.date <= today()); return { L, qty: Math.round(L.reduce((n, l) => n + (Number(l.qty) || 0), 0) * 1000) / 1000 }; }
function countPendOpen(c) { return c.items.map((i, idx) => ({ i, idx, P: countPend(i.code) })).filter(x => x.P.L.length && !x.i.pendKeep); }
function countPendBox(i, idx, open) {
  if (!open) return '';
  const P = countPend(i.code); if (!P.L.length) return '';
  const reqs = P.L.slice(0, 3).map(l => esc(l.req) + ' ' + esc(l.store) + ' (' + num(l.qty) + ')').join(', ') + (P.L.length > 3 ? ' +' + (P.L.length - 3) + ' more' : '');
  if (i.pendKeep) return '<div class="note" style="margin-top:6px">Kept in count · ' + num(P.qty) + ' ' + esc(i.uom) + ' still pending for issue (' + reqs + ') <button class="btn sm ghost" data-a="cpUndo" data-v="' + idx + '" style="min-height:30px;padding:0 10px">Change</button></div>';
  return '<div class="banner t-no" style="display:block;margin-top:8px"><b>Still pending for issue: ' + num(P.qty) + ' ' + esc(i.uom) + '</b> · ' + P.L.length + ' request' + (P.L.length === 1 ? '' : 's') + ': ' + reqs + '. If it is already given out but not entered on CUIMS, system stock will not match.' +
    '<div class="grid2" style="margin-top:8px"><button class="btn sm" data-a="cpKeep" data-v="' + idx + '">Keep</button><button class="btn sm danger-t" data-a="cpRemove" data-v="' + idx + '">Remove</button></div></div>';
}
function vCountStart() {
  const pick = countPick(), last = countSaved()[0], todayN = countSaved().filter(c => c.date === today());
  let h = '<header class="top"><div><button class="btn sm ghost" data-a="back">‹ Back</button><h1 style="margin-top:10px">Daily Count Cycle</h1><div class="sub">Count your list any time, as many times as you need. System stock is always the latest. A saved count is locked.</div></div></header><main>';
  h += stockCard();
  if (!pick) return h + '<div class="banner t-no" style="display:block"><b>Your count list ' + (ui.clWhy === 'empty' ? 'is empty' : 'has no items in the current stock report') + '.</b> Add items to start counting.</div><button class="btn main full" data-a="clOpen">Edit my count list</button></main>';
  h += '<div class="card pad col" style="gap:12px"><div class="row"><b style="font-size:18px">Start a new count</b><span class="note">' + pick.length + ' articles</span></div>' +
    '<div class="note">How should the counted values start?</div>' +
    '<button class="btn main full" data-a="countNew" data-v="recent"' + (last ? '' : ' disabled') + '>Copy recently entered values</button>' +
    '<div class="note" style="margin-top:-6px">' + (last ? 'Each article gets its last saved count (latest: ' + esc(fmtDT(last.doneAt)) + '). Batches are copied too.' : 'No saved count yet to copy from.') + '</div>' +
    '<button class="btn full" data-a="countNew" data-v="blank">Blank values</button></div>';
  h += '<div class="grid2"><button class="btn" data-a="clOpen">Edit my count list</button><button class="btn" data-a="countLog">Count history</button></div>';
  if (todayN.length) { h += '<div class="shead"><div><h2>Saved today · ' + todayN.length + '</h2><span>Locked counts</span></div></div>';
    todayN.forEach(c => { const sm = countSummary(c); h += '<button class="card pad tap col" style="gap:6px" data-a="countOpen" data-v="' + c.id + '"><div class="row"><b class="ttl">' + esc(fmtDT(c.doneAt)) + '</b>' + pill('Saved', 'c-ok') + '</div>' + meta([sm.m + ' match', sm.ex + ' excess', sm.sh + ' short', c.items.length + ' articles']) + '</button>'; }); }
  return h + '</main>';
}
function countKey(k) {
  if (S.stock[k]) return k;
  const n = String(k || '').replace(/\s+/g, '').toUpperCase(); if (!n) return k;
  return Object.keys(S.stock).find(c => String(c).replace(/\s+/g, '').toUpperCase() === n) || k;
}
function countOpenFail() { openCountCycle(); }
function countListSig() { return (S.countList || []).join('|') + '#' + (S.countPerDay || 0); }
function diffOf(i) { if (i.physical === '' || i.physical == null || isNaN(parseFloat(i.physical))) return null; return Math.round((parseFloat(i.physical) - i.system) * 1000) / 1000; }
function countSummary(c) { let m = 0, ex = 0, sh = 0, left = 0; c.items.forEach(i => { const d = diffOf(i); if (d === null) left++; else if (d === 0) m++; else if (d > 0) ex++; else sh++; }); return { m, ex, sh, left }; }
function vCount() {
  const c = (S.counts || []).find(x => String(x.id) === String(ui.countId)) || countDraft();
  if (!c) { ui.view = 'countStart'; return vCountStart(); }
  countLive(c);
  const sm = countSummary(c), open = !countLocked(c);
  let h = '<header class="top"><div><button class="btn sm ghost" data-a="back">‹ Back</button><h1 style="margin-top:10px">' + (c.mode === 'emp' ? 'Employee count' : 'Daily Count Cycle') + '</h1><div class="sub">' + (c.mode === 'emp' ? 'Round ' + ((EMP().sessions.find(k => String(k.id) === String(c.emp)) || {}).round || '') + ' · ' : '') + (open ? 'Draft · started ' + esc(fmtDT(c.startedAt)) + (c.fill === 'recent' ? ' · recent values copied' : c.fill === 'copy' ? ' · copied from a saved count' : c.fill === 'emp' ? ' · from employee sheets' : ' · blank values') : 'Saved ' + esc(fmtDT(c.doneAt || c.startedAt)) + ' · locked') + ' · ' + c.items.length + ' articles · system stock from ' + (c.stockAt ? fmtDT(c.stockAt) : '–') + '</div></div></header><main>';
  if (open) { h += stockCard();
    h += '<button class="btn full" data-a="countSys">Update system stock</button><div class="grid2"><button class="btn" data-a="countDraftSave">Save draft</button><button class="btn danger-t" data-a="countClear">' + (c.mode === 'emp' ? 'Back to entry' : 'Clear this cycle') + '</button></div>'; }
  else if (c.status === 'old') h += '<div class="banner t-in" style="display:block"><b>Old random count.</b> Made before you switched to your own list. It is read only and never opens as your draft.<div style="margin-top:8px"><button class="btn sm danger-t" data-a="countDelOld" data-v="' + c.id + '">Delete it</button></div></div>';
  else h += '<div class="banner t-ok" style="display:block"><b>Saved and locked.</b> System and counted values are fixed as they were at ' + esc(fmtDT(c.doneAt || c.startedAt)) + '. For a correction, start a new count.</div>';
  h += '<div class="grid3"><div class="tile t-ok"><b>' + sm.m + '</b><span>Match</span></div><div class="tile t-in"><b>' + sm.ex + '</b><span>Excess</span></div><div class="tile t-no"><b>' + sm.sh + '</b><span>Short</span></div></div>';
  h += meta([sm.left ? sm.left + ' still to count' : 'All counted', open ? 'Draft · not saved yet' + (c.draftAt ? ' · draft saved ' + fmtDT(c.draftAt) : '') : 'Saved ' + fmtDT(c.doneAt)]);
  if (open) { const PO = countPendOpen(c); if (PO.length) h += '<div class="banner t-no" style="display:block"><b>' + PO.length + ' article' + (PO.length === 1 ? ' is' : 's are') + ' still pending for issue.</b> Keep or remove ' + (PO.length === 1 ? 'it' : 'each one') + ' so your count is not affected: ' + PO.slice(0, 4).map(x => esc(x.i.name)).join(', ') + (PO.length > 4 ? '…' : '') + '<div class="grid2" style="margin-top:8px"><button class="btn sm" data-a="cpKeepAll">Keep all</button><button class="btn sm danger-t" data-a="cpRemoveAll">Remove all</button></div></div>'; }
  h += '<div class="card" style="overflow:hidden">';
  c.items.forEach((i, idx) => {
    const d = diffOf(i);
    const tag = d === null ? '' : d === 0 ? pill('Match', 'c-ok') : d > 0 ? pill('Excess +' + num(d), 'c-in') : pill('Short ' + num(d), 'c-no');
    const V = i.variants || [];
    const eq = c.mode === 'emp' ? ((EMP().sessions.find(k => String(k.id) === String(c.emp)) || { people: [] }).people[i.by || 0] || {}) : null;
    h += '<div class="line"><div class="row"><b>' + (idx + 1) + '. ' + esc(i.name) + '</b>' + tag + '</div>' + (eq ? '<div class="note">Counted by ' + esc(eq.name || '') + (i.rem ? ' · ' + esc(i.rem) : '') + '</div>' : '') + '<div class="row" style="align-items:center">' + meta([esc(i.code), 'System ' + num(i.system) + ' ' + esc(i.uom)]) +
      (open && !V.length ? '<input type="number" inputmode="decimal" data-cnt="' + idx + '" value="' + esc(i.physical) + '" placeholder="Physical" style="width:120px;text-align:right">' : '<b class="qty">' + (i.physical === '' ? '–' : num(i.physical)) + ' ' + esc(i.uom) + '</b>') + '</div>' + countPendBox(i, idx, open) +
      (V.length && !open ? '<div class="vbox">' + V.map((v, k) => '<div class="vrow"><div class="vhead"><b>Batch ' + (k + 1) + ' · ' + num(v.qty) + ' ' + esc(i.uom) + '</b><span class="note">' + (v.mfd ? 'MFD ' + fmtShort(v.mfd) : '') + (v.exp ? ' · EXP ' + fmtShort(v.exp) : '') + '</span></div></div>').join('') + '</div>' : '') +
      (V.length && open ? '<div class="vbox">' + V.map((v, k) => { const dl = v.exp ? days(v.exp) * -1 : null;
        return '<div class="vrow"><div class="vhead"><b>Batch ' + (k + 1) + '</b>' + (v.exp ? pill(dl < 0 ? 'Expired' : dl + ' days left', dl < 0 ? 'c-no' : dl <= 15 ? 'c-no' : dl <= expDays() ? 'c-gd' : 'c-ok') : '') + '<button class="xbtn" data-a="varDel" data-v="' + idx + '|' + k + '" aria-label="Remove batch">' + ico('x', 16) + '</button></div>' +
          '<div class="grid3"><label class="f">Qty<input type="number" inputmode="decimal" data-var="' + idx + '|' + k + '|qty" value="' + esc(v.qty) + '"></label><label class="f">MFD<input type="date" data-var="' + idx + '|' + k + '|mfd" value="' + esc(v.mfd || '') + '"></label><label class="f">Expiry<input type="date" data-var="' + idx + '|' + k + '|exp" value="' + esc(v.exp || '') + '"></label></div></div>'; }).join('') + '<div class="note">Physical count = total of all batches.</div></div>' : '') +
      (open ? '<button class="btn sm ghost" data-a="varAdd" data-v="' + idx + '" style="align-self:flex-start">+ Add batch (MFD / expiry)</button>' : '') + '</div>';
  });
  h += '</div>';
  if (open) h += '<button class="btn main full" data-a="countDone">Save &amp; generate report</button><div class="note" style="text-align:center">After saving, the system and counted values are locked and cannot be changed.</div>';
  else if (c.mode === 'emp') h += '<div class="grid2"><button class="btn main" data-a="empResult" data-v="' + c.id + '">Report</button><button class="btn" data-a="empOpen">Employee Cycle Count</button></div>';
  if (c.mode === 'emp' && open) h += '<div class="grid2"><button class="btn" data-a="empResult" data-v="' + c.id + '">Preview report</button><button class="btn" data-a="empLog">Count history</button></div><button class="btn ghost danger-t full" data-a="empDiscard" data-v="' + c.emp + '">Discard whole cycle</button>';
  if (c.mode === 'emp' && !open) h += '<button class="btn full" data-a="empLog">Count history</button>';
  else if (c.status === 'done') h += '<div class="grid2"><button class="btn main" data-a="countExport" data-v="' + c.id + '">Report</button><button class="btn" data-a="countNew" data-v="' + c.id + '">New count from this</button></div>';
  if (c.mode !== 'emp') h += '<div class="grid2">' + (open ? '<button class="btn" data-a="countExport" data-v="' + c.id + '">Preview report</button>' : '<button class="btn" data-a="countStart">Start a new count</button>') + '<button class="btn" data-a="countLog">Count history</button></div>';
  return h + '</main>';
}
function expDays() { return S.expiryDays || 45; }
function curCount() { return (S.counts || []).find(x => String(x.id) === String(ui.countId)); }
function syncPhysical(it) { if (it.variants && it.variants.length) { const t = it.variants.reduce((n, v) => n + (parseFloat(v.qty) || 0), 0); it.physical = String(Math.round(t * 1000) / 1000); } }
function expiryRows() {
  const latest = {};
  (S.counts || []).slice().sort((a, b) => a.date.localeCompare(b.date)).forEach(c => c.items.forEach(i => { if (i.variants && i.variants.length) latest[i.code] = { c, i }; }));
  const out = [];
  Object.values(latest).forEach(({ c, i }) => i.variants.forEach((v, k) => { if (!v.exp || v.cleared) return; const left = -days(v.exp);
    out.push({ code: i.code, name: i.name, uom: i.uom, qty: v.qty, mfd: v.mfd, exp: v.exp, left, countDate: c.date, cid: c.id, idx: c.items.indexOf(i), k }); }));
  return out.sort((a, b) => a.left - b.left);
}
/* ---------------- Employee Cycle Count ---------------- */
function EMP() {
  S.emp = S.emp || {}; const E = S.emp;
  E.staff = E.staff || []; E.ignore = E.ignore || []; E.sessions = E.sessions || []; E.pick = E.pick || [];
  E.round = E.round || { n: 1, start: new Date().toISOString(), counted: {}, missed: {} };
  if (E.title == null) E.title = 'JV Daily Cycle Count'; if (E.store == null) E.store = 'Ration Store';
  if (!E.per) E.per = 80; if (!E.how) E.how = 'n'; if (!E.stockF) E.stockF = 'nz';
  return E;
}
const EMP_RULE = { code: 'Exact code', pre: 'Code starts with', name: 'Name contains' };
function ruleHit(r, code) { const v = String(r.v || '').trim().toUpperCase(); if (!v) return false; const c = String(code).toUpperCase(), nm = String((S.stock[code] || {}).name || '').toUpperCase();
  return r.t === 'code' ? c === v : r.t === 'pre' ? c.startsWith(v) : nm.includes(v); }
const posStock = c => (Number((S.stock[c] || {}).qty) || 0) > 0;
function ruleAll(r) { return Object.keys(S.stock).filter(c => posStock(c) && ruleHit(r, c)).sort((a, b) => a.localeCompare(b, undefined, { numeric: true })); }
function ruleCodes(r) { const ex = new Set(r.ex || []); return ruleAll(r).filter(c => !ex.has(c)); }
function empIgnored(code) { if (!posStock(code)) return false; return EMP().ignore.some(r => ruleHit(r, code) && !(r.ex || []).includes(code)); }
function empMine() { return new Set((S.countList || []).map(countKey)); }
function empStockOk(c) { const q = Number((S.stock[c] || {}).qty) || 0; return EMP().stockF === 'pos' ? q > 0 : q !== 0; }
function empEligible() { const mine = empMine(); return Object.keys(S.stock).filter(c => empStockOk(c) && !mine.has(c) && !empIgnored(c)).sort((a, b) => a.localeCompare(b, undefined, { numeric: true })); }
function empActive() { return EMP().sessions.filter(x => x.status === 'print' || x.status === 'entry' || x.status === 'draft'); }
function empReserved() { const r = new Set(); empActive().forEach(x => x.people.forEach(q => q.codes.forEach(c => r.add(c)))); return r; }
function empStat() { const E = EMP(), el = empEligible(), R = E.round, counted = el.filter(c => R.counted[c]).length;
  return { el, total: el.length, counted, left: el.length - counted, missed: el.filter(c => R.missed[c] && !R.counted[c]).length }; }
function empPick(n) {
  const E = EMP(); let st = empStat();
  if (st.total && !st.left) { E.round = { n: E.round.n + 1, start: new Date().toISOString(), counted: {}, missed: {} }; st = empStat(); }
  const R = E.round, res = empReserved(), pool = st.el.filter(c => !R.counted[c] && !res.has(c));
  return pool.filter(c => R.missed[c]).concat(pool.filter(c => !R.missed[c])).slice(0, Math.max(0, n));
}
function empSplitSizes(n, k) { return Array.from({ length: k }, (_, i) => Math.floor(n / k) + (i < n % k ? 1 : 0)); }
function empSel() { const E = EMP(); return E.pick.map(id => E.staff.find(x => String(x.id) === String(id))).filter(Boolean); }
function empCur() { return EMP().sessions.find(x => String(x.id) === String(ui.empId)) || null; }
function empHow() { const E = EMP(), st = empStat(), free = st.el.filter(c => !E.round.counted[c] && !empReserved().has(c)).length; return E.how === 'all' ? free : Math.min(parseInt(E.per, 10) || 0, free || (st.total && !st.left ? st.total : 0)); }
function vEmp() {
  const E = EMP(), st = empStat(), sel = empSel(), n = empHow(), sizes = sel.length ? empSplitSizes(n, sel.length) : [], act = empActive();
  let h = '<header class="top"><div><button class="btn sm ghost" data-a="back">‹ Back</button><h1 style="margin-top:10px">Employee Cycle Count</h1><div class="sub">Articles for your staff to count on paper. Your own count list and the ignore list are never included.</div></div></header><main>';
  act.forEach(x => { const a = x.people.reduce((t, q) => t + q.codes.length, 0);
    h += '<div class="card pad col" style="gap:10px;border:2px solid #B9A7FF"><button class="tap col" style="all:unset;display:flex;flex-direction:column;gap:6px;cursor:pointer" data-a="empOpenSess" data-v="' + x.id + '"><div class="row"><b class="ttl">Round ' + x.round + ' · ' + a + ' articles</b>' + pill(EMP_ST[x.status][0], EMP_ST[x.status][1]) + '</div>' + meta(['Printed ' + esc(hrsDT(x.createdAt)), x.people.map(q => esc(q.name.split(' ')[0])).join(', ')]) + '</button>' +
      '<div class="grid2"><button class="btn sm main" data-a="empOpenSess" data-v="' + x.id + '">Continue</button><button class="btn sm danger-t" data-a="empDiscard" data-v="' + x.id + '">Discard this cycle</button></div></div>'; });
  h += stockCard();
  h += '<button class="btn full" data-a="empSys">Update system stock</button><div class="grid2"><button class="btn" data-a="empLog">Count history</button><button class="btn danger-t" data-a="empFresh">Start a fresh round</button></div>';
  h += '<div class="card pad col" style="gap:10px"><div class="row"><b style="font-size:17px">Round ' + E.round.n + '</b>' + pill('started ' + fmtShort(String(E.round.start).slice(0, 10)), 'c-in') + '</div>' +
    '<div style="height:12px;border-radius:99px;background:#EEEAFB;overflow:hidden"><i style="display:block;height:100%;width:' + (st.total ? Math.round(st.counted / st.total * 100) : 0) + '%;background:linear-gradient(90deg,#B9A7FF,#F6A8EE)"></i></div>' +
    '<div class="grid3"><div class="tile t-ok"><b>' + st.counted + '</b><span>Counted</span></div><div class="tile t-pt"><b>' + st.left + '</b><span>Left in round</span></div><div class="tile t-no"><b>' + st.missed + '</b><span>Missed before</span></div></div>' +
    '<div class="note">' + st.total + ' articles in this round. Missed ones are given first. When all are counted, the next round starts by itself.</div></div>';
  { const mine = empMine(), base = Object.keys(S.stock).filter(c => !mine.has(c) && !empIgnored(c)), nz = base.filter(c => (Number(S.stock[c].qty) || 0) !== 0).length, pos = base.filter(c => (Number(S.stock[c].qty) || 0) > 0).length, zero = base.length - nz, neg = nz - pos;
    h += '<div class="card pad col" style="gap:10px"><b>Articles to include</b>' +
      '<button class="stkrow" data-a="empStockF" data-v="nz"><span class="zwck' + (E.stockF !== 'pos' ? ' on' : '') + '">' + (E.stockF !== 'pos' ? '✓' : '') + '</span><span class="sn"><b>All articles · not zero</b><span class="mono">Stock above zero or below zero · ' + zero + ' at zero skipped</span></span>' + pill(String(nz), 'c-gy') + '</button>' +
      '<button class="stkrow" data-a="empStockF" data-v="pos"><span class="zwck' + (E.stockF === 'pos' ? ' on' : '') + '">' + (E.stockF === 'pos' ? '✓' : '') + '</span><span class="sn"><b>Above zero only</b><span class="mono">No zero and no negative · ' + (zero + neg) + ' skipped</span></span>' + pill(String(pos), 'c-gy') + '</button></div>'; }
  h += '<div class="card pad col" style="gap:10px"><b>How many articles today?</b><div class="seg"><button data-a="empHow" data-v="n" class="' + (E.how !== 'all' ? 'on' : '') + '">Number</button><button data-a="empHow" data-v="all" class="' + (E.how === 'all' ? 'on' : '') + '">All left</button></div>' +
    (E.how !== 'all' ? '<label class="f">Articles to count<input type="number" inputmode="numeric" data-emp="per" value="' + esc(E.per) + '"></label>' : '') + '<div class="note">' + n + ' articles will be given out.</div></div>';
  h += '<div class="card pad col" style="gap:8px"><div class="row"><b>Who is counting?</b><button class="btn sm ghost" data-a="empStaff">Manage</button></div>' +
    (E.staff.length ? E.staff.map(x => { const i = sel.indexOf(x), on = i >= 0; return '<button class="stkrow" data-a="empPickP" data-v="' + x.id + '"><span class="zwck' + (on ? ' on' : '') + '">' + (on ? '✓' : '') + '</span><span class="sn"><b>' + esc(x.name) + '</b><span class="mono">' + esc([x.code, x.desig].filter(Boolean).join(' · ')) + '</span></span>' + (on ? pill(String(sizes[i] || 0), 'c-ok') : '') + '</button>'; }).join('') : '<div class="note">No employees yet. Tap Manage to add name, code and designation.</div>') +
    (sel.length ? '<div class="note">' + n + ' articles ÷ ' + sel.length + ' ' + (sel.length === 1 ? 'person' : 'people') + ' = ' + sizes.join(' · ') + '</div>' : '') + '</div>';
  h += '<div class="card pad col" style="gap:8px"><b>Never included</b><div class="stkrow"><span class="sn"><b>My count list</b><span class="mono">High-value · your own count</span></span>' + pill(empMine().size + ' articles', 'c-gy') + '</div>' +
    '<button class="stkrow" data-a="empIgnore"><span class="sn"><b>Ignore list</b><span class="mono">' + E.ignore.length + ' rule' + (E.ignore.length === 1 ? '' : 's') + ' · tap to manage</span></span>' + pill(Object.keys(S.stock).filter(empIgnored).length + ' articles', 'c-gy') + '</button></div>';
  h += '<div class="card pad col" style="gap:8px"><b>Labels on paper</b><label class="f">Title<input type="text" data-emp="title" value="' + esc(E.title) + '"></label><label class="f">Store<input type="text" data-emp="store" value="' + esc(E.store) + '"></label></div>';
  h += '<button class="btn main full" data-a="empMake"' + (sel.length && n ? '' : ' disabled') + '>Make sheets' + (sel.length ? ' · ' + sel.length + ' ' + (sel.length === 1 ? 'person' : 'people') : '') + '</button>';
  const done = EMP().sessions.filter(x => x.status === 'done').slice().reverse().slice(0, 15);
  if (done.length) { h += '<div class="shead"><div><h2>Saved employee counts</h2><span>Locked results</span></div></div>';
    done.forEach(x => { const c = (S.counts || []).find(k => String(k.id) === String(x.countId)); const sm = c ? countSummary(c) : null;
      h += '<button class="card pad tap col" style="gap:6px" data-a="countOpen" data-v="' + (c ? c.id : '') + '"><div class="row"><b class="ttl">' + esc(c ? hrsDT(c.doneAt) : hrsDT(x.createdAt)) + '</b>' + pill('Round ' + x.round, 'c-ok') + '</div>' + meta([sm ? sm.m + ' match' : '', sm ? sm.ex + ' excess' : '', sm ? sm.sh + ' short' : '', x.people.map(q => esc(q.name.split(' ')[0])).join(', ')]) + '</button>'; }); }
  return h + '</main>';
}
function vEmpStaff() {
  const E = EMP(), F = ui.empNew = ui.empNew || { name: '', code: '', desig: '' };
  let h = '<header class="top"><div><button class="btn sm ghost" data-a="empHome">‹ Back</button><h1 style="margin-top:10px">Employees</h1><div class="sub">Name, employee code and designation print on their sheets and in the result.</div></div></header><main>';
  h += '<div class="card pad col" style="gap:8px"><b>Add an employee</b><label class="f">Name<input type="text" data-empnew="name" value="' + esc(F.name) + '"></label><label class="f">Employee code<input type="text" data-empnew="code" value="' + esc(F.code) + '" class="mono"></label><label class="f">Designation<input type="text" data-empnew="desig" value="' + esc(F.desig) + '" placeholder="e.g. Store Keeper"></label><button class="btn main full" data-a="empAddP">Add</button></div>';
  h += '<div class="card" style="overflow:hidden">' + (E.staff.length ? E.staff.map(x => '<div class="stkrow"><span class="sn"><b>' + esc(x.name) + '</b><span class="mono">' + esc([x.code, x.desig].filter(Boolean).join(' · ')) + '</span></span><button class="btn sm" data-a="empEditP" data-v="' + x.id + '">Edit</button><button class="btn sm danger-t" data-a="empDelP" data-v="' + x.id + '">Remove</button></div>').join('') : '<div class="pad note">No employees yet.</div>') + '</div>';
  return h + '</main>';
}
function vEmpIgnore() {
  const E = EMP(), F = ui.ign = ui.ign || { t: 'pre', v: '', off: {} };
  let h = '<header class="top"><div><button class="btn sm ghost" data-a="empHome">‹ Back</button><h1 style="margin-top:10px">Ignore list</h1><div class="sub">Articles here are never given to employees. Only articles with stock above zero in your latest stock report are listed.</div></div></header><main>';
  h += stockCard();
  const tot = Object.keys(S.stock).filter(empIgnored).length;
  h += '<div class="grid2"><div class="tile t-pt"><b>' + E.ignore.length + '</b><span>Rules</span></div><div class="tile t-in"><b>' + tot + '</b><span>Articles ignored</span></div></div>';
  h += '<div class="card pad col" style="gap:10px"><b>Add a rule</b><div class="seg">' + Object.entries(EMP_RULE).map(([k, l]) => '<button data-a="eigT" data-v="' + k + '" class="' + (F.t === k ? 'on' : '') + '">' + l + '</button>').join('') + '</div>' +
    '<label class="f">' + EMP_RULE[F.t] + '<input type="text" data-ign="v" value="' + esc(F.v) + '" autocomplete="off"></label><div id="ignprev">' + ignPreview() + '</div></div>';
  h += '<div class="shead"><div><h2>Saved rules</h2><span>Tap a rule to see all its articles</span></div></div>';
  if (!E.ignore.length) h += '<div class="card pad note">No rules yet.</div>';
  E.ignore.forEach((r, i) => { const L = ruleCodes(r), ex = (r.ex || []).filter(c => S.stock[c]), op = ui.ignOpen === i;
    h += '<div class="card" style="overflow:hidden"><button class="stkrow" data-a="eigOpen" data-v="' + i + '"><span class="sn"><b>' + EMP_RULE[r.t] + ' "' + esc(r.v) + '"</b><span class="mono">' + L.length + ' article' + (L.length === 1 ? '' : 's') + ' ignored' + (ex.length ? ' · ' + ex.length + ' removed from rule' : '') + '</span></span>' + ico(op ? 'up' : 'down', 18) + '</button>';
    if (op) {
      h += L.length ? L.map(c => '<div class="stkrow"><span class="sn"><b>' + esc(itemName(c)) + '</b><span class="mono">' + esc(c) + ' · stock ' + num(S.stock[c].qty) + ' ' + esc(S.stock[c].uom || '') + '</span></span><button class="btn sm danger-t" data-a="eigItemDel" data-v="' + i + '|' + esc(c) + '">Remove</button></div>').join('') : '<div class="pad note">No article with stock above zero matches this rule right now.</div>';
      if (ex.length) h += '<div class="note" style="padding:10px 16px 4px;font-weight:700">Removed from this rule · ' + ex.length + '</div>' + ex.map(c => '<div class="stkrow"><span class="sn"><b>' + esc(itemName(c)) + '</b><span class="mono">' + esc(c) + ' · can be given to employees</span></span><button class="btn sm" data-a="eigItemBack" data-v="' + i + '|' + esc(c) + '">Put back</button></div>').join('');
      h += '<div class="pad"><button class="btn danger-t full" data-a="eigDel" data-v="' + i + '">Remove whole rule</button></div>';
    }
    h += '</div>'; });
  return h + '</main>';
}
function ignPreview() {
  const F = ui.ign; F.off = F.off || {}; if (!String(F.v || '').trim()) return '<div class="note">Type to see which articles match.</div>';
  const L = ruleAll(F), mine = empMine(), on = L.filter(c => !F.off[c]);
  if (!L.length) return '<div class="note">No article with stock above zero matches.</div>';
  return '<div class="row"><span class="note"><b>' + on.length + ' of ' + L.length + ' article' + (L.length === 1 ? '' : 's') + ' selected</b></span><span class="row" style="gap:6px"><button class="btn sm ghost" data-a="eigPrevAll" data-v="on">All</button><button class="btn sm ghost" data-a="eigPrevAll" data-v="off">None</button></span></div>' +
    '<div style="max-height:46vh;overflow-y:auto;border:1px solid #EEECF3;border-radius:16px">' + L.map(c => '<button class="stkrow" data-a="eigPrev" data-v="' + esc(c) + '"><span class="zwck' + (F.off[c] ? '' : ' on') + '">' + (F.off[c] ? '' : '✓') + '</span><span class="sn"><b>' + esc(itemName(c)) + '</b><span class="mono">' + esc(c) + ' · stock ' + num(S.stock[c].qty) + (mine.has(c) ? ' · in your count list' : '') + '</span></span></button>').join('') + '</div>' +
    '<button class="btn main full" data-a="eigSave"' + (on.length ? '' : ' disabled') + '>Save rule · ignore ' + on.length + ' article' + (on.length === 1 ? '' : 's') + '</button>';
}
function vEmpSess() {
  const x = empCur(); if (!x) { ui.view = 'emp'; return vEmp(); }
  if (x.status === 'entry') return vEmpEntry(x);
  const tot = x.people.reduce((t, q) => t + q.codes.length, 0);
  let h = '<header class="top"><div><button class="btn sm ghost" data-a="empHome">‹ Back</button><h1 style="margin-top:10px">Sheets ready</h1><div class="sub">Round ' + x.round + ' · ' + tot + ' articles · printed ' + esc(hrsDT(x.createdAt)) + '</div></div></header><main>';
  h += '<div class="card" style="overflow:hidden">' + x.people.map(q => '<div class="stkrow"><span class="sn"><b>' + esc(q.name) + '</b><span class="mono">' + esc([q.code, q.desig].filter(Boolean).join(' · ')) + '</span></span>' + pill(q.codes.length + ' articles', 'c-ok') + '</div>').join('') + '</div>';
  h += '<button class="btn main full" data-a="empPrint">Preview &amp; print sheets (PDF)</button>';
  h += '<div class="banner t-in" style="display:block"><b>Staff are counting on paper.</b> When the signed sheets come back, continue below. You can close the app; this round waits for you.</div>';
  h += '<button class="btn main full" data-a="empPhysDone">✓ Physical count done · enter results</button><div class="grid2"><button class="btn" data-a="empSys">Update system stock</button><button class="btn danger-t" data-a="empDiscard" data-v="' + x.id + '">Discard this cycle</button></div>';
  return h + '</main>';
}
function vEmpEntry(x) {
  const pi = Math.min(ui.empTab || 0, x.people.length - 1), q = x.people[pi];
  let h = '<header class="top"><div><button class="btn sm ghost" data-a="empHome">‹ Back</button><h1 style="margin-top:10px">Enter results</h1><div class="sub">Round ' + x.round + ' · ' + (x.draftAt ? 'draft saved ' + esc(fmtDT(x.draftAt)) : 'not saved as draft yet') + '. Type the counts from each sheet. The photo stays above for checking.</div></div></header><main>';
  h += stockCard() + '<button class="btn full" data-a="empSys">Update system stock</button><div class="grid2"><button class="btn" data-a="empDraftSave">Save draft</button><button class="btn danger-t" data-a="empDiscard" data-v="' + x.id + '">Discard this cycle</button></div>';
  h += '<div class="seg">' + x.people.map((p, i) => { const f = p.codes.filter(c => p.vals[c] && p.vals[c].cnt !== '' && p.vals[c].cnt != null).length; return '<button data-a="empTab" data-v="' + i + '" class="' + (i === pi ? 'on' : '') + '">' + esc(p.name.split(' ')[0]) + (f === p.codes.length ? ' ✓' : ' ' + f + '/' + p.codes.length) + '</button>'; }).join('') + '</div>';
  h += '<div class="card pad col" style="gap:8px"><div class="row"><b>Signed sheet photos · ' + q.photos.length + '</b><button class="btn sm" data-a="empPhoto" data-v="' + pi + '">+ Add photo</button></div>' +
    (q.photos.length ? '<div class="wrap" style="gap:8px">' + q.photos.map((ph, k) => '<span style="position:relative;display:inline-block"><img src="' + esc(paperSrc(ph.id)) + '" data-a="empZoom" data-v="' + esc(ph.id) + '" style="width:96px;height:128px;object-fit:cover;border-radius:12px;border:1px solid #E4E1EC"><button class="xbtn" data-a="empPhotoDel" data-v="' + pi + '|' + k + '" style="position:absolute;top:4px;right:4px;background:#fff">×</button></span>').join('') + '</div>' : '<div class="note">Add a photo of the signed sheet. It is printed at the end of the result PDF.</div>') + '</div>';
  h += '<div class="card pad col" style="gap:8px"><b>Submitted on the sheet</b><div class="grid2"><label class="f">Date<input type="date" data-empv="' + pi + '|subDate" value="' + esc(q.subDate || '') + '"></label><label class="f">Time (Hrs)<input type="text" inputmode="numeric" maxlength="4" data-empv="' + pi + '|subTime" value="' + esc(q.subTime || '') + '" placeholder="HHMM"></label></div></div>';
  h += '<div class="card" style="overflow:hidden"><div style="display:grid;grid-template-columns:1fr 78px 96px;gap:6px;padding:10px 14px;background:#2C2E33;color:#fff;font:700 12px Outfit,system-ui"><span>Item</span><span style="text-align:right">Count</span><span>Remarks</span></div>' +
    q.codes.map(c => { const v = q.vals[c] || {}, op = ui.empDates && ui.empDates[pi + '|' + c];
      return '<div style="padding:8px 14px;border-bottom:1px solid #F0EEF4' + (v.cnt === '' || v.cnt == null ? '' : '') + '"><div style="display:grid;grid-template-columns:1fr 78px 96px;gap:6px;align-items:center"><span><b style="font-size:14px">' + esc(itemName(c)) + '</b><div class="mono note">' + esc(c) + ' · ' + esc(itemUom(c)) + '</div></span>' +
        '<input type="number" inputmode="decimal" data-empc="' + pi + '|' + esc(c) + '|cnt" value="' + esc(v.cnt == null ? '' : v.cnt) + '" style="height:42px;text-align:right">' +
        '<input type="text" data-empc="' + pi + '|' + esc(c) + '|rem" value="' + esc(v.rem || '') + '" placeholder="Remarks" style="height:42px"></div>' +
        (op ? '<div class="grid2" style="margin-top:6px"><label class="f">Mfg. date<input type="date" data-empc="' + pi + '|' + esc(c) + '|mfd" value="' + esc(v.mfd || '') + '"></label><label class="f">Expiry date<input type="date" data-empc="' + pi + '|' + esc(c) + '|exp" value="' + esc(v.exp || '') + '"></label></div>' :
          '<button class="btn sm ghost" data-a="empDates" data-v="' + pi + '|' + esc(c) + '" style="margin-top:4px;min-height:30px">' + (v.mfd || v.exp ? 'Mfg ' + (v.mfd ? fmtShort(v.mfd) : '–') + ' · Exp ' + (v.exp ? fmtShort(v.exp) : '–') : '+ Mfg / Expiry') + '</button>') + '</div>'; }).join('') + '</div>';
  h += '<div class="grid2"><button class="btn" data-a="empNext">' + (pi < x.people.length - 1 ? 'Save · next person' : 'Save') + '</button><button class="btn main" data-a="empMakeDraft">Done · make draft</button></div>';
  h += '<button class="btn ghost full" data-a="empBackPrint">Back to the printed sheets</button>';
  return h + '</main>';
}
function empDiscard(x) {
  if (!x) return; if (x.countId) S.counts = (S.counts || []).filter(c => String(c.id) !== String(x.countId));
  x.status = 'void'; x.discardedAt = new Date().toISOString(); delete x.countId;
}
const EMP_ST = { print: ['Counting on paper', 'c-gd'], entry: ['Entering results', 'c-gd'], draft: ['Draft to review', 'c-in'], done: ['Saved · locked', 'c-ok'], void: ['Discarded', 'c-gy'] };
function vEmpLog() {
  const L = EMP().sessions.slice().reverse();
  let h = '<header class="top"><div><button class="btn sm ghost" data-a="empHome">‹ Back</button><h1 style="margin-top:10px">Employee count history</h1><div class="sub">Every employee cycle: on paper, being entered, draft, saved or discarded.</div></div></header><main>';
  if (!L.length) h += '<div class="card pad note">No employee cycles yet.</div>';
  L.forEach(x => { const a = x.people.reduce((t, q) => t + q.codes.length, 0), c = x.countId ? (S.counts || []).find(k => String(k.id) === String(x.countId)) : null, sm = c && c.status === 'done' ? countSummary(c) : null, T = EMP_ST[x.status] || ['', 'c-gy'];
    h += '<button class="card pad tap col" style="gap:6px' + (x.status === 'void' ? ';opacity:.7' : '') + '" data-a="' + (x.status === 'void' ? 'empLogNo' : 'empOpenSess') + '" data-v="' + x.id + '"><div class="row"><b class="ttl">Round ' + x.round + ' · ' + esc(hrsDT(x.lockedAt || x.discardedAt || x.createdAt)) + '</b>' + pill(T[0], T[1]) + '</div>' +
      meta([a + ' articles', x.people.map(q => esc(q.name.split(' ')[0])).join(', '), sm ? sm.m + ' match · ' + sm.ex + ' excess · ' + sm.sh + ' short' : '']) + '</button>'; });
  return h + '</main>';
}
function empMakeDraft(x) {
  const c = { id: nid(), date: today(), status: 'draft', mode: 'emp', emp: x.id, startedAt: new Date().toISOString(), by: meTag(), stockAt: S.stockAt, fill: 'emp', items: [] };
  x.people.forEach((q, pi) => q.codes.forEach(code => { const st = S.stock[code] || {}, v = q.vals[code] || {}, cnt = v.cnt == null ? '' : String(v.cnt);
    const it = { code, name: st.name || itemName(code), uom: st.uom || itemUom(code), system: st.qty || 0, physical: cnt, by: pi, rem: v.rem || '' };
    if ((v.mfd || v.exp) && cnt !== '') it.variants = [{ qty: cnt, mfd: v.mfd || '', exp: v.exp || '' }];
    c.items.push(it); }));
  S.counts = S.counts || []; S.counts.push(c); x.status = 'draft'; x.countId = c.id; save(); return c;
}
function empLock(c) {
  const x = EMP().sessions.find(k => String(k.id) === String(c.emp)); if (!x) return;
  const R = EMP().round; c.items.forEach(i => { if (i.physical !== '' && i.physical != null) { R.counted[i.code] = 1; delete R.missed[i.code]; } else R.missed[i.code] = 1; });
  x.people.forEach(q => q.codes.forEach(code => { if (!c.items.some(i => i.code === code)) R.missed[code] = 1; }));
  x.status = 'done'; x.lockedAt = c.doneAt;
}
/* sheets & result PDFs */
function empRowsPlan(n, A, SIGN, maxH) {
  for (let P = 1; P < 40; P++) { for (let rh = Math.min(maxH, (P * A - SIGN) / n); rh >= 6.2; rh -= 0.05) { const full = Math.floor(A / rh), last = Math.floor((A - SIGN) / rh);
    if ((P - 1) * full + last >= n) { const rows = []; let rest = n; for (let k = 0; k < P - 1; k++) { const t = Math.min(full, rest - 1); rows.push(t); rest -= t; } if (rest > 0 && rest <= last) { rows.push(rest); return { rh, rows }; } } } }
  return { rh: 7, rows: [n] };
}
function empSheetDef() {
  const p = rptPref('empSheet'), x = empCur(), off = (ui.sheet && ui.sheet.rowOff) || {}, all = [];
  if (x) x.people.forEach((q, pi) => q.codes.forEach(c => all.push({ _k: pi + '|' + c, _p: pi, _lab: itemName(c), _sub: c + ' · ' + q.name, 'Item Code': c, 'Item Name': itemName(c), UOM: itemUom(c), 'Physical Count': '', 'Mfg. Date': '', 'Expiry Date': '', Remarks: '' })));
  const K = ['Item Code', 'Item Name', 'UOM', 'Physical Count', 'Mfg. Date', 'Expiry Date', 'Remarks'];
  return { cols: K.map(k => [k, k]), all, rows: all.filter(r => !off[r._k]), x, file: 'Employee-Count-Sheets-' + (x ? isoOf(new Date(x.createdAt)) : '') };
}
function empResultDef() {
  const p = rptPref('empResult'), c = (S.counts || []).find(k => String(k.id) === String(ui.countExportId)), x = c ? EMP().sessions.find(k => String(k.id) === String(c.emp)) : null, off = (ui.sheet && ui.sheet.rowOff) || {}, all = [];
  if (c) c.items.forEach(i => { const d = diffOf(i), res = d === null ? 'Not counted' : d === 0 ? 'Match' : d > 0 ? 'Excess' : 'Short', v = (i.variants || [])[0] || {};
    all.push({ _k: (i.by || 0) + '|' + i.code, _p: i.by || 0, _res: res, _lab: i.name, _sub: i.code + ' · ' + res, 'Item code': i.code, Item: i.name, UOM: i.uom, 'System stock': Number(i.system) || 0, Counted: i.physical === '' || i.physical == null ? '–' : Number(i.physical), Difference: d === null ? '' : (d > 0 ? '+' : '') + num(d), Result: res, Remarks: i.rem || '–', 'Mfg. Date': v.mfd ? mdy(v.mfd) : '–', 'Expiry Date': v.exp ? mdy(v.exp) : '–' }); });
  const K = ['Item code', 'Item', 'UOM', 'System stock', 'Counted', 'Difference', 'Result', 'Remarks', 'Mfg. Date', 'Expiry Date'];
  return { cols: K.map(k => [k, k]), all, rows: all.filter(r => !off[r._k]), c, x, when: c ? (c.doneAt || new Date().toISOString()) : new Date().toISOString(), draft: !!(c && c.status !== 'done'), file: 'Employee-Count-Result-' + (c ? isoOf(new Date(c.doneAt || Date.now())) : '') };
}
function empSheetPdf(p, D) {
  const x = D.x; if (!x) return; const doc = pdfDoc(p.orient === 'l'); if (!doc) return;
  const W = doc.internal.pageSize.getWidth(), H = doc.internal.pageSize.getHeight(), GR = [107, 111, 118], fs = p.font === 's' ? 7.8 : p.font === 'b' ? 10 : 8.6;
  const cols = orderedCols(p, D).filter(c => colOn(p, c[0])), AL = { UOM: 'center', 'Physical Count': 'center', 'Mfg. Date': 'center', 'Expiry Date': 'center' }, CW = { 'Item Code': 24, UOM: 14, 'Physical Count': 27, 'Mfg. Date': 24, 'Expiry Date': 24 };
  const TOP = 44, HEAD = 8.5, BOT = H - 14, SIGN = 33, A = BOT - TOP - HEAD;
  let first = true;
  x.people.forEach((q, pi) => { const R = D.rows.filter(r => r._p === pi); if (!R.length) return; const PL = empRowsPlan(R.length, A, SIGN, 12); let k = 0;
    PL.rows.forEach((rc, pg) => { if (!first) doc.addPage(); first = false;
      cleanHead(doc, p.title || EMP().title, '', null, p.sub || EMP().store);
      doc.setFillColor(246, 246, 247); doc.setDrawColor(214, 214, 219); doc.setLineWidth(0.3); doc.roundedRect(12, 23, W - 24, 16, 2, 2, 'FD');
      const lab = (xx, t) => { doc.setFont('helvetica', 'normal'); doc.setFontSize(7); doc.setTextColor(...GR); doc.text(t.toUpperCase(), xx, 28); };
      const cx = [16, 16 + (W - 24) * 0.27, 16 + (W - 24) * 0.44, 16 + (W - 24) * 0.665];
      lab(cx[0], 'Counted by'); lab(cx[1], 'Employee ID'); lab(cx[2], 'Printed date & time'); lab(cx[3], 'Submission date & time');
      doc.setFont('helvetica', 'bold'); doc.setFontSize(10.5); doc.setTextColor(...INK); doc.text(q.name, cx[0], 34.5); doc.text(q.code || '', cx[1], 34.5);
      doc.setFontSize(9.5); doc.text(hrsDT(x.createdAt), cx[2], 34.5);
      doc.setFillColor(255, 255, 255); doc.setDrawColor(158, 158, 168); doc.setLineWidth(0.4); const bx = cx[3] - 1, bwid = (W - 12 - 3 - bx);
      doc.roundedRect(bx, 30.2, bwid * 0.56, 6.6, 1.2, 1.2, 'FD'); doc.roundedRect(bx + bwid * 0.56 + 2, 30.2, bwid * 0.44 - 2, 6.6, 1.2, 1.2, 'FD');
      doc.setFont('helvetica', 'normal'); doc.setFontSize(7); doc.setTextColor(...GR); doc.text('Hrs', W - 12 - 4.4, 34.6, { align: 'right' });
      const body = R.slice(k, k + rc).map(r => cols.map(c => cellText(r[c[0]], '\n'))); k += rc;
      const cs = {}; cols.forEach((c, i) => { cs[i] = { halign: AL[c[0]] || 'left' }; if (CW[c[0]]) cs[i].cellWidth = CW[c[0]]; if (c[0] === 'Item Name') cs[i].fontStyle = 'bold'; });
      doc.autoTable({ startY: TOP, margin: { left: 12, right: 12, bottom: 4 }, head: [cols.map(c => c[1])], body, columnStyles: cs, pageBreak: 'avoid', rowPageBreak: 'avoid',
        headStyles: { fillColor: [44, 46, 51], textColor: 255, fontStyle: 'bold', fontSize: fs, minCellHeight: HEAD, valign: 'middle' },
        styles: { fontSize: fs, textColor: INK, lineColor: [204, 204, 211], lineWidth: 0.25, minCellHeight: PL.rh, valign: 'middle', overflow: 'ellipsize', cellPadding: { left: 2, right: 2, top: 0.5, bottom: 0.5 } },
        didParseCell: d => { if (d.section === 'head') d.cell.styles.halign = AL[cols[d.column.index][0]] || 'left'; } });
      if (pg === PL.rows.length - 1) { const B = [['Counted by (Sign here)', q.name, [q.code, q.desig].filter(Boolean).join(' · ')]]; if (p.sign) B.push(meBox('Received & Reported by')); if (p.mgr) B.push(mgrBox()); signBoxes(doc, BOT - 28, B, true); }
    }); });
  cleanFoot(doc); pdfSave(doc, D.file + '.pdf');
}
function imgSize(src) { return new Promise(res => { const im = new Image(); im.onload = () => res([im.naturalWidth, im.naturalHeight]); im.onerror = () => res(null); im.src = src; }); }
async function empResultPdf(p, D) {
  const c = D.c, x = D.x; if (!c) return; const doc = pdfDoc(p.orient === 'l'); if (!doc) return;
  const W = doc.internal.pageSize.getWidth(), H = doc.internal.pageSize.getHeight(), fs = p.font === 's' ? 7.8 : p.font === 'b' ? 10 : 8.6;
  const C = { Match: [26, 128, 69], Excess: [41, 84, 191], Short: [191, 38, 59], 'Not counted': [107, 111, 118] };
  const cols = orderedCols(p, D).filter(k => colOn(p, k[0])), AL = { UOM: 'center', 'System stock': 'right', Counted: 'right', Difference: 'right', Result: 'center', 'Mfg. Date': 'center', 'Expiry Date': 'center' };
  const TOP = 30, HEAD = 8, BOT = H - 12, SIGN = 30, A = BOT - TOP - HEAD, people = x ? x.people : [{ name: '', code: '', desig: '', photos: [] }];
  let first = true; loader(true, 'Making the PDF');
  try {
    people.forEach((q, pi) => { const R = D.rows.filter(r => r._p === pi); if (!R.length) return; const PL = empRowsPlan(R.length, A, SIGN, 11.5); let k = 0;
      PL.rows.forEach((rc, pg) => { if (!first) doc.addPage(); first = false;
        cleanHead(doc, (p.title || EMP().title) + (D.draft ? ' (Draft)' : ''), p.sub || EMP().store, D.when);
        const chunk = R.slice(k, k + rc); k += rc;
        doc.autoTable({ startY: TOP, margin: { left: 12, right: 12, bottom: 4 }, head: [cols.map(k2 => k2[1])], body: chunk.map(r => cols.map(k2 => cellText(r[k2[0]], '\n'))), pageBreak: 'avoid', rowPageBreak: 'avoid',
          headStyles: { fillColor: [44, 46, 51], textColor: 255, fontStyle: 'bold', fontSize: fs - 0.4, minCellHeight: HEAD, valign: 'middle' },
          styles: { fontSize: fs, textColor: INK, lineColor: [214, 214, 219], lineWidth: { bottom: 0.2 }, minCellHeight: PL.rh, valign: 'middle', overflow: 'ellipsize', cellPadding: { left: 1.8, right: 1.8, top: 0.5, bottom: 0.5 } }, alternateRowStyles: { fillColor: [249, 249, 250] },
          didParseCell: d => { const kk = cols[d.column.index][0]; d.cell.styles.halign = AL[kk] || 'left'; if (d.section !== 'body') return; const res = chunk[d.row.index]._res;
            if (kk === 'Counted') d.cell.styles.fontStyle = 'bold'; if (kk === 'Difference' || kk === 'Result') { d.cell.styles.fontStyle = 'bold'; d.cell.styles.textColor = C[res] || INK; } } });
        if (pg === PL.rows.length - 1) { const sub = q.subDate ? 'Submitted ' + mdy(q.subDate) + (q.subTime ? ' · ' + String(q.subTime).padStart(4, '0') + ' Hrs' : '') : '';
          const B = [['Counted by', q.name, [q.code, q.desig].filter(Boolean).join(' · '), sub]]; if (p.sign) B.push(meBox('Received & Reported by', D.draft ? '' : 'Locked ' + hrsDT(c.doneAt))); if (p.mgr) B.push(mgrBox());
          signBoxes(doc, BOT - 24, B, false); } }); });
    const photoFrom = doc.getNumberOfPages() + 1;
    if (p.photos !== false && x) for (const q of x.people) for (const ph of (q.photos || [])) { const src = paperSrc(ph.id); if (!src) continue; const sz = await imgSize(src); if (!sz) continue;
      doc.addPage('a4', 'portrait'); const PW = doc.internal.pageSize.getWidth(), PH = doc.internal.pageSize.getHeight();
      doc.setFont('helvetica', 'bold'); doc.setFontSize(13); doc.setTextColor(...INK); doc.text('Original signed sheet', 12, 14); doc.setDrawColor(214, 214, 219); doc.setLineWidth(0.4); doc.line(12, 18, PW - 12, 18);
      const s = Math.min((PW - 24) / sz[0], (PH - 32) / sz[1]); doc.addImage(src, 'JPEG', (PW - sz[0] * s) / 2, 22, sz[0] * s, sz[1] * s); }
    const n = doc.getNumberOfPages(); for (let i = 1; i <= n; i++) { doc.setPage(i); const PW = doc.internal.pageSize.getWidth(), PH = doc.internal.pageSize.getHeight(); doc.setFont('helvetica', 'normal'); doc.setFontSize(i >= photoFrom ? 9.5 : 7.5); doc.setTextColor(107, 111, 118);
      if (i >= photoFrom) doc.text('Page ' + i + ' of ' + n, PW - 12, 14, { align: 'right' }); else doc.text('Page ' + i + ' of ' + n, PW - 12, PH - 6.5, { align: 'right' }); }
    pdfSave(doc, D.file + '.pdf');
  } finally { loader(false); }
}
/* ---------------- Zero-stock watch (order-only articles) ---------------- */
function zwList() { S.zeroWatch = S.zeroWatch || []; return S.zeroWatch; }
let ZWI = null, ZWV = -1;
function zwWaiting(code) {
  if (!ZWI || ZWV !== DATAVER || ZWI._n !== S.lines.length) { ZWI = { _n: S.lines.length }; S.lines.forEach(l => { if (l.status === 'waiting' && !S.hold[l.id]) (ZWI[l.code] = ZWI[l.code] || []).push(l); }); ZWV = DATAVER; Object.keys(ZWI).forEach(k => { if (k !== '_n') ZWI[k].sort((a, b) => a.date.localeCompare(b.date)); }); }
  return (ZWI[code] || []).slice();
}
function zwRow(w) {
  const st = S.stock[w.code], inRep = !!st, qty = inRep ? Math.round((Number(st.qty) || 0) * 1000) / 1000 : null;
  const W = zwWaiting(w.code), need = Math.round(W.reduce((n, l) => n + (Number(l.qty) || 0), 0) * 1000) / 1000;
  const after = qty == null ? null : Math.round((qty - need) * 1000) / 1000;
  let k;
  if (qty == null) k = 'missing';
  else if (qty <= 0) k = qty < 0 ? 'neg' : 'ok';
  else if (need > 0) k = after > 0 ? 'extra' : after < 0 ? 'short' : 'covered';
  else k = 'extra';
  const acked = w.ack && Number(w.ack.qty) === qty && (k === 'extra' || k === 'neg');
  return { w, code: w.code, name: inRep ? st.name : (w.name || itemName(w.code)), uom: inRep ? st.uom : (w.uom || itemUom(w.code)), qty, need, after, W, k, acked, alert: (k === 'extra' || k === 'neg') && !acked };
}
function zwRows() { return zwList().map(zwRow); }
const ZW_TAG = { ok: ['Zero · OK', 'c-ok'], extra: ['Above zero · check', 'c-no'], neg: ['Below zero · check', 'c-no'], covered: ['Covered by pending', 'c-gd'], short: ['Pending needs more', 'c-gd'], missing: ['Not in stock report', 'c-gy'] };
function zwHomeCard() {
  if (!zwList().length) return '';
  const R = zwRows(), al = R.filter(r => r.alert), cov = R.filter(r => r.k === 'covered' || r.k === 'short');
  if (!al.length && !cov.length) return '';
  const names = (al.length ? al : cov).slice(0, 3).map(r => r.name).join(', ') + ((al.length ? al : cov).length > 3 ? '…' : '');
  return '<button class="alertcard' + (al.length ? '' : ' soft') + '" data-a="zwOpen"><span class="ai">' + ico('alert', 22) + '</span><span style="flex:1;min-width:0"><b>Zero-stock watch</b><span>' +
    (al.length ? al.length + ' order-only article' + (al.length === 1 ? '' : 's') + ' not zero' : 'All clear after pending requests') + (al.length && cov.length ? ' · ' + cov.length + ' covered by pending' : !al.length ? ' · ' + cov.length + ' in stock for pending' : '') + '</span><span style="font-weight:600;opacity:.75;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;display:block">' + esc(names) + '</span></span>' + ico('right', 18) + '</button>';
}
function vZeroWatch() {
  ui.zw = ui.zw || { f: 'all', q: '', open: null, sel: null };
  const Z = ui.zw, R = zwRows();
  const n = k => R.filter(r => k(r)).length;
  let h = '<header class="top"><div><button class="btn sm ghost" data-a="back">‹ Back</button><h1 style="margin-top:10px">Zero-stock watch</h1><div class="sub">Order-only articles. They are not kept in the store, so their stock should be zero. Anything above zero needs a check.</div></div></header><main>';
  h += stockCard();
  h += '<div class="grid3"><div class="tile t-in"><b>' + R.length + '</b><span>Watching</span></div><div class="tile t-no"><b>' + n(r => r.alert) + '</b><span>Need a check</span></div><div class="tile t-ok"><b>' + n(r => r.k === 'ok') + '</b><span>Zero · OK</span></div></div>';
  h += '<div class="grid3"><div class="tile t-pt"><b>' + n(r => r.W.length) + '</b><span>With pending</span></div><div class="tile t-pt"><b>' + n(r => r.k === 'covered') + '</b><span>Zero after issue</span></div><div class="tile"><b>' + n(r => r.acked || r.k === 'missing') + '</b><span>Checked / not found</span></div></div>';
  h += '<div class="grid2"><button class="btn main" data-a="zwAdd">+ Add articles</button><button class="btn" data-a="zwExport"' + (R.length ? '' : ' disabled') + '>Download</button></div>';
  if (!R.length) return h + '<div class="card pad note">No articles yet. Tap <b>Add articles</b> and pick them from your stock report by name or item code.</div></main>';
  h += '<div class="seg">' + [['all', 'All'], ['alert', 'Check'], ['ok', 'Zero'], ['pend', 'Pending']].map(([k, l]) => '<button data-a="zwF" data-v="' + k + '" class="' + (Z.f === k ? 'on' : '') + '">' + l + '</button>').join('') + '</div>';
  h += '<div class="sbox"><svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"><circle cx="11" cy="11" r="7"/><path d="M20 20l-4-4"/></svg><input type="search" data-zw="q" value="' + esc(Z.q) + '" placeholder="Search watched articles" autocomplete="off"></div>';
  h += '<div class="row" style="justify-content:space-between"><span class="note">' + (Z.sel ? Z.sel.length + ' selected' : 'Tap an article for details') + '</span>' + (Z.sel ? '<span class="row" style="gap:8px"><button class="btn sm danger-t" data-a="zwBDel"' + (Z.sel.length ? '' : ' disabled') + '>Remove</button><button class="btn sm ghost" data-a="zwSel">Done</button></span>' : '<button class="btn sm ghost" data-a="zwSel">Select</button>') + '</div>';
  h += '<div id="zwres">' + zwResults() + '</div>';
  return h + '</main>';
}
function zwResults() {
  const Z = ui.zw, q = String(Z.q || '').trim().toUpperCase(), words = q.split(/\s+/).filter(Boolean);
  const rank = { extra: 0, neg: 1, short: 2, covered: 3, missing: 4, ok: 5 };
  let R = zwRows();
  if (words.length) R = R.filter(r => words.every(w => r.code.toUpperCase().includes(w) || String(r.name).toUpperCase().includes(w)));
  if (Z.f === 'alert') R = R.filter(r => r.alert); else if (Z.f === 'ok') R = R.filter(r => r.k === 'ok'); else if (Z.f === 'pend') R = R.filter(r => r.W.length);
  R.sort((a, b) => (a.alert ? 0 : 1) - (b.alert ? 0 : 1) || rank[a.k] - rank[b.k] || String(a.name).localeCompare(String(b.name)));
  if (!R.length) return '<div class="card pad note">Nothing here.</div>';
  return '<div class="card" style="overflow:hidden">' + R.map(r => {
    const open = Z.open === r.code, sel = Z.sel && Z.sel.includes(r.code), T = ZW_TAG[r.k];
    let x = '<div class="stkitem' + (open ? ' on' : '') + '"><button class="stkrow" data-a="' + (Z.sel ? 'zwPick' : 'zwOpenRow') + '" data-v="' + esc(r.code) + '">' + (Z.sel ? '<span class="zwck' + (sel ? ' on' : '') + '">' + (sel ? '✓' : '') + '</span>' : '') +
      '<span class="sn"><b>' + esc(r.name) + '</b><span class="mono">' + esc(r.code) + '</span></span><span class="sq"><b' + (r.alert ? ' style="color:#C0264A"' : '') + '>' + (r.qty == null ? '–' : num(r.qty)) + '</b><small>' + esc(r.uom || '') + '</small></span></button>';
    x += '<div class="scrow" style="padding:0 18px 12px">' + pill(r.acked ? 'Checked · ' + num(r.qty) : T[0], r.acked ? 'c-gy' : T[1]) +
      (r.W.length ? '<span class="sc gd">pending ' + num(r.need) + ' · ' + r.W.length + ' request' + (r.W.length === 1 ? '' : 's') + '</span><span class="sc ' + (r.after === 0 ? 'ok' : 'no') + '">after issue ' + (r.after == null ? '–' : num(r.after)) + '</span>' : '') +
      (r.w.note ? '<span class="sc">' + esc(r.w.note) + '</span>' : '') + '</div>';
    if (open && !Z.sel) {
      x += '<div class="leftbox"><div class="zwnums"><div><span>Real stock now</span><b>' + (r.qty == null ? '–' : num(r.qty)) + ' <small>' + esc(r.uom || '') + '</small></b></div><div><span>Pending requests</span><b>' + num(r.need) + '</b></div><div><span>After all issued</span><b' + (r.after != null && r.after !== 0 ? ' style="color:#C0264A"' : '') + '>' + (r.after == null ? '–' : num(r.after)) + '</b></div></div>' +
        '<div class="note" style="margin:6px 0 8px">' + esc(stockAge()) + (r.k === 'missing' ? '. This item code is not in the stock report.' : r.k === 'covered' ? '. Stock is there only for pending requests. It will be zero once they are issued.' : r.k === 'short' ? '. Pending requests need ' + num(-r.after) + ' more than the stock.' : r.k === 'extra' ? '. ' + num(r.W.length ? r.after : r.qty) + ' extra that no request needs.' : '') + '</div>' +
        '<div class="lefthead">Pending for it · ' + r.W.length + '</div>' + (r.W.length ? r.W.map(l => '<div class="leftrow"><span><b><span class="reqno sm" data-req="' + esc(l.req) + '">' + esc(l.req) + '</span> ' + esc(l.store) + '</b><span>' + fmtShort(l.date) + (l.date > today() ? ' · scheduled' : '') + '</span></span><b class="qty">' + num(l.qty) + '</b></div>').join('') : '<div class="note">No pending request.</div>') +
        (r.w.ack ? '<div class="note" style="margin-top:8px">Checked by ' + esc(r.w.ack.by || 'you') + ' at ' + num(r.w.ack.qty) + ' · ' + esc(fmtDT(r.w.ack.at)) + '. Alerts again if the stock changes.</div>' : '') +
        '<div class="rqbtns" style="margin-top:10px;grid-template-columns:1fr 1fr 1fr">' + ((r.k === 'extra' || r.k === 'neg') ? '<button class="btn sm main" data-a="zwAck" data-v="' + esc(r.code) + '">' + (r.acked ? 'Undo checked' : 'I checked it') + '</button>' : '<button class="btn sm" data-a="stockOpenCode" data-v="' + esc(r.code) + '">Live stock</button>') +
        '<button class="btn sm" data-a="zwNote" data-v="' + esc(r.code) + '">Note</button><button class="btn sm danger-t" data-a="zwDel" data-v="' + esc(r.code) + '">Remove</button></div></div>';
    }
    return x + '</div>';
  }).join('') + '</div>';
}
function shZwAdd() {
  const Z = ui.sheet, q = String(Z.q || '').trim().toUpperCase(), words = q.split(/\s+/).filter(Boolean), have = new Set(zwList().map(w => w.code));
  let h = '<div class="row"><h2>Add articles</h2><button class="btn sm ghost" data-a="closeSheet">Close</button></div>';
  h += '<div class="note">Pick from your stock report by name or item code. ' + esc(stockAge()) + '.</div>';
  h += '<div class="seg">' + [['both', 'Name or code'], ['code', 'Item code'], ['name', 'Exact name']].map(([k, l]) => '<button data-a="zwBy" data-v="' + k + '" class="' + ((Z.by || 'both') === k ? 'on' : '') + '">' + l + '</button>').join('') + '</div>';
  h += '<div class="sbox"><svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"><circle cx="11" cy="11" r="7"/><path d="M20 20l-4-4"/></svg><input type="search" data-zwadd="q" value="' + esc(Z.q || '') + '" placeholder="' + (Z.by === 'code' ? 'Item code' : Z.by === 'name' ? 'Full item name' : 'Item name or code') + '" autocomplete="off"></div>';
  h += '<div id="zwaddres">' + zwAddResults() + '</div>';
  h += '<button class="btn main full" data-a="zwAddSave"' + (Z.sel.length ? '' : ' disabled') + '>' + (Z.sel.length ? 'Add ' + Z.sel.length + ' article' + (Z.sel.length === 1 ? '' : 's') : 'Select articles') + '</button>';
  return h;
}
function zwAddResults() {
  const Z = ui.sheet, by = Z.by || 'both', q = String(Z.q || '').trim().toUpperCase(), words = q.split(/\s+/).filter(Boolean), have = new Set(zwList().map(w => w.code));
  let L = Object.entries(S.stock).map(([c, v]) => ({ c, v }));
  if (by === 'code') L = q ? L.filter(x => x.c.toUpperCase().includes(q)) : [];
  else if (by === 'name') L = q ? L.filter(x => String(x.v.name).trim().toUpperCase() === q) : [];
  else if (words.length) L = L.filter(x => words.every(w => x.c.toUpperCase().includes(w) || String(x.v.name).toUpperCase().includes(w)));
  L.sort((a, b) => (Z.sel.includes(b.c) ? 1 : 0) - (Z.sel.includes(a.c) ? 1 : 0) || String(a.v.name).localeCompare(String(b.v.name)));
  let h = '';
  if (Z.sel.length) h += '<div class="note" style="padding:0 4px">Selected: ' + Z.sel.map(c => esc((S.stock[c] || {}).name || c)).join(', ') + '</div>';
  if (!Object.keys(S.stock).length) return h + '<div class="card pad note">No stock report yet. Upload one or update live stock first.</div>';
  if (!L.length) return h + '<div class="card pad note">' + (q ? (by === 'name' ? 'No item has exactly this name.' : 'No item matches.') : 'Type to search the stock report.') + '</div>';
  return h + '<div class="card" style="overflow:hidden;max-height:46vh;overflow-y:auto">' + L.slice(0, 80).map(x => { const on = Z.sel.includes(x.c), had = have.has(x.c);
    return '<button class="stkrow" data-a="zwAddPick" data-v="' + esc(x.c) + '"' + (had ? ' disabled style="opacity:.55"' : '') + '><span class="zwck' + (on ? ' on' : '') + '">' + (on || had ? '✓' : '') + '</span><span class="sn"><b>' + esc(x.v.name) + '</b><span class="mono">' + esc(x.c) + (had ? ' · already watched' : '') + '</span></span><span class="sq"><b>' + num(x.v.qty) + '</b><small>' + esc(x.v.uom) + '</small></span></button>'; }).join('') + '</div>' +
    (L.length > 80 ? '<div class="note" style="padding:0 4px">Showing 80 of ' + L.length + '. Type more to narrow.</div>' : '');
}
function vExpiry() {
  const all = expiryRows(), lim = expDays();
  const due = all.filter(r => r.left <= lim);
  const expd = due.filter(r => r.left < 0), soon = due.filter(r => r.left >= 0 && r.left <= 15), later = due.filter(r => r.left > 15);
  let h = '<header class="top"><div><button class="btn sm ghost" data-a="back">‹ Back</button><h1 style="margin-top:10px">Expiry Tracker</h1><div class="sub">Batches from your Daily Count Cycle expiring within ' + lim + ' days.</div></div></header><main>';
  h += '<div class="grid3"><div class="tile t-no"><b>' + expd.length + '</b><span>Expired</span></div><div class="tile t-pt"><b>' + soon.length + '</b><span>Within 15 days</span></div><div class="tile t-in"><b>' + later.length + '</b><span>16 to ' + lim + ' days</span></div></div>';
  h += '<div class="grid2"><label class="f">Alert window (days)<input type="number" inputmode="numeric" data-expdays="1" value="' + lim + '"></label><button class="btn" data-a="expExport" style="align-self:end">Download</button></div>';
  const sec = (title, list, cls) => { if (!list.length) return ''; let x = '<div class="sect">' + title + '</div><div class="card" style="overflow:hidden">';
    list.forEach(r => { x += '<div class="line"><div class="row"><b>' + esc(r.name) + '</b>' + pill(r.left < 0 ? 'Expired ' + (-r.left) + ' d ago' : r.left === 0 ? 'Expires today' : r.left + ' days left', cls) + '</div>' +
      '<div class="row" style="align-items:center">' + meta([esc(r.code), num(r.qty) + ' ' + esc(r.uom), r.mfd ? 'MFD ' + fmtShort(r.mfd) : '', 'EXP ' + fmtLong(r.exp)]) + '<button class="btn sm ghost" data-a="expClear" data-v="' + r.cid + '|' + r.idx + '|' + r.k + '">Cleared</button></div>' +
      '<div class="meta"><span>Counted ' + fmtShort(r.countDate) + '</span></div></div>'; });
    return x + '</div>'; };
  if (!due.length) h += '<div class="card pad note">Nothing expiring within ' + lim + ' days. Add batches with expiry dates in the Daily Count Cycle.</div>';
  h += sec('Expired', expd, 'c-no') + sec('Within 15 days', soon, 'c-no') + sec('16 to ' + lim + ' days', later, 'c-gd');
  return h + '</main>';
}
function doneRows() {
  return doneData().map(({ r, slips, left }) => ({ 'Request No': r.req, Store: r.store, 'Requested on': fmtLong(r.date), Slips: slips.map(e => e.slip), Serials: slips.map(e => e.serial || '–'), Status: left.length ? 'Partly done' : 'Fully done', 'Pending articles': left.map(l => itemName(l.code) + ' (' + l.code + ') ' + num(l.qty) + ' ' + itemUom(l.code)) }));
}
function doneData() {
  const f = fltGet('done');
  let R = requests().filter(r => r.lines.some(l => l.status === 'issued') && reqMatch(r, f));
  R = sortBy(R, getSort('done'), r => ({ req: r.req, store: r.store, date: r.date, ready: r.lines.filter(l => l.status === 'waiting').length, size: r.lines.length }));
  return R.map(r => { const slips = S.entries.filter(e => e.items.some(i => i.req === r.req) && (!f.id || entryDate(e) === f.id)); return { r, slips, left: r.lines.filter(l => l.status === 'waiting'), issued: r.lines.filter(l => l.status === 'issued').length, total: r.lines.filter(l => l.status !== 'dropped').length }; });
}
function vDone() {
  const D = doneData();
  let h = '<header class="top"><div><button class="btn sm ghost" data-a="back">‹ Back</button><h1 style="margin-top:10px">Done list</h1><div class="sub">Requests entered on CUIMS, with Slip and Serial. Use it to mark your paper.</div></div></header><main>';
  h += fltBar('done', true) + '<div class="row" style="justify-content:flex-end">' + sortPick('done') + '</div>';
  const full = D.filter(x => !x.left.length).length;
  h += '<div class="grid3"><div class="tile t-in"><b>' + D.length + '</b><span>Requests</span></div><div class="tile t-ok"><b>' + full + '</b><span>Fully done</span></div><div class="tile t-pt"><b>' + (D.length - full) + '</b><span>Partly done</span></div></div>';
  if (!D.length) h += '<div class="card pad note">Nothing done for these dates.</div>';
  D.forEach(({ r, slips, left, issued, total }) => {
    h += rqCard({ where: 'done', req: r.req, store: r.store, status: left.length ? [left.length + ' left', 'c-gd'] : ['Completed', 'c-ok'], meta: ['requested ' + fmtShort(r.date), issued + ' of ' + total + ' issued'], slips, left });
  });
  if (D.length) h += '<button class="btn" data-a="doneExport">Download done list</button>';
  return h + '</main>';
}
function vCountList() {
  const L = S.countList = S.countList || [], q = String(ui.clq || '').trim().toUpperCase(), words = q.split(/\s+/).filter(Boolean);
  let h = '<header class="top"><div><button class="btn sm ghost" data-a="back">‹ Back</button><h1 style="margin-top:10px">My count list</h1><div class="sub">Your high-value items for the Daily Count Cycle. Batches, MFD, expiry, differences and history work the same.</div></div></header><main>';
  if (ui.clWhy) h += '<div class="banner t-no" style="display:block"><b>Today\'s count could not start.</b> ' + (ui.clWhy === 'empty' ? 'Your count list is empty.' : 'None of the ' + L.length + ' items in your list are in the current stock report (' + esc(stockAge()) + ').') + ' Add items below, then open Daily Count Cycle again.</div>';
  h += '<div class="card pad col" style="gap:10px"><label class="f">Items to count per day<input type="number" inputmode="numeric" data-cperday="1" value="' + esc(S.countPerDay || '') + '" placeholder="All ' + L.length + ' every day"></label><div class="note">Leave empty to count the whole list daily, or set a number to rotate through the list (e.g. 10 a day).</div></div>';
  h += '<div class="sbox"><svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"><circle cx="11" cy="11" r="7"/><path d="M20 20l-4-4"/></svg><input type="search" data-clq="1" value="' + esc(ui.clq || '') + '" placeholder="Search stock to add an item" autocomplete="off"></div>';
  h += '<div id="clres">' + clResults() + '</div>';
  h += '<div class="shead"><div><h2>In my list · ' + L.length + '</h2><span>Counted in this order</span></div></div>';
  if (!L.length) h += '<div class="card pad note">No items yet. Search above and tap + Add.</div>';
  else h += '<div class="card" style="overflow:hidden">' + L.map((k, i) => { const it = S.stock[k]; return '<div class="line" style="flex-direction:row;align-items:center;gap:8px"><b style="width:26px;color:var(--mute)">' + (i + 1) + '</b><span style="flex:1;min-width:0"><b>' + esc(it ? it.name : k) + '</b><div class="meta"><span class="mono">' + esc(k) + '</span><i></i><span>' + (it ? num(it.qty) + ' ' + esc(it.uom) : 'not in stock list') + '</span></div></span><button class="xbtn" data-a="clMove" data-v="' + i + '|-1" aria-label="Move up"' + (i ? '' : ' disabled') + '>' + ico('up', 16) + '</button><button class="xbtn" data-a="clMove" data-v="' + i + '|1" aria-label="Move down"' + (i < L.length - 1 ? '' : ' disabled') + '>' + ico('down', 16) + '</button><button class="xbtn" data-a="clDel" data-v="' + esc(k) + '" aria-label="Remove">' + ico('x', 16) + '</button></div>'; }).join('') + '</div>';
  if (L.length) h += '<button class="btn ghost danger-t" data-a="clClear">Clear the whole list</button>';
  return h + '</main>';
}
function clResults() {
  const q = String(ui.clq || '').trim().toUpperCase(), words = q.split(/\s+/).filter(Boolean); if (!words.length) return '';
  const L = new Set(S.countList || []);
  const R = Object.entries(S.stock).filter(([c, v]) => words.every(w => c.includes(w) || String(v.name).toUpperCase().includes(w))).slice(0, 25);
  if (!R.length) return '<div class="card pad note">No stock item matches.</div>';
  return '<div class="card" style="overflow:hidden">' + R.map(([c, v]) => '<div class="line" style="flex-direction:row;align-items:center;gap:10px"><span style="flex:1;min-width:0"><b>' + esc(v.name) + '</b><div class="meta"><span class="mono">' + esc(c) + '</span><i></i><span>' + num(v.qty) + ' ' + esc(v.uom) + '</span></div></span>' + (L.has(c) ? pill('In list', 'c-ok') : '<button class="btn sm main" data-a="clAdd" data-v="' + esc(c) + '">+ Add</button>') + '</div>').join('') + '</div>';
}
function vCountLog() {
  countRetire();
  const L = (S.counts || []).filter(c => c.status !== 'void' && c.mode !== 'emp').slice().sort((a, b) => String(b.doneAt || b.startedAt || b.date).localeCompare(String(a.doneAt || a.startedAt || a.date)));
  let h = '<header class="top"><div><button class="btn sm ghost" data-a="back">‹ Back</button><h1 style="margin-top:10px">Count history</h1><div class="sub">Every Daily Count Cycle with its differences.</div></div></header><main>';
  if (!L.length) h += '<div class="card pad note">No counts yet. Open Daily Count Cycle to start one.</div>';
  L.forEach(c => { const sm = countSummary(c);
    h += '<button class="card pad tap col" style="gap:6px" data-a="countOpen" data-v="' + c.id + '"><div class="row"><b class="ttl">' + (c.status === 'done' ? esc(fmtDT(c.doneAt || c.startedAt)) : fmtLong(c.date)) + '</b>' + (c.status === 'done' ? pill('Saved · locked', 'c-ok') : c.status === 'old' ? pill('Old random count', 'c-gy') : pill('Draft', 'c-gd')) + '</div>' +
      meta([sm.m + ' match', sm.ex + ' excess', sm.sh + ' short', sm.left ? sm.left + ' not counted' : '', c.by && c.by.name ? esc(c.by.name) : '']) + '</button>'; });
  if (L.length) h += '<button class="btn" data-a="countExportAll">Download all counts</button>';
  return h + '</main>';
}
function countRows(list) {
  const rows = []; list.forEach(c => c.items.forEach((i, n) => { const d = diffOf(i), res = d === null ? 'Not counted' : d === 0 ? 'Match' : d > 0 ? 'Excess' : 'Short';
    rows.push({ _k: c.id + '|' + i.code, _res: res, Count: c.status === 'done' ? hrsDT(c.doneAt || c.startedAt) : fmtLong(c.date) + ' (draft)', '#': n + 1, 'Item code': i.code, Item: i.name, UOM: i.uom, 'System stock': Number(i.system) || 0, Counted: i.physical === '' || i.physical == null ? '–' : Number(i.physical), Difference: d === null ? '' : (d > 0 ? '+' : '') + num(d), Result: res,
      'Batches (Qty · MFD · Expiry)': (i.variants || []).map(v => num(v.qty) + (v.mfd ? ' · MFD ' + mdy(v.mfd) : '') + (v.exp ? ' · EXP ' + mdy(v.exp) : '')), 'Counted by': (c.by || {}).name || '' }); }));
  return rows;
}
function mdy(iso) { const d = new Date(String(iso).length <= 10 ? iso + 'T00:00:00' : iso); if (isNaN(d)) return String(iso || ''); return MON3[d.getMonth()] + ' ' + String(d.getDate()).padStart(2, '0') + ', ' + d.getFullYear(); }
function hrs(iso) { const d = new Date(iso); if (isNaN(d)) return ''; return String(d.getHours()).padStart(2, '0') + String(d.getMinutes()).padStart(2, '0') + ' Hrs'; }
function hrsDT(iso) { return mdy(iso) + ' · ' + hrs(iso); }
const CNT_F = [['all', 'All'], ['diff', 'Differences'], ['short', 'Short'], ['excess', 'Excess'], ['match', 'Match'], ['nc', 'Not counted']];
function countFOk(f, res) { return f === 'all' || (f === 'diff' && (res === 'Short' || res === 'Excess')) || (f === 'short' && res === 'Short') || (f === 'excess' && res === 'Excess') || (f === 'match' && res === 'Match') || (f === 'nc' && res === 'Not counted'); }
function countDef() {
  const p = rptPref('counts'), list = (S.counts || []).filter(c => c.status !== 'void' && (!ui.countExportId || String(c.id) === String(ui.countExportId)));
  const all = countRows(list), off = (ui.sheet && ui.sheet.rowOff) || {};
  const rows = all.filter(r => countFOk(p.rowF || 'all', r._res) && !off[r._k]);
  const one = list.length === 1 ? list[0] : null, when = one ? (one.status === 'done' ? one.doneAt || one.startedAt : new Date().toISOString()) : new Date().toISOString();
  const K = ['#', 'Item code', 'Item', 'UOM', 'System stock', 'Counted', 'Difference', 'Result', 'Batches (Qty · MFD · Expiry)', 'Counted by'];
  const cols = (one ? K : ['Count'].concat(K)).map(k => [k, k]);
  const cnt = k => rows.filter(r => r._res === k).length;
  return { cols, rows, all, list, one, when, draft: !!(one && one.status !== 'done'), chips: [['Articles', rows.length], ['Match', cnt('Match')], ['Excess', cnt('Excess')], ['Short', cnt('Short')], ['Not counted', cnt('Not counted')]],
    file: 'Daily-Cycle-Count-' + isoOf(new Date(when)) + '-' + hrs(when).slice(0, 4), sub2: '' };
}
function cleanHead(doc, title, sub, when, storeRight) {
  const W = doc.internal.pageSize.getWidth(), GR = [107, 111, 118];
  doc.setTextColor(...INK); doc.setFont('helvetica', 'bold'); doc.setFontSize(19); doc.text(title, 12, 15);
  if (storeRight) { doc.setFontSize(12); doc.text(storeRight, W - 12, 15, { align: 'right' }); doc.setDrawColor(...INK); doc.setLineWidth(0.6); doc.line(12, 19, W - 12, 19); return 19; }
  if (sub) { doc.setFont('helvetica', 'normal'); doc.setFontSize(10); doc.setTextColor(...GR); doc.text(sub, 12, 21); }
  if (when) { doc.setFont('helvetica', 'bold'); doc.setFontSize(12); doc.setTextColor(...INK); doc.text(mdy(when), W - 12, 13, { align: 'right' });
    doc.setFont('helvetica', 'normal'); doc.setFontSize(10.5); doc.setTextColor(...GR); doc.text(hrs(when), W - 12, 19, { align: 'right' }); }
  doc.setDrawColor(...INK); doc.setLineWidth(0.6); doc.line(12, 24, W - 12, 24); return 24;
}
function cleanTiles(doc, y, chips, colors) {
  let x = 12; const GR = [107, 111, 118], LN = [214, 214, 219], tw = Math.min(40, (doc.internal.pageSize.getWidth() - 24 - (chips.length - 1) * 4) / chips.length);
  chips.forEach(([k, v]) => { doc.setDrawColor(...LN); doc.setLineWidth(0.3); doc.roundedRect(x, y, tw, 13, 2, 2, 'S');
    doc.setFont('helvetica', 'normal'); doc.setFontSize(7.5); doc.setTextColor(...GR); doc.text(String(k).toUpperCase(), x + 4, y + 4.8);
    doc.setFont('helvetica', 'bold'); doc.setFontSize(13); doc.setTextColor(...((colors || {})[k] || INK)); doc.text(String(v), x + 4, y + 10.6); x += tw + 4; });
  return y + 19;
}
function cleanFoot(doc) { const n = doc.getNumberOfPages(), W = doc.internal.pageSize.getWidth(), H = doc.internal.pageSize.getHeight();
  for (let i = 1; i <= n; i++) { doc.setPage(i); doc.setFont('helvetica', 'normal'); doc.setFontSize(7.5); doc.setTextColor(107, 111, 118); doc.text('Page ' + i + ' of ' + n, W - 12, H - 6.5, { align: 'right' }); } }
function signBoxes(doc, y, boxes, pen) {
  const W = doc.internal.pageSize.getWidth(), k = boxes.length; if (!k) return;
  const bw = k === 1 ? 80 : k === 2 ? Math.min(88, (W - 24 - 6) / 2) : (W - 24 - (k - 1) * 4) / k, hh = pen ? 28 : 22;
  boxes.forEach((b, i) => { const x = k === 2 && bw < (W - 24 - 6) / 2 ? (i ? W - 12 - bw : 12) : 12 + i * (bw + 4);
    doc.setDrawColor(232, 229, 223); doc.setFillColor(250, 249, 246); doc.setLineWidth(0.3); doc.roundedRect(x, y, bw, hh, 3, 3, 'FD');
    doc.setFont('helvetica', 'bold'); doc.setFontSize(7.6); doc.setTextColor(138, 106, 31); doc.text(String(b[0]).toUpperCase(), x + 4, y + 6);
    if (pen) { doc.setDrawColor(180); doc.line(x + 4, y + 17, x + bw - 4, y + 17);
      doc.setTextColor(...INK); doc.setFontSize(9.5); doc.text(b[1] || ' ', x + 4, y + 22.5);
      doc.setFont('helvetica', 'normal'); doc.setFontSize(7.8); doc.setTextColor(107, 111, 118); doc.text(b[2] || ' ', x + 4, y + 26.2); }
    else { doc.setTextColor(...INK); doc.setFontSize(9.8); doc.text(b[1] || ' ', x + 4, y + 12.5);
      doc.setFont('helvetica', 'normal'); doc.setFontSize(7.8); doc.setTextColor(107, 111, 118); doc.text(b[2] || ' ', x + 4, y + 16.6); if (b[3]) doc.text(b[3], x + 4, y + 20.3); } });
  return y + hh;
}
const meBox = (label, when) => [label, S.me.name || '', [S.me.emp, S.me.desig].filter(Boolean).join(' · '), when || ''];
const mgrBox = when => ['Manager', S.mgr.name || '', [S.mgr.emp, S.mgr.desig].filter(Boolean).join(' · '), when || ''];
function expiryPdf2(p, D) {
  const doc = pdfDoc(p.orient === 'l'); if (!doc) return;
  const W = doc.internal.pageSize.getWidth(), H = doc.internal.pageSize.getHeight(), fs = p.font === 's' ? 7.5 : p.font === 'b' ? 10 : 8.6, now = new Date().toISOString();
  const SC = { Expired: [191, 38, 59], 'Within 15 days': [179, 107, 0] }, scol = st => SC[st] || [41, 84, 191];
  cleanHead(doc, p.title || 'Expiry Tracker', p.sub, now);
  const st = D.rows.map(r => r.Status), win = 'Within ' + expDays() + ' days';
  let y = cleanTiles(doc, 29, [['Batches', D.rows.length], ['Expired', st.filter(x => x === 'Expired').length], ['Within 15 days', st.filter(x => x === 'Within 15 days').length], [win, st.filter(x => x === win).length]], { Expired: [191, 38, 59], 'Within 15 days': [179, 107, 0], [win]: [41, 84, 191] });
  const cols = orderedCols(p, D).filter(c => colOn(p, c[0])), AL = { Qty: 'right', UOM: 'center', MFD: 'center', Expiry: 'center', 'Days left': 'right', Status: 'center', 'Counted on': 'center' };
  doc.autoTable({ startY: y, margin: { left: 12, right: 12, bottom: 16 }, head: [cols.map(c => c[1])], body: D.rows.map(r => cols.map(c => cellText(r[c[0]], '\n'))),
    headStyles: { fillColor: [44, 46, 51], textColor: 255, fontStyle: 'bold', fontSize: fs, cellPadding: { top: 2.4, bottom: 2.4, left: 1.8, right: 1.8 } },
    styles: { fontSize: fs, textColor: INK, lineColor: [214, 214, 219], lineWidth: { bottom: 0.2 }, cellPadding: { top: 2.2, bottom: 2.2, left: 1.8, right: 1.8 }, valign: 'middle' }, alternateRowStyles: { fillColor: [249, 249, 250] },
    didParseCell: d => { const k = cols[d.column.index][0]; d.cell.styles.halign = AL[k] || 'left'; if (d.section !== 'body') return; const r = D.rows[d.row.index];
      if (k === 'Item' || k === 'Expiry') d.cell.styles.fontStyle = 'bold'; if (k === 'Days left' || k === 'Status') { d.cell.styles.fontStyle = 'bold'; d.cell.styles.textColor = scol(r.Status); } } });
  const B = []; if (p.sign) B.push(meBox('Prepared & checked by')); if (p.mgr) B.push(mgrBox());
  if (B.length) { let sy = doc.lastAutoTable.finalY + 10; if (sy + 30 > H - 14) { doc.addPage(); sy = 20; } signBoxes(doc, sy, B, true); }
  cleanFoot(doc); pdfSave(doc, 'Expiry-Tracker-' + isoOf(new Date()) + '.pdf');
}
function zwPdf2(p, D) {
  const doc = pdfDoc(p.orient === 'l'); if (!doc) return;
  const H = doc.internal.pageSize.getHeight(), fs = p.font === 's' ? 7.5 : p.font === 'b' ? 10 : 8.4, now = new Date().toISOString();
  const RED = [191, 38, 59], GRN = [26, 128, 69], AMB = [179, 107, 0], GRY = [107, 111, 118];
  const col = st => /check/.test(st) ? RED : /^Zero/.test(st) ? GRN : /pending|Pending/.test(st) ? AMB : GRY;
  cleanHead(doc, p.title || 'Zero-stock Watch', p.sub, now);
  const R = zwRows(), y = cleanTiles(doc, 29, [['Watching', R.length], ['Need a check', R.filter(r => r.alert).length], ['Zero · OK', R.filter(r => r.k === 'ok').length], ['Covered by pending', R.filter(r => r.k === 'covered' || r.k === 'short').length]], { 'Need a check': RED, 'Zero · OK': GRN, 'Covered by pending': AMB });
  const cols = orderedCols(p, D).filter(c => colOn(p, c[0])), AL = { UOM: 'center', 'Stock now': 'right', 'Pending qty': 'right', 'After all issued': 'right', Status: 'center' };
  doc.autoTable({ startY: y, margin: { left: 12, right: 12, bottom: 16 }, head: [cols.map(c => c[1])], body: D.rows.map(r => cols.map(c => cellText(r[c[0]], '\n'))),
    headStyles: { fillColor: [44, 46, 51], textColor: 255, fontStyle: 'bold', fontSize: fs, cellPadding: { top: 2.4, bottom: 2.4, left: 1.8, right: 1.8 } },
    styles: { fontSize: fs, textColor: INK, lineColor: [214, 214, 219], lineWidth: { bottom: 0.2 }, cellPadding: { top: 2.2, bottom: 2.2, left: 1.8, right: 1.8 }, valign: 'middle' }, alternateRowStyles: { fillColor: [249, 249, 250] },
    didParseCell: d => { const k = cols[d.column.index][0]; d.cell.styles.halign = AL[k] || 'left'; if (d.section !== 'body') return; const st = String(D.rows[d.row.index].Status || '');
      if (k === 'Item') d.cell.styles.fontStyle = 'bold'; if (k === 'Status' || (k === 'Stock now' && !/^Zero/.test(st))) { d.cell.styles.fontStyle = 'bold'; d.cell.styles.textColor = col(st); } if (k === 'Stock now' && /^Zero/.test(st)) d.cell.styles.fontStyle = 'bold'; } });
  const B = []; if (p.sign) B.push(meBox('Prepared & checked by')); if (p.mgr) B.push(mgrBox());
  if (B.length) { let sy = doc.lastAutoTable.finalY + 10; if (sy + 30 > H - 14) { doc.addPage(); sy = 20; } signBoxes(doc, sy, B, true); }
  cleanFoot(doc); pdfSave(doc, 'Zero-stock-Watch-' + isoOf(new Date()) + '.pdf');
}
function countPdf2(p, D) {
  const doc = pdfDoc(p.orient === 'l'); if (!doc) return;
  const W = doc.internal.pageSize.getWidth(), H = doc.internal.pageSize.getHeight(), fs = p.font === 's' ? 7.5 : p.font === 'b' ? 10 : 8.5;
  const GR = [107, 111, 118], LN = [214, 214, 219], C = { Match: [26, 128, 69], Excess: [41, 84, 191], Short: [191, 38, 59], 'Not counted': GR };
  doc.setTextColor(...INK); doc.setFont('helvetica', 'bold'); doc.setFontSize(20); doc.text((p.title || 'Daily Cycle Count') + (D.draft ? ' (Draft)' : ''), 12, 17);
  doc.setFontSize(12); doc.text(mdy(D.when), W - 12, 12.5, { align: 'right' });
  doc.setFont('helvetica', 'normal'); doc.setFontSize(10.5); doc.setTextColor(...GR); doc.text(hrs(D.when), W - 12, 18.5, { align: 'right' });
  let y = 23;
  if (p.sub) { doc.setFontSize(10); doc.setTextColor(...GR); doc.text(p.sub, 12, 22.5); y = 26; }
  doc.setDrawColor(...INK); doc.setLineWidth(0.6); doc.line(12, y, W - 12, y);
  if (p.tiles !== false) { let x = 12; const ty = y + 5;
    D.chips.forEach(([k, v]) => { doc.setDrawColor(...LN); doc.setLineWidth(0.3); doc.roundedRect(x, ty, 34, 13, 2, 2, 'S');
      doc.setFont('helvetica', 'normal'); doc.setFontSize(7.5); doc.setTextColor(...GR); doc.text(k.toUpperCase(), x + 4, ty + 4.8);
      doc.setFont('helvetica', 'bold'); doc.setFontSize(13); doc.setTextColor(...(C[k] || INK)); doc.text(String(v), x + 4, ty + 10.6); x += 38; });
    y = ty + 19; } else y += 6;
  const cols = orderedCols(p, D).filter(c => colOn(p, c[0]));
  const body = D.rows.map(r => cols.map(c => cellText(r[c[0]], '\n')));
  const AL = { '#': 'center', UOM: 'center', 'System stock': 'right', Counted: 'right', Difference: 'right', Result: 'center' };
  const colStyles = {}; cols.forEach((c, i) => { colStyles[i] = { halign: AL[c[0]] || 'left' }; if (c[0] === '#') colStyles[i].cellWidth = 9; if (c[0] === 'Batches (Qty · MFD · Expiry)') colStyles[i].fontSize = fs - 0.7; });
  doc.autoTable({ startY: y, margin: { left: 12, right: 12, bottom: 16 }, tableWidth: W - 24, head: [cols.map(c => c[1])], body, columnStyles: colStyles, rowPageBreak: 'avoid',
    headStyles: { fillColor: [44, 46, 51], textColor: 255, fontStyle: 'bold', fontSize: fs, cellPadding: { top: 2.4, bottom: 2.4, left: 1.8, right: 1.8 }, valign: 'middle' },
    styles: { fontSize: fs, textColor: INK, lineColor: LN, lineWidth: { bottom: 0.2 }, cellPadding: { top: 1.9, bottom: 1.9, left: 1.8, right: 1.8 }, valign: 'middle' },
    alternateRowStyles: { fillColor: [249, 249, 250] },
    didParseCell: d => { if (d.section === 'head') d.cell.styles.halign = AL[cols[d.column.index][0]] || 'left';
      if (d.section !== 'body') return; const k = cols[d.column.index][0], res = D.rows[d.row.index]._res;
      if (k === 'Counted') d.cell.styles.fontStyle = 'bold';
      if (k === 'Difference' || k === 'Result') { d.cell.styles.fontStyle = 'bold'; d.cell.styles.textColor = C[res] || INK; } } });
  if (p.sign || p.mgr) pdfSign(doc, p.sign, p.mgr);
  const n = doc.getNumberOfPages();
  for (let i = 1; i <= n; i++) { doc.setPage(i); doc.setFont('helvetica', 'normal'); doc.setFontSize(7.5); doc.setTextColor(...GR); doc.text('Page ' + i + ' of ' + n, W - 12, H - 6.5, { align: 'right' }); }
  pdfSave(doc, D.file + '.pdf');
}

/* ---------------- side drawer ---------------- */
function renderDrawer() {
  let el = document.getElementById('drawer'); if (!el) { el = document.createElement('div'); el.id = 'drawer'; document.body.appendChild(el); }
  if (!ui.drawer) { el.innerHTML = ''; return; }
  const item = (a, label, sub, d, v) => '<button class="ditem" data-a="' + a + '"' + (v ? ' data-v="' + v + '"' : '') + '><span class="dic"><svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">' + d + '</svg></span><span><b>' + label + '</b><span>' + sub + '</span></span></button>';
  el.innerHTML = '<div class="dbg" data-a="drawerClose"></div><aside class="dpanel" role="dialog" aria-label="Menu"><div class="dhead"><img src="icon.png" alt=""><div><b>JV Stock Issue</b><span>Built by ' + esc(S.me.builder || S.me.name || 'JV') + '</span></div></div>' +
    '<div class="dsect">Tools</div>' +
    item('empOpen', 'Employee Cycle Count', 'Staff count on paper · rounds', '<circle cx="9" cy="8" r="3.2"/><path d="M3.5 19c.6-3 2.8-4.6 5.5-4.6s4.9 1.6 5.5 4.6"/><path d="M16 6.5h5M16 10h5M17 13.5h4"/>') +
    item('dCount', 'Daily Count Cycle', 'Your count list, physical vs system', '<path d="M9 11l3 3 8-8"/><path d="M20 12v7a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h9"/>') +
    item('zwOpen', 'Zero-stock watch', 'Order-only articles that should be zero', '<circle cx="12" cy="12" r="8"/><path d="M6.5 17.5l11-11"/>') +
    item('expOpen', 'Expiry Tracker', 'Batches expiring within ' + expDays() + ' days', '<circle cx="12" cy="13" r="8"/><path d="M12 9v4l2.5 2.5M9 2h6"/>') +
    item('doneOpen', 'Done list', 'Slips, serials and articles still left', '<path d="M4 12l5 5L20 6"/>') +
    item('newReq', 'Add store request', 'Type a request directly in the app', '<path d="M12 5v14M5 12h14"/>') +
    item('batchReq', 'Batch add requests', 'Many stores at once, or paste from Excel', '<rect x="3" y="3" width="18" height="18" rx="2"/><path d="M3 9h18M9 3v18"/>') +
    item('stockOpen', 'Live stock search', 'Find any item, see needed and free qty', '<circle cx="11" cy="11" r="7"/><path d="M20 20l-4-4"/>') +
    item('consOpen', 'Store-wise consumption', 'What each store took, by week or month', '<path d="M4 20V10M10 20V4M16 20v-7M22 20H2"/>') +
    item('lkOpen', 'Link CUIMS serials', 'Requests issued on CUIMS outside the app', '<path d="M10 14a4 4 0 0 0 5.7 0l3-3a4 4 0 0 0-5.7-5.7l-1 1"/><path d="M14 10a4 4 0 0 0-5.7 0l-3 3a4 4 0 0 0 5.7 5.7l1-1"/>') +
    item('vrList', 'Verify on CUIMS', 'Check requests, returns or a whole day', '<path d="M12 3l8 4v5c0 5-3.5 8-8 9-4.5-1-8-4-8-9V7z"/><path d="M8.5 12l2.5 2.5 4.5-5"/>') +
    item('mgOpen', 'Manage data', 'Filter, select many, delete or complete', '<rect x="3" y="4" width="18" height="16" rx="3"/><path d="M7 9l2 2 4-4M7 15h10"/>') +
    item('artsOpen', 'Pending articles', 'Edit qty, hold or remove, one or many', '<path d="M8 6h13M8 12h13M8 18h13"/><path d="M3 6l1 1 2-2M3 12l1 1 2-2M3 18l1 1 2-2"/>') +
    item('dcOpen', 'Data check', 'Find clashes and errors, fix on the spot', '<path d="M12 3l8 4v5c0 5-3.5 8-8 9-4.5-1-8-4-8-9V7z"/><path d="M9 12l2 2 4-4"/>') +
    item('testToggle', S.testMode ? 'Leave Test mode' : 'Test mode', S.testMode ? 'Back to your real data' : 'Try things without touching real data', '<path d="M9 3h6M10 3v6l-5 9a2 2 0 0 0 2 3h10a2 2 0 0 0 2-3l-5-9V3"/>') +
    item('countLog', 'Count history', 'All past counts and differences', '<path d="M3 3v18h18"/><path d="M7 15l4-4 3 3 5-6"/>') +
    item('taskLog', 'Task log', 'Daily tasks: done, pending, not done', '<path d="M8 6h13M8 12h13M8 18h13"/><path d="M3 6h.01M3 12h.01M3 18h.01"/>') +
    '<div class="dsect">Work</div>' +
    item('dUpload', 'Upload', 'Requests, earlier pending, stock', '<path d="M12 21V9M7 14l5-5 5 5M4 3h16"/>') +
    item('dBulk', 'Edit all requests', 'Slip No, Request No, date, receiver', '<path d="M4 20h4L19 9l-4-4L4 16z"/>') +
    item('dSite', 'Issue CUIMS', 'Your emp ID', '<rect x="3" y="4" width="18" height="13" rx="2"/><path d="M8 21h8M12 17v4"/>') +
    item('dMgr', 'Live stock', 'Manager CUIMS', '<path d="M3 12h4l3 7 4-14 3 7h4"/>') +
    '<div class="dsect">Data</div>' +
    item('dBackup', 'Cloud backups', 'Restore, keep, delete', '<path d="M7 18a5 5 0 1 1 1-9.9A6 6 0 0 1 19 10a4 4 0 0 1-1 8z"/>') +
    item('dData', 'Downloads', 'Excel and PDF reports', '<path d="M12 3v12M7 10l5 5 5-5M4 21h16"/>') +
    '</aside>';
}

/* ---------------- export preview + settings ---------------- */
const REPORTS = {
  issue: { name: 'Daily Issue Register', pdf: true, landscape: true, dated: 'reg', details: true, sorts: true },
  ret: { name: 'Daily Return Register', pdf: true, landscape: false, dated: 'reg', details: true, sorts: true },
  pending: { name: 'Pending Report', pdf: true, landscape: true, sorts: true },
  requests: { name: 'Requests Register' }, entries: { name: 'Entries Log' }, items: { name: 'Entry Items' },
  empSheet: { name: 'Employee count sheets', pdf: true, landscape: false }, empResult: { name: 'Employee count result', pdf: true, landscape: false },
  stock: { name: 'Stock Now' }, returns: { name: 'Returns (all)' }, search: { name: 'Search Results' }, counts: { name: 'Daily Cycle Count', pdf: true, landscape: true }, expiry: { name: 'Expiry Tracker', pdf: true, landscape: false }, zwatch: { name: 'Zero-stock Watch', pdf: true, landscape: false }, done: { name: 'Done List', pdf: true, landscape: false }, cons: { name: 'Store-wise Consumption', pdf: true, landscape: false }, verify: { name: 'CUIMS Verification', pdf: true, landscape: false }, verifyItems: { name: 'CUIMS Verification · Articles', pdf: true, landscape: true }, arts: { name: 'Pending Articles', pdf: true, landscape: false }
};
function rptPref(type) {
  S.rp = S.rp || {};
  const R = REPORTS[type];
  const d = { title: R.name, sub: S.me.storeName || '', orient: R.landscape ? 'l' : 'p', font: 'n', details: !!R.details && type === 'ret', sign: true, mgr: S.mgr.on, sort: 'reqdate', cols: {} };
  const p = S.rp[type] = S.rp[type] || {};
  for (const k in d) if (!(k in p)) p[k] = d[k];
  if (type === 'zwatch' && !p.v2) { p.v2 = 1; p.title = 'Zero-stock Watch'; if (!p.sub) p.sub = S.me.storeName || 'Ration Store'; p.orient = 'p'; p.order = []; p.cols = { 'Pending requests': false }; }
  if (type === 'expiry' && !p.v2) { p.v2 = 1; p.title = 'Expiry Tracker'; if (!p.sub) p.sub = S.me.storeName || 'Ration Store'; }
  if (type === 'empSheet' && !p.v2) { p.v2 = 1; p.title = EMP().title; p.sub = EMP().store; p.orient = 'p'; p.order = []; p.cols = { UOM: false }; p.sign = true; }
  if (type === 'empResult' && !p.v2) { p.v2 = 1; p.title = EMP().title; p.sub = EMP().store; p.orient = 'p'; p.order = []; p.cols = { 'Mfg. Date': false, 'Expiry Date': false }; p.sign = true; p.photos = true; }
  if (type === 'counts' && !p.v2) { p.v2 = 1; p.title = 'Daily Cycle Count'; p.sub = ''; p.orient = 'l'; p.order = []; p.cols = { 'Counted by': false }; p.rowF = 'all'; p.tiles = true; }
  return p;
}
function sortStores(arr, key, how) { return arr.sort((a, b) => how === 'az' ? String(a[key]).localeCompare(String(b[key])) : byStore(a[key], b[key])); }
function reportDef(type) {
  if (type === 'counts') return countDef();
  if (type === 'empSheet') return empSheetDef();
  if (type === 'empResult') return empResultDef();
  const p = rptPref(type), d = ui.reg.date;
  if (type === 'issue') {
    const list = regEntries(), F = fltGet('reg');
    let G = sortBy(issueGroups(list), ['custom', 'az', 'time'].includes(p.sort) ? 'reqdate' : p.sort, g => ({ req: g.req, store: g.store, date: reqDateOfRaw(g.req), size: g.items.length }));
    return { cols: [['no', '#'], ['req', 'Request No'], ['rdate', 'Requisition Requested Date'], ['store', 'Store'], ['to', 'Issued to'], ['slips', 'Slip No'], ['serials', 'Serial No'], ['times', 'Time'], ['items', 'Items'], ['remarks', 'Remarks'], ['by', 'Entered by']],
      rows: G.map((g, i) => ({ no: i + 1, req: g.req || '–', rdate: reqDateOf(g.req), store: g.store, to: [...g.to], slips: g.slips.map(x => x.slip), serials: g.slips.map(x => x.serial || '______'), times: g.slips.map(x => x.time), items: g.count || g.items.length, remarks: [...g.remarks].join(', ') || '–', by: [...g.by] })),
      chips: [].concat(F.id ? [['Issue date', fmtLong(F.id)]] : []).concat(F.rd ? [['Request date', fmtLong(F.rd)]] : []).concat([['Requests', G.length], ['Items', list.reduce((n, e) => n + e.items.length, 0)]]),
      detail: G.map(g => ({ head: 'Request ' + (g.req || '–') + '   ·   ' + g.store + '   ·   ' + [...g.to].join(', ') + '   ·   Slips ' + g.slips.map(x => x.slip + (x.serial ? ' #' + x.serial : '')).join(', '),
        cols: ['S.No', 'Slip No', 'Item code', 'Item', 'UOM', 'Qty', 'Item remarks'], rows: g.items.map((x, i) => [i + 1, x.slip, x.code, x.name || itemName(x.code), x.uom || itemUom(x.code), num(x.qty), x.remark || '–']) })),
      file: 'Issue-Register-' + d, sub2: 'Issue · Department · Offline · HOSTEL MESS (GA)' };
  }
  if (type === 'ret') {
    let list = S.returns.filter(x => x.date === d);
    list = sortBy(list, ['custom', 'az', 'time'].includes(p.sort) ? 'reqdate' : p.sort, r => ({ req: r.no, store: r.store, date: r.date + ' ' + (r.time || ''), size: r.items.length }));
    return { cols: [['no', '#'], ['rno', 'Return No'], ['store', 'Store'], ['by', 'Returned by'], ['dt', 'Date & time'], ['against', 'Against'], ['serial', 'Serial No'], ['items', 'Items'], ['remarks', 'Remarks'], ['ent', 'Entered by']],
      rows: list.map((r, i) => ({ no: i + 1, rno: r.no, store: r.store, by: [rcvLabel(r.by)].concat(r.byName ? [r.byName] : []), dt: fmtShort(r.date) + ' ' + (r.time || ''), against: r.against, serial: r.serial || '______', items: r.items.length, remarks: r.remarks || '–', ent: [(r.enteredBy || {}).name || ''].concat((r.enteredBy || {}).emp ? [r.enteredBy.emp] : []) })),
      chips: [['Date', fmtLong(d)], ['Returns', list.length], ['Items', list.reduce((n, r) => n + r.items.length, 0)]],
      detail: list.map(r => ({ head: r.no + '   ·   ' + r.store + '   ·   Returned by ' + rcvLabel(r.by) + '   ·   Serial ' + (r.serial || '____'), cols: ['S.No', 'Item code', 'Item', 'UOM', 'Qty', 'Item remarks'], rows: r.items.map((x, i) => [i + 1, x.code, x.name || itemName(x.code), x.uom || itemUom(x.code), num(x.qty), x.remark || '–']) })),
      file: 'Return-Register-' + d, sub2: 'Return · Department · Against Issue No 1111' };
  }
  const objRows = type === 'zwatch' ? zwRows().map(r => ({ 'Item code': r.code, Item: r.name, UOM: r.uom || '', 'Stock now': r.qty == null ? 'Not in report' : r.qty, 'Pending qty': r.need, 'Pending requests': r.W.map(l => l.req + ' ' + l.store + ' (' + num(l.qty) + ')'), 'After all issued': r.after == null ? '–' : r.after, Status: r.acked ? 'Checked · ' + num(r.qty) : ZW_TAG[r.k][0], Note: r.w.note || '–' })) : type === 'pending' ? sortBy(rowsPending(), ['custom', 'az', 'time'].includes(p.sort) ? 'reqdate' : p.sort, r => ({ req: r['Request No'], store: r.Store, date: r['_date'] || '' })) : type === 'requests' ? rowsRequests() : type === 'entries' ? rowsEntries() : type === 'items' ? rowsItems() : type === 'stock' ? rowsStock() : type === 'returns' ? rowsReturns() : type === 'search' ? searchRows() : type === 'arts' ? artsList().sort((a, b) => byStore(a.l.store, b.l.store) || String(a.l.req).localeCompare(String(b.l.req), undefined, { numeric: true })).map(({ l, k }) => ({ Store: l.store, 'Request No': l.req, 'Requested on': fmtLong(l.date), Item: itemName(l.code), 'Item code': l.code, Qty: l.qty, UOM: itemUom(l.code), Status: k === 'issue' ? 'Ready' : k === 'later' ? 'Scheduled' : k === 'hold' ? 'On hold' : k === 'missing' ? 'Not in stock' : 'Short' })) : type === 'verifyItems' ? (() => { const R = (S.verifyReports || []).find(r => r.id === ui.vrep) || (S.verifyReports || [])[0] || {}; const out = []; Object.values(R.details || {}).forEach(D => { D.items.forEach(i => out.push({ Serial: D.serial, Slip: D.slip, 'Project Area': D.pa, 'Received by': D.rcv ? rcvLabel(D.rcv) : '', Code: i.code, Item: i.name, 'CUIMS qty': i.qty, 'App qty': i.app == null ? 'not in app' : i.app, Remarks: i.remark || '' })); D.missing.forEach(m => out.push({ Serial: D.serial, Slip: D.slip, 'Project Area': D.pa, 'Received by': D.rcv ? rcvLabel(D.rcv) : '', Code: m.code, Item: itemName(m.code), 'CUIMS qty': 'missing', 'App qty': m.qty, Remarks: '' })); }); return out; })() : type === 'verify' ? (((S.verifyReports || []).find(r => r.id === ui.vrep) || (S.verifyReports || [])[0] || { findings: [] }).findings.map(f => ({ Entry: f.label || (f.serial ? 'Serial ' + f.serial : ''), Result: { ok: 'All good', notFound: 'Not found on CUIMS', serial: 'Serial missing in app', multi: 'Slip used more than once', store: 'Store differs', rcv: 'Receiver differs', type: 'Not a return', missing: 'Missing on CUIMS', qty: 'Qty differs', remark: 'Remark differs', extra: 'Extra on CUIMS', notInApp: 'On CUIMS, not in app' }[f.kind] || f.kind, Item: f.code ? itemName(f.code) + ' (' + f.code + ')' : '', App: f.app != null ? String(f.app) : (f.qty != null ? String(f.qty) : ''), CUIMS: f.cuims != null ? String(f.cuims) : (f.val || f.serial || ''), Status: f.fixed ? 'Fixed in app' : (f.kind === 'ok' ? '' : 'Open') }))) : type === 'cons' ? consRows() : type === 'done' ? doneRows() : type === 'expiry' ? expiryRows().filter(r => r.left <= expDays()).map(r => ({ Item: r.name, Code: r.code, Qty: r.qty, UOM: r.uom, MFD: r.mfd ? fmtLong(r.mfd) : '', Expiry: fmtLong(r.exp), 'Days left': r.left, Status: r.left < 0 ? 'Expired' : r.left <= 15 ? 'Within 15 days' : 'Within ' + expDays() + ' days', 'Counted on': fmtLong(r.countDate) })) : type === 'counts' ? countRows((S.counts || []).filter(c => !ui.countExportId || String(c.id) === String(ui.countExportId))) : [];
  const keys = objRows.length ? Object.keys(objRows[0]) : [];
  const chips = type === 'pending' ? [['Date', fmtLong(today())], ['Stores', new Set(objRows.map(r => r.Store)).size], ['Articles', objRows.length]] : [['Date', fmtLong(today())], ['Rows', objRows.length]];
  return { cols: keys.map(k => [k, k]), rows: objRows, chips, file: REPORTS[type].name.replace(/[^A-Za-z]+/g, '-') + '-' + today(), sub2: '' };
}
function reqDateOfRaw(req) { const l = S.lines.find(x => x.req === req); return l ? l.date : ''; }
function reqDateOf(req) {
  if (!req) return '–';
  const ds = [...new Set(S.lines.filter(l => l.req === req).map(l => l.date))].sort();
  return ds.length ? ds.map(fmtLong) : '–';
}
function searchRows() { const rows = []; searchRecords().forEach(x => x.items.forEach(i => rows.push({ Type: x.type, Date: x.date ? fmtLong(x.date) : '', Time: x.time || '', 'Slip / Return No': x.no, 'Serial No': x.serial, Store: x.store, 'Issued to / Returned by': x.who, 'Request / Against': x.reqs, 'Item code': i.code, Item: i.name || itemName(i.code), Qty: Number(i.qty), UOM: i.uom || '', 'Item remark': i.remark || '', 'Entered by': x.by.name || '', 'Emp code': x.by.emp || '' }))); return rows; }
function colOn(p, k) { return p.cols[k] !== false; }
function orderedCols(p, D) { const o = p.order || []; return D.cols.slice().sort((a, b) => { const i = o.indexOf(a[0]), j = o.indexOf(b[0]); return (i < 0 ? 999 + D.cols.indexOf(a) : i) - (j < 0 ? 999 + D.cols.indexOf(b) : j); }); }
function cellText(v, sep) { return Array.isArray(v) ? v.join(sep) : v == null ? '' : String(v); }
function openExport(type) { rptPref(type); ui.sheet = { kind: 'export', type }; renderSheet(); }
function shExport() {
  const type = ui.sheet.type, R = REPORTS[type], p = rptPref(type), D = reportDef(type);
  const all = orderedCols(p, D), cols = all.filter(c => colOn(p, c[0]));
  let h = '<div class="row"><h2>' + esc(R.name) + '</h2><button class="btn sm ghost" data-a="closeSheet">Close</button></div>';
  h += '<div class="note">Your choices are saved for next time.</div>';
  h += '<div class="card pad col"><h3>Basics</h3><label class="f">Title<input type="text" data-rp="title" value="' + esc(p.title) + '"></label><label class="f">Subtitle (store name)<input type="text" data-rp="sub" value="' + esc(p.sub) + '"></label>' +
    (R.dated ? '<label class="f">Date<input type="date" data-in="regDate" value="' + esc(ui.reg.date) + '"></label>' : '') +
    (R.sorts ? '<label class="f">Order</label>' + pickBtn('rpSort', { title: 'Order', full: true, opts: SORT_OPTS, val: p.sort, set: v => { p.sort = v; save(true); renderSheet(); } }) : '') + '</div>';
  if (R.pdf) {
    h += '<div class="card pad col"><h3>Page</h3><div class="seg">' + [['p', 'A4 Portrait'], ['l', 'A4 Landscape']].map(([v, l]) => '<button data-a="rpSet" data-k="orient" data-v="' + v + '" class="' + (p.orient === v ? 'on' : '') + '">' + l + '</button>').join('') + '</div>' +
      '<div class="seg">' + [['s', 'Small text'], ['n', 'Normal'], ['b', 'Large text']].map(([v, l]) => '<button data-a="rpSet" data-k="font" data-v="' + v + '" class="' + (p.font === v ? 'on' : '') + '">' + l + '</button>').join('') + '</div>' +
      (R.details ? '<label class="chk"><input type="checkbox" data-a="rpTog" data-k="details"' + (p.details ? ' checked' : '') + '> Print item details under each ' + (type === 'issue' ? 'request' : 'return') + '</label>' : '') +
      '<label class="chk"><input type="checkbox" data-a="rpTog" data-k="sign"' + (p.sign ? ' checked' : '') + '> Signature box (Prepared & checked by)</label>' +
      '<label class="chk"><input type="checkbox" data-a="rpTog" data-k="mgr"' + (p.mgr ? ' checked' : '') + '> Manager signature box</label></div>';
  }
  if (type === 'empSheet' || type === 'empResult') {
    const off = ui.sheet.rowOff = ui.sheet.rowOff || {}, ppl = type === 'empSheet' ? (D.x ? D.x.people : []) : (D.x ? D.x.people : [{ name: '' }]);
    h += '<div class="card pad col" style="gap:10px"><div class="row"><h3>Rows</h3><span class="note">' + D.rows.length + ' of ' + D.all.length + ' articles printed</span></div>' +
      '<div class="grid2"><button class="btn sm" data-a="rpRowAll" data-v="on">Select all</button><button class="btn sm" data-a="rpRowAll" data-v="off">Clear all</button></div>' +
      '<div style="max-height:40vh;overflow-y:auto;border:1px solid #EEECF3;border-radius:16px">' + ppl.map((q, pi) => { const R = D.all.filter(r => r._p === pi); if (!R.length) return '';
        return (q.name ? '<div class="note" style="padding:8px 14px;background:#F1EEFB;font-weight:700;color:#141414">' + esc(q.name) + '</div>' : '') + R.map(r => '<button class="stkrow" data-a="rpRow" data-v="' + esc(r._k) + '"><span class="zwck' + (off[r._k] ? '' : ' on') + '">' + (off[r._k] ? '' : '✓') + '</span><span class="sn"><b>' + esc(r._lab) + '</b><span class="mono">' + esc(r._sub) + '</span></span></button>').join(''); }).join('') + '</div>' +
      (type === 'empResult' ? '<label class="chk"><input type="checkbox" data-a="rpTog" data-k="photos"' + (p.photos !== false ? ' checked' : '') + '> Add the original signed sheet photos at the end</label>' : '') + '</div>';
  }
  if (type === 'counts') {
    const off = ui.sheet.rowOff = ui.sheet.rowOff || {}, f = p.rowF || 'all', inF = D.all.filter(r => countFOk(f, r._res));
    h += '<div class="card pad col" style="gap:10px"><div class="row"><h3>Rows</h3><span class="note">' + D.rows.length + ' of ' + D.all.length + ' articles printed</span></div>' +
      '<div class="wrap" style="gap:6px">' + CNT_F.map(([k, l]) => '<button class="btn sm' + (f === k ? ' main' : '') + '" data-a="rpRowF" data-v="' + k + '">' + l + ' · ' + D.all.filter(r => countFOk(k, r._res)).length + '</button>').join('') + '</div>' +
      '<div class="grid2"><button class="btn sm" data-a="rpRowAll" data-v="on">Select all</button><button class="btn sm" data-a="rpRowAll" data-v="off">Clear all</button></div>' +
      '<div style="max-height:40vh;overflow-y:auto;border:1px solid #EEECF3;border-radius:16px">' + (inF.length ? inF.map(r => '<button class="stkrow" data-a="rpRow" data-v="' + esc(r._k) + '"><span class="zwck' + (off[r._k] ? '' : ' on') + '">' + (off[r._k] ? '' : '✓') + '</span><span class="sn"><b>' + esc(r.Item) + '</b><span class="mono">' + esc(r['Item code']) + (D.one ? '' : ' · ' + esc(r.Count)) + '</span></span>' + pill(r._res + (r.Difference ? ' ' + r.Difference : ''), r._res === 'Match' ? 'c-ok' : r._res === 'Excess' ? 'c-in' : r._res === 'Short' ? 'c-no' : 'c-gy') + '</button>').join('') : '<div class="pad note">No articles in this filter.</div>') + '</div>' +
      '<label class="chk"><input type="checkbox" data-a="rpTog" data-k="tiles"' + (p.tiles !== false ? ' checked' : '') + '> Totals boxes (Articles, Match, Excess, Short, Not counted)</label></div>';
  }
  h += '<div class="card" style="overflow:hidden"><div class="pad row"><h3>Columns and order</h3><span class="note">' + cols.length + ' of ' + D.cols.length + ' printed</span></div>' +
    all.map(([k, l], i) => '<div class="line" style="flex-direction:row;align-items:center;gap:8px;padding:8px 14px"><label class="chk" style="min-height:40px;font-size:14.5px;flex:1"><input type="checkbox" data-a="rpCol" data-k="' + esc(k) + '"' + (colOn(p, k) ? ' checked' : '') + '> ' + esc(l) + '</label>' +
      '<button class="xbtn" data-a="rpMove" data-k="' + esc(k) + '" data-d="-1"' + (i ? '' : ' disabled') + ' aria-label="Move up">' + ico('up', 18) + '</button><button class="xbtn" data-a="rpMove" data-k="' + esc(k) + '" data-d="1"' + (i < all.length - 1 ? '' : ' disabled') + ' aria-label="Move down">' + ico('down', 18) + '</button></div>').join('') + '</div>';
  // preview
  const pr = D.rows.slice(0, 8);
  if (type === 'expiry' || type === 'zwatch' || type === 'empSheet' || type === 'empResult') h += '<div class="sect">Preview</div><div class="card" style="overflow:hidden"><div style="padding:14px 14px 10px;border-bottom:2px solid #141414;display:flex;justify-content:space-between;align-items:flex-start;gap:10px"><span><b style="font-size:19px">' + esc(p.title || R.name) + '</b>' + (p.sub && type !== 'empSheet' ? '<div class="note">' + esc(p.sub) + '</div>' : '') + '</span><span style="text-align:right">' + (type === 'empSheet' ? '<b>' + esc(p.sub || '') + '</b>' : '<b>' + esc(mdy(D.when || new Date().toISOString())) + '</b><div class="note">' + esc(hrs(D.when || new Date().toISOString())) + '</div>') + '</span></div>' +
    '<div class="tblwrap" style="padding:0 0 6px"><table style="font-size:13px"><tr>' + cols.map(c => '<th>' + esc(c[1]) + '</th>').join('') + '</tr>' + (D.rows.slice(0, 8).map(r => '<tr>' + cols.map(c => '<td>' + esc(cellText(r[c[0]], ' ')) + '</td>').join('') + '</tr>').join('') || '<tr><td colspan="' + cols.length + '" class="note">No rows selected.</td></tr>') + '</table></div>' +
    (D.rows.length > 8 ? '<div class="note" style="padding:0 12px 10px">…and ' + (D.rows.length - 8) + ' more rows</div>' : '') +
    '<div class="note" style="padding:0 12px 12px">Signature boxes: ' + [type === 'empSheet' ? 'employee (sign here)' : type === 'empResult' ? 'employee' : '', p.sign ? (type === 'expiry' || type === 'zwatch' ? 'prepared & checked by you' : 'received & reported by you') : '', p.mgr ? 'manager' : ''].filter(Boolean).join(', ') + '</div></div>';
  else if (type === 'counts') h += '<div class="sect">Preview</div><div class="card" style="overflow:hidden"><div style="padding:14px 14px 10px;border-bottom:2px solid #141414;display:flex;justify-content:space-between;align-items:flex-start;gap:10px"><span><b style="font-size:19px">' + esc(p.title || 'Daily Cycle Count') + (D.draft ? ' (Draft)' : '') + '</b>' + (p.sub ? '<div class="note">' + esc(p.sub) + '</div>' : '') + '</span><span style="text-align:right"><b>' + esc(mdy(D.when)) + '</b><div class="note">' + esc(hrs(D.when)) + '</div></span></div>' +
    (p.tiles !== false ? '<div class="wrap" style="gap:6px;padding:10px 12px">' + D.chips.map(c => pill(c[0] + ' ' + c[1], 'c-gy')).join('') + '</div>' : '') +
    '<div class="tblwrap" style="padding:0 0 6px"><table style="font-size:13px"><tr>' + cols.map(c => '<th>' + esc(c[1]) + '</th>').join('') + '</tr>' + (D.rows.slice(0, 8).map(r => '<tr>' + cols.map(c => '<td style="white-space:pre-line' + ((c[0] === 'Difference' || c[0] === 'Result') ? ';font-weight:700;color:' + ({ Match: '#1A8045', Excess: '#2954BF', Short: '#BF263B' }[r._res] || '#6B6F76') : '') + '">' + esc(cellText(r[c[0]], '\n')) + '</td>').join('') + '</tr>').join('') || '<tr><td colspan="' + cols.length + '" class="note">No rows selected.</td></tr>') + '</table></div>' +
    (D.rows.length > 8 ? '<div class="note" style="padding:0 12px 10px">…and ' + (D.rows.length - 8) + ' more rows</div>' : '') +
    ((p.sign || p.mgr) ? '<div class="note" style="padding:0 12px 12px">+ ' + [p.sign ? 'your signature box' : '', p.mgr ? 'manager signature box' : ''].filter(Boolean).join(' and ') + '</div>' : '') + '</div>';
  else h += '<div class="sect">Preview</div><div class="card" style="overflow:hidden"><div style="background:linear-gradient(160deg,#1B2540,#0B1220);color:#fff;padding:12px 14px;border-bottom:2px solid var(--gold)"><b style="font-size:16px">' + esc(p.title) + '</b><div style="font-size:12px;color:#C9CED6">' + esc([p.sub, D.sub2].filter(Boolean).join(' · ')) + '</div></div>' +
    '<div class="wrap" style="gap:6px;padding:10px 12px">' + D.chips.map(c => pill(c[0] + ' ' + c[1], 'c-gd')).join('') + '</div>' +
    '<div class="tblwrap" style="padding:0 0 6px"><table style="font-size:' + (p.font === 's' ? 12 : p.font === 'b' ? 15 : 13.5) + 'px"><tr>' + cols.map(c => '<th>' + esc(c[1]) + '</th>').join('') + '</tr>' +
    (pr.length ? pr.map(r => '<tr>' + cols.map(c => '<td style="white-space:pre-line">' + esc(cellText(r[c[0]], '\n')) + '</td>').join('') + '</tr>').join('') : '<tr><td colspan="' + cols.length + '" class="note">No data for this selection.</td></tr>') + '</table></div>' +
    (D.rows.length > pr.length ? '<div class="note" style="padding:0 12px 10px">…and ' + (D.rows.length - pr.length) + ' more rows</div>' : '') +
    (R.pdf && p.details && D.detail && D.detail.length ? '<div class="note" style="padding:0 12px 10px">+ item details for ' + D.detail.length + ' ' + (type === 'issue' ? 'requests' : 'returns') + '</div>' : '') +
    (R.pdf && (p.sign || p.mgr) ? '<div class="note" style="padding:0 12px 12px">+ ' + [p.sign ? 'your signature box' : '', p.mgr ? 'manager signature box' : ''].filter(Boolean).join(' and ') + '</div>' : '') + '</div>';
  h += '<div class="grid2">' + (R.pdf ? '<button class="btn main" data-a="rpPdf"' + (D.rows.length && cols.length ? '' : ' disabled') + '>Download PDF</button>' : '') + '<button class="btn' + (R.pdf ? '' : ' main') + '" data-a="rpXlsx"' + (D.rows.length && cols.length ? '' : ' disabled') + '>Download Excel</button></div>';
  return h;
}
function rpPdf(type) { loader(true, 'Making your PDF'); setTimeout(() => { try { rpPdf2(type); } finally { loader(false); } }, 60); }
function rpPdf2(type) {
  const p = rptPref(type), D = reportDef(type), R = REPORTS[type];
  if (type === 'counts') return countPdf2(p, D);
  if (type === 'expiry') return expiryPdf2(p, D);
  if (type === 'zwatch') return zwPdf2(p, D);
  if (type === 'empSheet') return empSheetPdf(p, D);
  if (type === 'empResult') return empResultPdf(p, D);
  const doc = pdfDoc(p.orient === 'l'); if (!doc) return;
  const fs = p.font === 's' ? 7.5 : p.font === 'b' ? 10 : 8.5;
  const cols = orderedCols(p, D).filter(c => colOn(p, c[0]));
  const y0 = pdfHead(doc, p.title, [p.sub, D.sub2].filter(Boolean).join(' · '), D.chips);
  const st = Object.assign({}, TSTYLE, { styles: Object.assign({}, TSTYLE.styles, { fontSize: fs }), headStyles: Object.assign({}, TSTYLE.headStyles, { fontSize: fs }) });
  const WGT = { no: 3.5, req: 8.5, rdate: 11, store: 15, to: 22, slips: 9, serials: 8, times: 6.5, items: 6, remarks: 12, by: 14, rno: 10, dt: 13, against: 8, serial: 8, ent: 14 };
  const avail = doc.internal.pageSize.getWidth() - 24, known = cols.every(c => WGT[c[0]]), sumW = cols.reduce((n, c) => n + (WGT[c[0]] || 0), 0);
  const colStyles = {}; if (known) cols.forEach((c, i) => { colStyles[i] = { cellWidth: avail * WGT[c[0]] / sumW }; if (/^(no|items|times)$/.test(c[0])) colStyles[i].halign = 'center'; });
  const meEmp = String(S.me.emp || '').toUpperCase();
  const body = D.rows.map(r => cols.map(c => c[0] === 'by' || c[0] === 'ent' ? cellText(r[c[0]], '\n').replace(/\s*\((GA\d+)\)/gi, (m, g) => g.toUpperCase() === meEmp ? '' : '\n' + g) : cellText(r[c[0]], '\n')));
  const itemsIdx = cols.findIndex(c => c[0] === 'items'), foot = itemsIdx >= 0 ? [cols.map((c, i) => i === 0 ? { content: 'Total', colSpan: itemsIdx, styles: { halign: 'right' } } : i === itemsIdx ? String(D.rows.reduce((n, r) => n + (Number(r.items) || 0), 0)) : i < itemsIdx ? null : '').filter(x => x !== null)] : undefined;
  doc.autoTable(Object.assign({}, st, { startY: y0, tableWidth: avail, columnStyles: colStyles, pageBreak: 'auto', rowPageBreak: 'avoid', showFoot: 'lastPage', foot, footStyles: { fillColor: [247, 239, 217], textColor: INK, fontStyle: 'bold', fontSize: fs }, head: [cols.map(c => c[1])], body,
    didParseCell: d => { if (d.section === 'body') { const k = cols[d.column.index][0]; if (/req|store|Store|Request/.test(k)) d.cell.styles.fontStyle = 'bold'; if (/slips|Slip/.test(k)) d.cell.styles.textColor = [30, 58, 138]; if (/serial|Serial/.test(k)) d.cell.styles.textColor = [11, 94, 61]; } } }));
  if (p.details && D.detail) D.detail.forEach(b => {
    doc.autoTable(Object.assign({}, st, { startY: doc.lastAutoTable.finalY + 6, headStyles: { fillColor: [30, 41, 59], textColor: 255, fontStyle: 'bold', fontSize: fs }, head: [[{ content: b.head, colSpan: b.cols.length }], b.cols], body: b.rows }));
  });
  if (p.sign || p.mgr) pdfSign(doc, p.sign, p.mgr);
  pdfFoot(doc, R.name); pdfSave(doc, D.file + '.pdf');
}
function rpXlsx(type) { loader(true, 'Making your Excel file'); setTimeout(() => { try { rpXlsx2(type); } finally { loader(false); } }, 60); }
function rpXlsx2(type) {
  const p = rptPref(type), D = reportDef(type), R = REPORTS[type];
  const cols = orderedCols(p, D).filter(c => colOn(p, c[0]));
  const rows = D.rows.map(r => { const o = {}; cols.forEach(c => o[c[1]] = cellText(r[c[0]], ', ')); return o; });
  const sheets = [[R.name.slice(0, 30), rows]];
  if (p.details && D.detail && D.detail.length) { const dr = []; D.detail.forEach(b => b.rows.forEach(x => { const o = { Group: b.head }; b.cols.forEach((c, i) => o[c] = x[i]); dr.push(o); })); sheets.push(['Item details', dr]); }
  saveWb(sheets, D.file + '.xlsx');
}

/* ---------------- Google Sheet sync ---------------- */
async function syncNow(quiet, kind, note) {
  if (!S.sync.url) return;
  if (S.testMode) { if (!quiet) toast('Test mode: cloud backup is paused.'); return; }
  const payload = { action: 'sync', kind: kind || 'auto', note: note || '', counts: { requests: requests().length, articles: S.lines.length, entries: S.entries.length, returns: S.returns.length }, at: new Date().toISOString(), by: meTag(),
    tabs: { 'Requests': rowsRequests(), 'Request lines': rowsAllLines(), 'Entries': rowsEntries(), 'Entry items': rowsItems(), 'Pending': rowsPending(), 'Returns': rowsReturns(), 'Stock': rowsStock(),
      'Stores': Object.entries(S.stores).map(([s, v]) => ({ Store: s, Receiver: v.rcv ? rcvLabel(v.rcv) : '', Name: v.rname || '' })) },
    backup: JSON.stringify(S) };
  if (syncBusy) return; syncBusy = true; paintSync();
  const startedAt = S.sync.changedAt;
  try {
    if (!navigator.onLine) throw new Error('offline');
    const r = await fetch(S.sync.url, { method: 'POST', body: JSON.stringify(payload) });
    const j = await r.json();
    if (!j.ok) throw new Error(j.error || 'failed');
    S.sync.at = new Date().toISOString(); if (S.sync.changedAt === startedAt) { S.sync.dirty = false; S.sync.firstDirty = 0; } setTimeout(() => syncPhotos(true), 800); syncErr = ''; syncBusy = false; writeLocal(); paintSync();
    if (!quiet) { toast('Backed up to Google Drive and Sheet.'); render(); if (ui.sheet && ui.sheet.kind === 'backups') loadBackups(); }
  } catch (e) { syncBusy = false; syncErr = e.message; paintSync(); if (!quiet) toast(e.message === 'offline' ? 'Offline. Saved on phone; it uploads by itself when internet is back.' : 'Backup failed: ' + e.message + '. It will retry by itself.'); }
}
async function apiGet(q) { const r = await fetch(S.sync.url + (S.sync.url.includes('?') ? '&' : '?') + q); const j = await r.json(); if (!j.ok) throw new Error(j.error || 'failed'); return j; }
async function apiPost(o) { const r = await fetch(S.sync.url, { method: 'POST', body: JSON.stringify(o) }); const j = await r.json(); if (!j.ok) throw new Error(j.error || 'failed'); return j; }
async function loadBackups() {
  ui.sheet = Object.assign(ui.sheet || {}, { kind: 'backups', loading: true, err: '' }); renderSheet();
  try { const j = await apiGet('action=list'); ui.sheet.items = j.items; ui.sheet.folder = j.folder; ui.sheet.sheetUrl = j.sheet; }
  catch (e) { ui.sheet.err = 'Could not load backups: ' + e.message + '. If you just updated Code.gs, deploy it as a New version.'; }
  ui.sheet.loading = false; renderSheet();
}
function nextReqNo() {
  const d = new Date(), pre = pad(d.getDate()) + pad(d.getMonth() + 1) + '-';
  let mx = 0; S.lines.forEach(l => { if (String(l.req).startsWith(pre)) { const n = parseInt(String(l.req).slice(pre.length), 10); if (n > mx) mx = n; } });
  return pre + String(mx + 1).padStart(2, '0');
}
function nrHits() {
  const f = ui.form; const hits = itemHits(f.q, new Set(f.items.map(x => x.code)), 8);
  return String(f.q || '').trim() ? (hits.length ? hits.map(([c, v], k) => '<button class="hit' + (k === 0 ? ' first' : '') + '" data-a="nrPick" data-v="' + esc(c) + '"><span><b>' + esc(v.name) + '</b><span class="mono">' + esc(c) + '</span></span><span class="note">' + num(v.qty) + ' ' + esc(v.uom) + '</span></button>').join('') : '<div class="note">No item matches "' + esc(f.q) + '".</div>') : '';
}
function shNewReq() {
  const f = ui.form, stores = [...new Set([...(S.storeOrder || []), ...Object.keys(S.stores), ...S.lines.map(l => l.store)])].sort(byStore);
  const reqClash = S.lines.some(l => l.req === f.req);
  let h = '<div class="row"><h2>Add store request</h2><button class="btn sm ghost" data-a="closeSheet">Close</button></div>';
  h += '<label class="f">Store</label>' + pickBtn('nrStore', { title: 'Choose store', search: true, full: true, placeholder: 'Choose store', opts: stores.map(st => [st, st, (S.stores[st] || {}).rcv ? 'Receiver ' + rcvLabel(S.stores[st].rcv) : '']), val: f.store, set: v => { ui.form.store = v; const d = (S.stores[v] || {}).rcv; if (d) ui.form.rcv = d; renderSheet(); } });
  h += '<div class="grid2"><label class="f">Request No<input type="text" data-nr="req" value="' + esc(f.req) + '" class="mono' + (reqClash ? ' bad' : '') + '"></label><label class="f">Request date<input type="date" data-nr="date" value="' + esc(f.date) + '"></label></div>' + (reqClash ? '<div class="err">Request No ' + esc(f.req) + ' already exists.</div>' : '');
  h += '<div class="grid2"><label class="f">Receiver (GA or E code)<input type="text" inputmode="numeric" maxlength="6" data-nr="rcv" value="' + esc(f.rcv) + '" class="mono"></label><label class="f">Slip No (optional)<input type="text" data-nr="slip" value="' + esc(f.slip) + '" class="mono" autocapitalize="characters"></label></div>';
  h += '<label class="f">Custom remark (optional)<input type="text" data-nr="remark" value="' + esc(f.remark || '') + '" placeholder="Replaces Requisition Requested on …"></label>';
  h += '<div class="sect">Articles (' + f.items.length + ')</div>';
  if (f.items.length) h += '<div class="card" style="overflow:hidden">' + f.items.map((it, i) => '<div class="line" style="flex-direction:row;align-items:center;gap:10px"><span style="flex:1;min-width:0"><b>' + esc(it.name) + '</b><div class="meta"><span class="mono">' + esc(it.code) + '</span>' + (S.stock[it.code] ? '<i></i><span>stock ' + num(S.stock[it.code].qty) + '</span>' : '') + '</div></span><input type="number" inputmode="decimal" data-nrq="' + i + '" value="' + esc(it.qty) + '" placeholder="Qty" style="width:92px;text-align:right"><span class="note" style="width:34px">' + esc(it.uom) + '</span><button class="xbtn" data-a="nrDel" data-v="' + i + '" aria-label="Remove">' + ico('x', 16) + '</button></div>').join('') + '</div>';
  h += '<div class="card pad col" style="gap:8px"><label class="f">Find item by name or code<input type="search" data-nr="q" value="' + esc(f.q || '') + '" placeholder="Type e.g. atta, sugar, GR-198" autocomplete="off" enterkeyhint="done"></label>';
  h += '<div id="nrhits">' + nrHits() + '</div>';
  h += '</div>';
  const ok = f.store && f.req && !reqClash && f.items.length && f.items.every(x => parseFloat(x.qty) > 0) && (!f.rcv || validRcv(f.rcv)) && (!f.slip || !slipProblem(f.slip));
  if (f.slip && slipProblem(f.slip)) h += '<div class="err">' + esc(slipProblem(f.slip)) + '</div>';
  h += '<button class="btn main full" data-a="nrSave"' + (ok ? '' : ' disabled') + '>Save request · ' + f.items.length + ' articles</button>';
  return h;
}
function allStores() { return [...new Set([...(S.storeOrder || []), ...Object.keys(S.stores), ...S.lines.map(l => l.store), ...(S.areas || [])].filter(Boolean))].sort(byStore); }
function nextReqNoFrom(used) {
  const d = new Date(), pre = pad(d.getDate()) + pad(d.getMonth() + 1) + '-';
  let mx = 0; S.lines.concat(used.map(r => ({ req: r }))).forEach(l => { if (String(l.req).startsWith(pre)) { const n = parseInt(String(l.req).slice(pre.length), 10); if (n > mx) mx = n; } });
  return pre + String(mx + 1).padStart(2, '0');
}
function lastRetBy(store) { const r = S.returns.filter(x => x.store === store && validRcv(x.by)).sort((a, b) => String(b.date).localeCompare(String(a.date)))[0]; return r ? r.by : ((S.stores[store] || {}).rcv || ''); }
function batchAddGroup(store) {
  const f = ui.form;
  if (f.mode === 'return') { f.groups.push({ store, req: nextReturnNo(f.date, f.groups.map(g => g.req)), _auto: true, rcv: lastRetBy(store), slip: '', remark: '', items: [] }); f.act = f.groups.length - 1; return; }
  const req = nextReqNoFrom(f.groups.map(g => g.req));
  let slip = ''; if (f.slipStart) { const m = String(f.slipStart).toUpperCase().match(/^(.*?)(\d+)$/); if (m) { const used = allSlips(); f.groups.forEach(g => used.add(g.slip)); let n = parseInt(m[2], 10); do { slip = m[1] + String(n).padStart(m[2].length, '0'); n++; } while (used.has(slip)); } }
  f.groups.push({ store, req, rcv: (S.stores[store] || {}).rcv || '', slip, remark: '', items: [] }); f.act = f.groups.length - 1;
}
function itemHits(q, have, n) {
  q = String(q || '').trim().toUpperCase(); if (q.length < 1) return [];
  const words = q.split(/\s+/);
  return Object.entries(S.stock).filter(([c, v]) => !have.has(c) && words.every(w => c.includes(w) || String(v.name).toUpperCase().includes(w)))
    .sort((a, b) => (a[0] === q ? -2 : 0) - (b[0] === q ? -2 : 0) || (String(a[1].name).toUpperCase().startsWith(q) ? 0 : 1) - (String(b[1].name).toUpperCase().startsWith(q) ? 0 : 1) || String(a[1].name).localeCompare(String(b[1].name))).slice(0, n || 6);
}
function batchHits(gi) {
  const f = ui.form, g = f.groups[gi];
  const hits = itemHits(f.q, new Set(g.items.map(x => x.code)), 6);
  return String(f.q || '').trim() ? (hits.length ? hits.map(([c, v], k) => '<button class="hit' + (k === 0 ? ' first' : '') + '" data-a="btPick" data-v="' + esc(c) + '"><span><b>' + esc(v.name) + '</b><span class="mono">' + esc(c) + '</span></span><span class="note">' + num(v.qty) + ' ' + esc(v.uom) + '</span></button>').join('') : '<div class="note">No match in the stock sheet.</div>') : '';
}
function shBatch() {
  const f = ui.form, stores = allStores();
  const RET = f.mode === 'return';
  if (RET) { const used = []; f.groups.forEach(g => { if (g._auto) g.req = nextReturnNo(f.date, used); used.push(g.req); }); }
  let h = '<div class="row"><h2>' + (RET ? (f.single ? 'New return' : 'Batch add returns') : 'Batch add requests') + '</h2><button class="btn sm ghost" data-a="closeSheet">Close</button></div>';
  h += RET ? '<label class="f">Returns came on (in every remark)<input type="date" data-bt="date" value="' + esc(f.date) + '"></label>'
    : '<div class="grid2"><label class="f">Request date<input type="date" data-bt="date" value="' + esc(f.date) + '"></label><label class="f">First Slip No<input type="text" data-bt="slipStart" value="' + esc(f.slipStart || '') + '" class="mono" placeholder="optional, e.g. JV/1042" autocapitalize="characters"></label></div>';
  f.groups.forEach((g, gi) => {
    const act = f.act === gi;
    if (!act) { h += '<button class="card bmini" data-a="btAct" data-v="' + gi + '"><span class="reqno">' + esc(g.req) + '</span><b>' + esc(g.store) + '</b><span class="note">' + g.items.length + ' articles' + (g.items.some(x => !(parseFloat(x.qty) > 0)) ? ' · qty missing' : '') + '</span>' + ico('down', 18) + '</button>'; return; }
    h += '<div class="card bgroup act" style="overflow:hidden"><div class="pad col" style="gap:10px"><div class="row"><span class="reqno">' + esc(g.req) + '</span><button class="xbtn" data-a="btDel" data-v="' + gi + '" aria-label="Remove store">' + ico('x', 16) + '</button></div><b class="ttl">' + esc(g.store) + '</b>' +
      (RET ? '<div class="grid2"><label class="f">Return No<input type="text" data-bg="' + gi + '|req" value="' + esc(g.req) + '" class="mono" autocapitalize="characters"></label><label class="f">By employee<input type="text" inputmode="numeric" maxlength="6" data-bg="' + gi + '|rcv" value="' + esc(g.rcv) + '" class="mono"></label></div>' +
        '<div class="note mono" style="color:#2F6FE0">' + esc(retRemark({ store: g.store, recvDate: f.date })) + '</div></div>'
      : '<div class="grid3"><label class="f">Request No<input type="text" data-bg="' + gi + '|req" value="' + esc(g.req) + '" class="mono"></label><label class="f">Receiver<input type="text" inputmode="numeric" maxlength="6" data-bg="' + gi + '|rcv" value="' + esc(g.rcv) + '" class="mono"></label><label class="f">Slip No<input type="text" data-bg="' + gi + '|slip" value="' + esc(g.slip) + '" class="mono" autocapitalize="characters"></label></div>' +
      '<label class="f">Custom remark (optional)<input type="text" data-bg="' + gi + '|remark" value="' + esc(g.remark) + '"></label></div>') +
      g.items.map((it, ii) => '<div class="line" style="flex-direction:row;align-items:center;gap:10px"><span style="flex:1;min-width:0"><b>' + esc(it.name) + '</b><div class="meta"><span class="mono">' + esc(it.code) + '</span>' + (S.stock[it.code] ? '<i></i><span>stock ' + num(S.stock[it.code].qty) + '</span>' : '') + '</div></span><input type="number" inputmode="decimal" enterkeyhint="next" data-bq="' + gi + '|' + ii + '" value="' + esc(it.qty) + '" placeholder="Qty" style="width:88px;text-align:right"><button class="xbtn" data-a="btItemDel" data-v="' + gi + '|' + ii + '" aria-label="Remove">' + ico('x', 16) + '</button></div>').join('') +
      '<div class="pad col" style="gap:8px;background:var(--soft)"><div class="sbox"><svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"><circle cx="11" cy="11" r="7"/><path d="M20 20l-4-4"/></svg><input type="search" data-bt="q" value="' + esc(f.q || '') + '" placeholder="Add item: type name or code" autocomplete="off" enterkeyhint="done"></div><div id="bthits">' + batchHits(gi) + '</div></div></div>';
  });
  if (!(RET && f.single && f.groups.length)) h += pickBtn('btStore', { title: 'Add a store', search: true, full: true, placeholder: RET ? (f.groups.length ? '+ Another return (store)' : '+ Choose the store it came from') : '+ Add a store', opts: stores.map(st => [st, st, (S.stores[st] || {}).rcv ? 'Receiver ' + rcvLabel(S.stores[st].rcv) : '']), val: '', set: v => { batchAddGroup(v); ui.form.q = ''; renderSheet(); const i = document.querySelector('[data-bt="q"]'); if (i) i.focus(); } });
  h += '<details class="card pad"><summary><b>Paste rows from Excel</b></summary><div class="note" style="margin:8px 0">One row per article: <b>Store, Item code, Qty</b> (tab or comma). Optional 4th column: ' + (RET ? 'Return No' : 'Request No') + '.</div><textarea data-bt="paste" rows="5">' + esc(f.paste || '') + '</textarea><button class="btn" data-a="btPaste" style="margin-top:8px">Add pasted rows</button></details>';
  const rows = f.groups.flatMap(g => g.items.map(it => ({ g, it })));
  if (rows.length) h += '<div class="sect">Preview · ' + rows.length + ' articles · ' + f.groups.length + (RET ? ' returns' : ' requests') + '</div><div class="card tblwrap"><table><tr><th>' + (RET ? 'Return' : 'Request') + '</th><th>Store</th><th>Item</th><th>Qty</th><th>' + (RET ? 'By employee' : 'Receiver') + '</th>' + (RET ? '' : '<th>Slip</th>') + '</tr>' +
    rows.map(({ g, it }) => '<tr><td><b>' + esc(g.req) + '</b></td><td>' + esc(g.store) + '</td><td>' + esc(it.name) + ' <span class="note mono">' + esc(it.code) + '</span></td><td' + (parseFloat(it.qty) > 0 ? '' : ' style="color:var(--noInk);font-weight:700"') + '>' + esc(it.qty || 'missing') + '</td><td>' + esc(g.rcv || '–') + (g.rcv && rcvName(g.rcv) ? ' ' + esc(rcvName(g.rcv)) : '') + '</td>' + (RET ? '' : '<td>' + esc(g.slip || '–') + '</td>') + '</tr>').join('') + '</table></div>';
  const bad = f.groups.find(g => !g.req || (RET ? S.returns.some(r => String(r.no).toUpperCase() === String(g.req).toUpperCase()) : S.lines.some(l => l.req === g.req)) || f.groups.filter(x => x.req === g.req).length > 1);
  if (bad) h += '<div class="err">' + (RET ? 'Return' : 'Request') + ' No ' + esc(bad.req) + ' is empty or already used.</div>';
  const badRcv = RET && f.groups.find(g => !validRcv(g.rcv || ''));
  if (badRcv) h += '<div class="err">' + esc(badRcv.store) + ': By employee needs 6 digits.</div>';
  const ok = rows.length && !bad && !badRcv && rows.every(({ it }) => parseFloat(it.qty) > 0);
  h += '<button class="btn main full" data-a="btSave"' + (ok ? '' : ' disabled') + '>' + (RET ? 'Save ' + f.groups.length + ' return' + (f.groups.length > 1 ? 's' : '') + ' · ' : 'Save all · ') + rows.length + ' articles</button>';
  if (RET && ok) h += '<button class="btn ret full" data-a="btSave" data-v="cuims">Save & return on CUIMS</button>';
  return h;
}
function shReqStatus() {
  const f = ui.form, L = S.lines.filter(l => l.req === f.req), store = (L[0] || {}).store || '';
  const left = L.filter(l => l.status === 'waiting').length;
  let h = '<div class="row"><h2>Request ' + esc(f.req) + '</h2><button class="btn sm ghost" data-a="closeSheet">Close</button></div>';
  h += '<div class="note">' + esc(store) + ' · ' + (left ? left + ' pending' : 'completed') + '. Close articles you will not issue, or make closed ones pending again.</div>';
  h += '<div class="card" style="overflow:hidden">' + L.map(l => {
    const st = l.status === 'issued' ? pill('Issued ' + (l.issued[0] ? l.issued[0].slip : ''), 'c-in') : l.status === 'waiting' ? pill('Pending', 'c-gd') : pill('Closed', 'c-gy');
    const btn = l.status === 'waiting' ? '<button class="btn sm ghost danger-t" data-a="rsClose" data-v="' + l.id + '">Close</button>' : l.status === 'dropped' ? '<button class="btn sm" data-a="rsOpen" data-v="' + l.id + '">Make pending</button>' : '';
    return '<div class="line" style="flex-direction:row;align-items:center;gap:10px"><span style="flex:1;min-width:0"><b>' + esc(itemName(l.code)) + '</b><div class="meta"><span class="mono">' + esc(l.code) + '</span><i></i><span>' + num(l.qty) + ' ' + esc(itemUom(l.code)) + '</span></div></span>' + st + btn + '</div>';
  }).join('') + '</div>';
  h += '<div class="card pad col" style="gap:8px"><b>Add a pending article</b><div class="grid2"><input type="text" data-cadd="code" value="' + esc(f.addCode || '') + '" placeholder="Item code" class="mono" autocapitalize="characters"><input type="number" inputmode="decimal" data-cadd="qty" value="' + esc(f.addQty || '') + '" placeholder="Qty"></div><button class="btn" data-a="rsAdd">+ Add as pending</button></div>';
  h += '<div class="grid2"><button class="btn danger-t" data-a="rsAll"' + (left ? '' : ' disabled') + '>Mark completed</button><button class="btn" data-a="corrOpen" data-v="' + esc(f.req) + '">Correct quantities</button></div>';
  return h;
}
function shMslips() {
  const f = ui.form, r = requests().find(x => x.req === f.req);
  if (!r) return '<div class="row"><h2>Request ' + esc(f.req) + '</h2><button class="btn sm ghost" data-a="closeSheet">Close</button></div><div class="card pad note">This request is not in the app.</div>';
  const W = r.lines.filter(l => l.status === 'waiting'), sl = reqSlips(r.req);
  let h = '<div class="row"><h2>Slips for ' + esc(r.req) + '</h2><button class="btn sm ghost" data-a="closeSheet">Done</button></div>';
  h += '<div class="note">' + esc(r.store) + ' · ' + W.length + ' pending of ' + r.lines.filter(l => l.status !== 'dropped').length + '. Add as many slips as were made on CUIMS, one after another.</div>';
  h += '<div class="slips card" style="padding:10px">' + (sl.length ? sl.map(e => slipRow(e, r.req)).join('') : '<div class="slipline none">No slip entered yet</div>') + '</div>';
  if (!W.length) return h + '<div class="okbox"><span>All articles of this request are issued or closed.</span></div>';
  h += '<div class="card pad col" style="gap:10px"><div class="row"><b class="ttl" style="font-size:17px">Add slip ' + (sl.length + 1) + '</b><span class="stag man" style="position:static">Manual</span></div>' +
    '<div class="grid2"><label class="f">Slip No<input type="text" data-f="slip" value="' + esc(f.slip) + '" class="mono" autocapitalize="characters"></label><label class="f">Serial No<input type="text" data-f="serial" value="' + esc(f.serial) + '" class="mono" inputmode="numeric"></label></div>' +
    '<div class="grid2"><label class="f">Date<input type="date" data-f="date" value="' + esc(f.date) + '"></label><label class="f">Time<input type="time" data-f="time" value="' + esc(f.time) + '"></label></div>' +
    '<label class="f">Receiver (GA or E code)<input type="text" data-f="rcv" value="' + esc(f.rcv) + '" class="mono" inputmode="numeric" maxlength="6"></label>' +
    '<div class="grid2"><label class="f">Entered by<input type="text" data-f="byName" value="' + esc(f.byName) + '"></label><label class="f">Emp code<input type="text" data-f="byEmp" value="' + esc(f.byEmp) + '" autocapitalize="characters"></label></div>' +
    '<div class="row"><b>Articles in this slip</b><button class="btn sm ghost" data-a="msAll">' + (W.every(l => f.pick[l.id]) ? 'Untick all' : 'Tick all') + '</button></div>' +
    W.map(l => '<label class="chk" style="min-height:44px;gap:12px"><input type="checkbox" data-a="markPick" data-v="' + l.id + '"' + (f.pick[l.id] ? ' checked' : '') + '><span style="flex:1"><b>' + esc(itemName(l.code)) + '</b><span class="note mono" style="display:block">' + esc(l.code) + '</span></span><b class="qty">' + num(l.qty) + ' ' + esc(itemUom(l.code)) + '</b></label>').join('') +
    '<button class="btn main full" data-a="msSave">Save slip ' + (sl.length + 1) + ' · ' + W.filter(l => f.pick[l.id]).length + ' articles</button></div>';
  return h;
}
function shManReq() {
  const f = ui.form;
  let h = '<div class="row"><h2>' + (f._new ? 'Manual request' : 'Request ' + esc(f.req)) + '</h2><button class="btn sm ghost" data-a="closeSheet">Close</button></div>';
  h += '<div class="note">For requests done outside the app. No item details needed: just the slips, serials and article counts.</div>';
  h += '<div class="card pad col"><div class="grid2"><label class="f">Request No<input type="text" data-mr="req" value="' + esc(f.req) + '" class="mono"' + (f._new ? '' : ' disabled') + '></label><label class="f">Request date<input type="date" data-mr="date" value="' + esc(f.date) + '"></label></div>' +
    '<label class="f">Store</label>' + pickBtn('mrStore', { title: 'Store', search: true, full: true, placeholder: 'Choose store', opts: allStores().map(x => [x, x]), val: f.store, set: v => { ui.form.store = v; const d = S.stores[v] || {}; if (!ui.form.rcv && d.rcv) { ui.form.rcv = d.rcv; ui.form.rname = d.rname || ''; } renderSheet(); } }) +
    '<div class="grid2"><label class="f">Issued to (GA or E code)<input type="text" data-mr="rcv" value="' + esc(f.rcv) + '" class="mono" inputmode="numeric" maxlength="6"></label><label class="f">Receiver name<input type="text" data-mr="rname" value="' + esc(f.rname) + '"></label></div>' +

    '<label class="f">Total articles in the request<input type="number" inputmode="numeric" data-mr="total" value="' + esc(f.total) + '" placeholder="e.g. 14"></label></div>';
  h += '<div class="sect">Slips (' + f.slips.length + ')</div>';
  f.slips.forEach((x, i) => {
    h += '<div class="card pad col" style="gap:10px;box-shadow:inset 4px 0 0 #FFB648"><div class="row"><b>Slip ' + (i + 1) + '</b><button class="xbtn" data-a="mrDel" data-v="' + i + '" aria-label="Remove slip">' + ico('x', 16) + '</button></div>' +
      '<div class="grid2"><label class="f">Slip No<input type="text" data-ms="' + i + '|slip" value="' + esc(x.slip) + '" class="mono" autocapitalize="characters"></label><label class="f">Serial No<input type="text" data-ms="' + i + '|serial" value="' + esc(x.serial) + '" class="mono" inputmode="numeric"></label></div>' +
      '<div class="grid2"><label class="f">Date<input type="date" data-ms="' + i + '|date" value="' + esc(x.date) + '"></label><label class="f">Time<input type="time" data-ms="' + i + '|time" value="' + esc(x.time) + '"></label></div>' +
      '<label class="f">Articles in this slip<input type="number" inputmode="numeric" data-ms="' + i + '|count" value="' + esc(x.count) + '" placeholder="e.g. 9"></label>' +
      '<div class="grid2"><label class="f">Entered by<input type="text" data-ms="' + i + '|byName" value="' + esc(x.byName != null ? x.byName : f.byName) + '"></label><label class="f">Emp code<input type="text" data-ms="' + i + '|byEmp" value="' + esc(x.byEmp != null ? x.byEmp : f.byEmp) + '" autocapitalize="characters"></label></div></div>';
  });
  h += '<button class="btn full" data-a="mrAdd">+ Add another slip</button>';
  const doneN = f.slips.reduce((n, x) => n + (parseInt(x.count, 10) || 0), 0), tot = parseInt(f.total, 10) || 0;
  h += '<div class="card pad col"><div class="row"><b>Status</b><span class="note">' + doneN + (tot ? ' of ' + tot : '') + ' articles in slips</span></div><div class="seg"><button data-a="mrSt" data-v="pending" class="' + (f.status !== 'done' ? 'on' : '') + '">Pending</button><button data-a="mrSt" data-v="done" class="' + (f.status === 'done' ? 'on' : '') + '">Completed</button></div></div>';
  h += '<button class="btn main full" data-a="mrSave">Save request</button>';
  if (!f._new) h += '<button class="btn ghost danger-t full" data-a="mrRemove">Delete this manual request</button>';
  h += '<button class="btn ghost full" data-a="newManualFreeOld">Enter full item details instead</button>';
  return h;
}
function corrRows(req) {
  const L = S.lines.filter(l => l.req === req && l.status !== 'dropped');
  const by = {}; L.forEach(l => { const o = by[l.code] = by[l.code] || { code: l.code, issued: 0, waiting: 0, slips: [] }; if (l.status === 'issued') { o.issued += l.qty; l.issued.forEach(x => o.slips.push(x.slip + (x.serial ? ' #' + x.serial : ''))); } else o.waiting += l.qty; });
  return Object.values(by);
}
function shCorr() {
  const f = ui.form;
  let h = '<div class="row"><h2>Correction · ' + esc(f.req) + '</h2><button class="btn sm ghost" data-a="closeSheet">Close</button></div>';
  h += '<div class="note">Type the <b>final</b> quantity from the paper. The app keeps what was already issued and makes the rest pending under the same Request No (it gets a new Slip and Serial when you fill it).</div>';
  h += '<div class="card" style="overflow:hidden">' + f.rows.map((o, i) => { const F = parseFloat(o.final); const rem = isNaN(F) ? null : Math.round((F - o.issued) * 1000) / 1000;
    return '<div class="line"><div class="row"><b>' + esc(itemName(o.code)) + '</b><span class="mono note">' + esc(o.code) + '</span></div>' +
      '<div class="row" style="align-items:center">' + meta(['issued ' + num(o.issued), 'pending ' + num(o.waiting), o.slips.length ? esc(o.slips.join(', ')) : '']) + '<input type="number" inputmode="decimal" data-corr="' + i + '" value="' + esc(o.final) + '" style="width:110px;text-align:right"></div>' +
      (rem === null || (rem === o.waiting) ? '' : rem > 0 ? '<div class="scrow"><span class="sc gd">' + num(rem) + ' ' + esc(itemUom(o.code)) + ' will be pending</span></div>' : rem === 0 ? '<div class="scrow"><span class="sc ok">Fully issued, nothing pending</span></div>' : '<div class="scrow"><span class="sc no">Issued ' + num(-rem) + ' more than final. Make a Return entry.</span></div>') + '</div>'; }).join('') + '</div>';
  h += '<div class="card pad col" style="gap:8px"><b>Add an article to this request</b><div class="grid2"><input type="text" data-cadd="code" value="' + esc(f.addCode || '') + '" placeholder="Item code e.g. GR-198" class="mono" autocapitalize="characters"><input type="number" inputmode="decimal" data-cadd="qty" value="' + esc(f.addQty || '') + '" placeholder="Qty"></div><button class="btn" data-a="corrAdd">+ Add article</button></div>';
  h += '<button class="btn main full" data-a="corrSave">Save correction</button>';
  return h;
}
function shPaperDay() {
  const d = ui.sheet.day, RQ = sortBy(requests().filter(r => r.date === d), 'req_asc', r => ({ req: r.req, store: r.store, date: r.date }));
  const withP = RQ.filter(r => paperList(r.req).length), photos = RQ.reduce((n, r) => n + paperList(r.req).length, 0), can = paperOpen(d);
  let h = '<div class="row"><h2>Paper photos</h2><button class="btn sm ghost" data-a="closeSheet">Close</button></div>';
  h += '<div class="grid3"><div class="tile t-in"><b>' + RQ.length + '</b><span>Requests</span></div><div class="tile t-ok"><b>' + withP.length + '</b><span>With photo</span></div><div class="tile t-pt"><b>' + photos + '</b><span>Photos</span></div></div>';
  h += '<div class="note">' + fmtLong(d) + ' · ' + (can ? 'photos can be added until ' + fmtShort(paperDeadline(d)) : 'closed for new photos') + '</div>';
  h += '<div class="card" style="overflow:hidden">' + RQ.map(r => { const n = paperList(r.req).length, cl = paperList(r.req).filter(p => p.cloud).length;
    return '<div class="line" style="flex-direction:row;align-items:center;gap:10px"><span style="flex:1;min-width:0"><span class="reqno sm" data-req="' + esc(r.req) + '">' + esc(r.req) + '</span> <b>' + esc(r.store) + '</b><div class="meta"><span>' + (n ? n + ' photo' + (n > 1 ? 's' : '') + (cl === n ? ' · backed up' : cl ? ' · ' + cl + ' backed up' : '') : '<em>no photo</em>') + '</span></div></span>' +
      (n ? pill('Done', 'c-ok') : '') + (can ? '<button class="btn sm ' + (n ? 'ghost' : 'main') + '" data-a="paperAddFrom" data-v="' + esc(r.req) + '">' + (n ? '+ More' : '+ Photo') + '</button>' : '') + '<button class="btn sm ghost" data-a="paperOpenReq" data-v="' + esc(r.req) + '">Open</button></div>'; }).join('') + '</div>';
  return h;
}
function shRetBatch() {
  const f = ui.form, stores = allStores();
  let h = '<div class="row"><h2>Batch add returns</h2><button class="btn sm ghost" data-a="closeSheet">Close</button></div>';
  h += '<label class="f">Returns came on (in every remark)<input type="date" data-rbf="recvDate" value="' + esc(f.recvDate) + '"></label>';
  f.groups.forEach((g, gi) => {
    const pn = (() => { const used = []; for (let k = 0; k <= gi; k++) used.push(nextReturnNo(f.recvDate, used)); return used[gi]; })();
    h += '<div class="card pad col" style="gap:10px;box-shadow:inset 4px 0 0 #5B9BFF"><div class="row"><b>Return ' + (gi + 1) + ' · <span class="mono" style="color:#2F6FE0">' + esc(pn) + '</span></b><button class="xbtn" data-a="rbDelG" data-v="' + gi + '" aria-label="Remove">' + ico('x', 16) + '</button></div>' +
      '<label class="f">Store (returned from)<input type="text" data-rb="' + gi + '|store" value="' + esc(g.store) + '" list="rbStores" autocapitalize="characters" placeholder="e.g. LC MESS"></label>' +
      '<label class="f">By employee (GA or E code)<input type="text" data-rb="' + gi + '|by" value="' + esc(g.by) + '" class="mono" inputmode="numeric" maxlength="6"></label>' +
      g.rows.map((r, ri) => '<div class="rbrow"><input type="text" data-rbr="' + gi + '|' + ri + '|code" value="' + esc(r.code) + '" class="mono" placeholder="Item code" autocapitalize="characters"><input type="number" inputmode="decimal" data-rbr="' + gi + '|' + ri + '|qty" value="' + esc(r.qty) + '" placeholder="Qty"><button class="xbtn" data-a="rbDelR" data-v="' + gi + '|' + ri + '" aria-label="Remove item">' + ico('x', 14) + '</button><span class="rbname">' + (r.code && S.stock[String(r.code).toUpperCase()] ? esc(itemName(String(r.code).toUpperCase())) + ' · ' + esc(itemUom(String(r.code).toUpperCase())) : r.code ? 'code not in stock list' : '') + '</span></div>').join('') +
      '<button class="btn sm ghost" data-a="rbAddR" data-v="' + gi + '">+ Item</button>' +
      (g.store ? '<div class="note mono">' + esc(retRemark({ store: g.store, recvDate: f.recvDate })) + '</div>' : '') + '</div>';
  });
  h += '<datalist id="rbStores">' + stores.map(x => '<option value="' + esc(x) + '">').join('') + '</datalist>';
  h += '<button class="btn full" data-a="rbAddG">+ Another return</button>';
  h += '<div class="card pad col" style="gap:8px"><b>Or paste from Excel</b><div class="note">One row per item: Store, Employee code, Item code, Qty</div><textarea data-rbf="paste" rows="4" placeholder="LC MESS\t600043\tGR-198\t5">' + esc(f.paste || '') + '</textarea><button class="btn sm" data-a="rbPaste">Add pasted rows</button></div>';
  h += '<button class="btn main full" data-a="rbSave">Save all returns</button>';
  return h;
}
function shCrop() {
  const c = ui.sheet, V = 280, base = Math.max(V / c.img.width, V / c.img.height) * c.zoom;
  const dw = c.img.width * base, dh = c.img.height * base;
  return '<div class="row"><h2>Crop photo</h2><button class="btn sm ghost" data-a="closeSheet">Close</button></div>' +
    '<div class="note">Drag to move. Use the slider to zoom.</div>' +
    '<div id="cropBox" style="position:relative;width:280px;height:280px;margin:0 auto;overflow:hidden;border-radius:20px;background:#0F172A;touch-action:none">' +
    '<img src="' + c.src + '" draggable="false" style="position:absolute;left:' + ((V - dw) / 2 + c.x) + 'px;top:' + ((V - dh) / 2 + c.y) + 'px;width:' + dw + 'px;height:' + dh + 'px;max-width:none;user-select:none;pointer-events:none">' +
    '<div style="position:absolute;inset:0;border-radius:50%;box-shadow:0 0 0 400px rgba(15,23,42,.55);border:2px solid #C9A24B;pointer-events:none"></div></div>' +
    '<label class="f">Zoom<input type="range" min="1" max="4" step="0.01" value="' + c.zoom + '" data-crop="zoom" style="min-height:40px"></label>' +
    '<button class="btn main full" data-a="cropSave">Save photo</button>';
}
let cropDrag = null;
document.addEventListener('pointerdown', e => { const b = e.target.closest && e.target.closest('#cropBox'); if (!b || !ui.sheet || ui.sheet.kind !== 'crop') return; cropDrag = { x: e.clientX, y: e.clientY, ox: ui.sheet.x, oy: ui.sheet.y }; b.setPointerCapture && b.setPointerCapture(e.pointerId); });
document.addEventListener('pointermove', e => { if (!cropDrag) return; ui.sheet.x = cropDrag.ox + e.clientX - cropDrag.x; ui.sheet.y = cropDrag.oy + e.clientY - cropDrag.y; const im = document.querySelector('#cropBox img'); if (im) { const V = 280, c = ui.sheet, base = Math.max(V / c.img.width, V / c.img.height) * c.zoom; im.style.left = ((V - c.img.width * base) / 2 + c.x) + 'px'; im.style.top = ((V - c.img.height * base) / 2 + c.y) + 'px'; } });
document.addEventListener('pointerup', () => { cropDrag = null; });
function shBackups() {
  const s = ui.sheet;
  let h = '<div class="row"><h2>Cloud backups</h2><button class="btn sm ghost" data-a="closeSheet">Close</button></div>';
  h += '<div class="note">Every change is backed up automatically (a new copy every 30 minutes, newest 60 kept). Tap Keep on any copy to protect it forever.</div>';
  h += '<div class="card pad col"><b>Save a backup now</b><input type="text" data-bk="note" value="' + esc(s.note || '') + '" placeholder="Note, e.g. Before month-end cleanup"><button class="btn main" data-a="bkSave">Save backup (kept)</button></div>';
  if (s.loading) return h + skel(4);
  if (s.err) return h + '<div class="err">' + esc(s.err) + '</div>';
  const items = s.items || [];
  h += '<div class="row"><span class="sect">' + items.length + ' backups</span>' + (s.folder ? '<button class="btn sm ghost" data-a="openUrl" data-v="' + esc(s.folder) + '">Open Drive folder</button>' : '') + '</div>';
  items.forEach(b => {
    const c = b.counts || {};
    h += '<div class="card pad col" style="gap:8px"><div class="row"><b>' + fmtDT(b.updated) + '</b>' + pill(b.keep ? 'Kept' : b.kind === 'manual' ? 'Manual' : 'Auto', b.keep ? 'c-ok' : 'c-gy') + '</div>' +
      meta([c.requests != null ? c.requests + ' requests' : '', c.entries != null ? c.entries + ' entries' : '', c.returns != null ? c.returns + ' returns' : '', Math.round(b.size / 1024) + ' KB', b.by ? esc(b.by) : '']) +
      (s.editing === b.id ? '<input type="text" data-bk="rename" value="' + esc(s.rename || '') + '" placeholder="Note"><div class="grid2"><button class="btn sm" data-a="bkNoteSave" data-v="' + b.id + '">Save note</button><button class="btn sm ghost" data-a="bkNoteCancel">Cancel</button></div>' : (b.note ? '<div class="note">' + esc(b.note) + '</div>' : '')) +
      '<div class="grid3"><button class="btn sm main" data-a="bkRestore" data-v="' + b.id + '">Restore</button><button class="btn sm" data-a="bkKeep" data-v="' + b.id + '" data-k="' + (b.keep ? '0' : '1') + '">' + (b.keep ? 'Unkeep' : 'Keep') + '</button><button class="btn sm warn" data-a="bkDel" data-v="' + b.id + '">Delete</button></div>' +
      (s.editing === b.id ? '' : '<button class="btn sm ghost" data-a="bkNote" data-v="' + b.id + '">Add / edit note</button>') + '</div>';
  });
  return h;
}
async function restoreNow() {
  if (!await uiConfirm('Replace all data on this phone with the last Google Sheet backup?')) return;
  try {
    const r = await fetch(S.sync.url + (S.sync.url.includes('?') ? '&' : '?') + 'action=restore');
    const j = await r.json();
    if (!j.ok || !j.backup) throw new Error(j.error || 'no backup found');
    const url = S.sync.url;
    S = Object.assign(blank(), JSON.parse(j.backup)); S.sync.url = url; save(true); render(); toast('Restored from Google Sheet.');
  } catch (e) { toast('Restore failed: ' + e.message); }
}

/* ---------------- updates ---------------- */
async function checkUpdate(manual) {
  if (!INFO.repo) { if (manual) toast('Updates work inside the installed app.'); return; }
  try {
    const r = await fetch('https://api.github.com/repos/' + INFO.repo + '/releases/latest', { headers: { Accept: 'application/vnd.github+json' } });
    if (!r.ok) throw new Error('GitHub ' + r.status);
    const j = await r.json();
    const m = String(j.tag_name || '').match(/(\d+)$/);
    const apk = (j.assets || []).find(a => /\.apk$/i.test(a.name));
    const newer = !!(m && apk && +m[1] > +(INFO.code || 0));
    S.updateInfo = { tag: j.tag_name, url: apk ? apk.browser_download_url : '', newer, at: new Date().toISOString() };
    S.lastUpdateCheck = Date.now(); save(true);
    if (manual) toast(newer ? 'Update ' + j.tag_name + ' available.' : 'You have the latest version.');
    render();
  } catch (e) { if (manual) toast('Could not check: ' + e.message); }
}

/* ---------------- events from CUIMS ---------------- */
window.onSiteEvent = function (raw) {
  let e; try { e = JSON.parse(raw); } catch (x) { return; }
  if (e.type === 'setPref' && ['queue', 'autoSubmit', 'funMode'].includes(e.key)) { S[e.key] = !!e.val; save(true); render(); return; }
  if (e.type === 'areas' && Array.isArray(e.areas) && e.areas.length) {
    if (e.areas.join('|') !== S.areas.join('|')) { S.areas = e.areas; save(true); }
  } else if (e.type === 'login') { S.lastLoginAt = e.at; save(true); }
  else if (e.type === 'loggedout') { toast('CUIMS logged out. Log in again; the entry restarts by itself.'); }
  else if (e.type === 'progress' && e.code && isFinite(e.stock)) {
    if (S.stock[e.code] && Math.abs(S.stock[e.code].qty - e.stock) > 1e-6) { S.stock[e.code].qty = e.stock; save(true); }
  } else if (e.type === 'submitted') { recordSubmit(e); }
  else if (e.type === 'names') { S.cuimsNames = Object.assign(S.cuimsNames || {}, e.names || {}); const n = Object.keys(e.names || {}).length, miss = (e.missing || []).length; save(); render(); renderSheet(); toast(n + ' name' + (n === 1 ? '' : 's') + ' saved from CUIMS' + (miss ? ' · ' + miss + ' code' + (miss > 1 ? 's' : '') + ' not in the CUIMS list: ' + e.missing.map(rcvLabel).join(', ') : '') + '.'); }
  else if (e.type === 'verified') { if (e.scope && /^link/.test(e.scope.type)) { buildLinkProposal(e); toast('CUIMS serials read. Check and save.'); } else { buildVerifyReport(e); toast('Verification finished.'); } }
  else if (e.type === 'cancelled') { let jk = ''; try { jk = (JSON.parse(N.jobGet() || '{}') || {}).kind || ''; } catch (x) {} toast(jk === 'verify' ? 'Verification stopped. Nothing on CUIMS was changed.' : 'Entry cancelled. Nothing was submitted.'); if (N) N.showApp(); }
};
function recordSubmit(e) {
  let job = null; try { job = JSON.parse(N.jobGet() || 'null'); } catch (x) {}
  if (!job || job.slip !== e.slip) return;
  if (job.kind === 'return') {
    const r = S.returns.find(x => String(x.id) === String(job.retId)); if (!r) return;
    r.serial = e.serial || r.serial || ''; r.cuimsAt = new Date().toISOString(); if (e.rname) { r.byName = r.byName || e.rname; S.rnames = S.rnames || {}; S.rnames[r.by] = e.rname; }
    save(); toast('Return ' + r.no + ' saved on CUIMS, Serial ' + (r.serial || '–') + '.'); render();
    if (S.queue && job.queue) { const nx = retQueue(r.id)[0]; if (nx) setTimeout(() => { toast('Queue: return ' + nx.no + ', ' + nx.store + '.'); startReturnJob(nx); }, 1500); }
    return;
  }
  if (S.entries.some(x => String(x.slip).toUpperCase() === String(job.slip).toUpperCase())) return;
  const items = job.items.filter(i => !i.skip);
  const at = new Date().toISOString();
  const entry = { id: nid(), slip: job.slip, serial: e.serial || '', store: job.store, rcv: job.rcv, rname: e.rname || rname(job.rcv), at, date: today(), time: timeNow(),
    by: meTag(), kind: 'auto', remarks: e.note || '', items: items.map(i => ({ lineId: i.lineId, req: i.req, code: i.code, name: i.name, uom: i.uom, qty: i.qty, remark: i.remark })) };
  S.entries.push(entry);
  items.forEach(i => {
    const l = S.lines.find(x => x.id === i.lineId);
    if (l) { l.status = 'issued'; l.issued.push({ slip: job.slip, serial: e.serial || '', at }); delete S.hold[l.id]; }
    if (S.stock[i.code]) S.stock[i.code].qty = Math.round((S.stock[i.code].qty - i.qty) * 1000) / 1000;
  });
  if (e.rname) { S.rnames = S.rnames || {}; S.rnames[job.rcv] = e.rname; if (S.stores[job.store] && !S.stores[job.store].rname) S.stores[job.store].rname = e.rname; }
  save();
  toast('Saved ' + job.slip + ', Serial ' + (e.serial || '–') + '.');
  render();
  if (S.queue && !job.adv) {
    const nx = nextQueueJob(); const slip = nx ? (plannedSlip(nx.ids) || nextSlip()) : '';
    if (nx && slip) { setTimeout(() => { toast('Queue: ' + nx.store + ', request ' + nx.req + ', Slip ' + slip); startJob(nx.store, slip, nx.rcv, nx.ids); }, 2500); return; }
    toast('Queue finished: nothing else can be issued today.');
  }
  if (S.funMode || job.fun) return; // Kitty mode: stay on Kitty until Close the door
  setTimeout(() => { if (N) N.showApp(); }, 2500);
}
window.jvOnReturnFromSite = () => render();
window.jvBack = () => {
  if (ui.picker) { ui.picker = null; renderPicker(); return true; }
  if (ui.drawer) { ui.drawer = false; renderDrawer(); return true; }
  if (ui.sheet) { ui.sheet = null; renderSheet(); return true; }
  if (ui.view) { ui.view = null; render(); return true; }
  if (ui.tab === 'set' && ui.setPage) { ui.setPage = null; render(); return true; }
  if (ui.tab !== 'home') { ui.tab = 'home'; render(); return true; }
  return false;
};

/* ---------------- render ---------------- */
function render() {
  const app = document.getElementById('app');
  const y = window.scrollY;
  app.innerHTML = appBar() + (S.testMode ? '<div class="testbar"><span><b>TEST MODE</b> · your real data is safe and hidden. Cloud backup is paused. Entries submitted on CUIMS are still real.</span><button class="btn sm" data-a="testToggle">Exit</button></div>' : '') + (ui.view === 'linkReview' ? vLinkReview() : ui.view === 'vreport' ? vReport() : ui.view === 'vreports' ? vReportList() : ui.view === 'countList' ? vCountList() : ui.view === 'manage' ? vManage() : ui.view === 'stock' ? vStock() : ui.view === 'cons' ? vCons() : ui.view === 'arts' ? vArts() : ui.view === 'check' ? vCheck() : ui.view === 'done' ? vDone() : ui.view === 'expiry' ? vExpiry() : ui.view === 'zwatch' ? vZeroWatch() : ui.view === 'countStart' ? vCountStart() : ui.view === 'emp' ? vEmp() : ui.view === 'empStaff' ? vEmpStaff() : ui.view === 'empIgnore' ? vEmpIgnore() : ui.view === 'empSess' ? vEmpSess() : ui.view === 'empLog' ? vEmpLog() : ui.view === 'count' ? vCount() : ui.view === 'countLog' ? vCountLog() : ui.view === 'taskLog' ? vTaskLog() : ui.view === 'req' ? vReq() : ({ home: vHome, pend: vPend, reg: vReg, find: vFind, set: vSet })[ui.tab]());
  document.querySelector('#tabs .in').innerHTML = TABS.map(([k, l]) => '<button data-a="tab" data-v="' + k + '" class="' + (ui.tab === k && !ui.view ? 'on' : '') + '" aria-label="' + l + '"><span class="nic">' + ICON[k] + '</span><span class="nl">' + l + '</span></button>').join('');
  renderDrawer();
  paintSync();
  enhanceDates(document.getElementById('app'));
  enhanceRcv(document.getElementById('app'));
  if (ui.lastReq) flashReq(ui.lastReq);
  window.scrollTo(0, y);
}
function renderSheet() {
  const el = document.getElementById('sheet');
  if (!ui.sheet) { el.innerHTML = ''; return; }
  const k = ui.sheet.kind;
  const body = k === 'empZoom' ? '<div class="row"><h2>Signed sheet</h2><button class="btn sm ghost" data-a="closeSheet">Close</button></div><img src="' + esc(ui.sheet.src) + '" style="width:100%;border-radius:14px">' : k === 'zwAdd' ? shZwAdd() : k === 'link' ? shLink() : k === 'retBatch' ? shRetBatch() : k === 'paperDay' ? shPaperDay() : k === 'manReq' ? shManReq() : k === 'mslips' ? shMslips() : k === 'reqStatus' ? shReqStatus() : k === 'corr' ? shCorr() : k === 'batch' ? shBatch() : k === 'newReq' ? shNewReq() : k === 'export' ? shExport() : k === 'crop' ? shCrop() : k === 'backups' ? shBackups() : k === 'start' ? shStart() : k === 'upload' ? shUpload() : k === 'entry' ? shEntry() : k === 'return' ? shReturn() : k === 'editReq' ? shEditReq() : k === 'bulk' ? shBulk() : k === 'mark' ? shMark() : '';
  const sc = el.querySelector('.sheet') ? el.querySelector('.sheet').scrollTop : 0;
  el.innerHTML = '<div class="sheetbg" data-a="bgClose"><div class="sheet" role="dialog" aria-modal="true">' + body + '</div></div>';
  el.querySelector('.sheet').scrollTop = sc;
  enhanceDates(document.getElementById('sheet'));
  enhanceRcv(document.getElementById('sheet'));
}
const SORT_OPTS = [['reqdate', 'Day, then Request No'], ['req_asc', 'Request No, low to high'], ['req_desc', 'Request No, high to low'], ['name_asc', 'Store name A to Z'], ['name_desc', 'Store name Z to A'],
  ['date_asc', 'Date, oldest first'], ['date_desc', 'Date, newest first'], ['custom', 'My store order'], ['stock', 'Stock priority (most ready first)'], ['size', 'Most articles first']];
function getSort(k) { S.uiPrefs = S.uiPrefs || {}; S.uiPrefs.sort = S.uiPrefs.sort || {}; return S.uiPrefs.sort[k] || 'reqdate'; }
function setSort(k, v) { getSort(k); S.uiPrefs.sort[k] = v; writeLocal(); }
function cmpSort(how, a, b) {
  const rq = (x, y) => String(x.req || '').localeCompare(String(y.req || ''), undefined, { numeric: true });
  const da = String(a.date || ''), db = String(b.date || '');
  switch (how) {
    case 'req_asc': return rq(a, b); case 'req_desc': return rq(b, a);
    case 'name_asc': return String(a.store).localeCompare(String(b.store)) || rq(a, b); case 'name_desc': return String(b.store).localeCompare(String(a.store)) || rq(a, b);
    case 'date_asc': return da.localeCompare(db) || rq(a, b); case 'date_desc': return db.localeCompare(da) || rq(a, b);
    case 'custom': return byStore(a.store, b.store) || rq(a, b); case 'stock': return (b.ready || 0) - (a.ready || 0) || rq(a, b); case 'size': return (b.size || 0) - (a.size || 0) || rq(a, b);
    default: return db.localeCompare(da) || rq(a, b);
  }
}
function sortBy(list, how, acc) { return list.sort((x, y) => cmpSort(how, acc(x), acc(y))); }
const PICKS = {};
function pickBtn(id, cfg, label) { PICKS[id] = cfg; const cur = (cfg.opts.find(o => o[0] === cfg.val) || [])[1]; return '<button type="button" class="pickbtn' + (cfg.full ? ' full' : '') + '" data-a="pick" data-v="' + id + '"><span>' + esc(label ? label + (cur ? ': ' + cur : '') : cur || cfg.placeholder || 'Choose') + '</span>' + ico('down', 16) + '</button>'; }
function sortPick(k) { return pickBtn('sort_' + k, { title: 'Sort by', opts: SORT_OPTS, val: getSort(k), set: v => { setSort(k, v); render(); } }, 'Sort'); }
const BUSY = { uploadOk: 'Importing and re-planning', syncNow: 'Backing up to the cloud', restore: 'Restoring your data', bkRestore: 'Restoring the backup', bkSave: 'Saving a backup', dcOpen: 'Checking your data', consOpen: 'Adding up consumption',
  stockOpen: 'Opening live stock', artsOpen: 'Loading pending articles', doneOpen: 'Preparing the done list', openMgr: 'Opening Manager CUIMS', dMgr: 'Opening Manager CUIMS', openSite: 'Opening Issue CUIMS', dSite: 'Opening Issue CUIMS', startFill: 'Opening Issue CUIMS',
  testToggle: 'Switching data', btSave: 'Saving requests', bulkSave: 'Saving all requests', mrSave: 'Saving request', msSave: 'Saving slip', corrSave: 'Saving correction', dCount: 'Picking today\'s articles', template: 'Making the template', expAll: 'Preparing the full backup' };
function loader(on, msg) {
  let el = document.getElementById('loader'); if (!el) { el = document.createElement('div'); el.id = 'loader'; document.body.appendChild(el); }
  if (!on) { el.className = ''; el.innerHTML = ''; return; }
  el.className = 'show';
  el.innerHTML = '<div class="ldbox"><div class="ldorb"><span class="o1"></span><span class="o2"></span><span class="o3"></span><i class="sp s1"></i><i class="sp s2"></i><i class="sp s3"></i><img src="icon.png" alt=""></div><b>' + esc(msg || 'Working') + '</b><div class="lddots"><i></i><i></i><i></i></div><div class="ldbar"><i></i></div><small>JV Stock Issue</small></div>';
}
const skel = n => Array.from({ length: n || 3 }, () => '<div class="card pad skel"><i style="width:34%"></i><i style="width:72%"></i><i style="width:55%"></i></div>').join('');
function uiPrompt(msg, value, okLabel) {
  loader(false);
  return new Promise(res => {
    let el = document.getElementById('dlg'); if (!el) { el = document.createElement('div'); el.id = 'dlg'; document.body.appendChild(el); }
    el.innerHTML = '<div class="pkbg"></div><div class="dlgbox" role="dialog" aria-modal="true"><div class="dlgmsg">' + esc(msg) + '</div><input type="text" id="dlgin" value="' + esc(value || '') + '" class="mono" autocapitalize="characters"><div class="grid2"><button class="btn" data-dlg="0">Cancel</button><button class="btn main" data-dlg="1">' + esc(okLabel || 'OK') + '</button></div></div>';
    const inp = el.querySelector('#dlgin'); setTimeout(() => { inp.focus(); inp.select(); }, 50);
    el.querySelectorAll('[data-dlg]').forEach(b => b.onclick = e => { e.stopPropagation(); const v = inp.value.trim(); el.innerHTML = ''; res(b.dataset.dlg === '1' ? v : null); });
  });
}
const TEST_KEYS = ['lines', 'entries', 'returns', 'stock', 'stockAt', 'counts', 'taskLog', 'corrections', 'hold'];
const deep = o => JSON.parse(JSON.stringify(o == null ? null : o));
function setTestMode(on) {
  if (on === !!S.testMode) return;
  if (on) {
    S._real = {}; TEST_KEYS.forEach(k => S._real[k] = S[k]);
    const t = S._test || {};
    S.lines = t.lines || []; S.entries = t.entries || []; S.returns = t.returns || []; S.counts = t.counts || []; S.taskLog = t.taskLog || {}; S.corrections = t.corrections || []; S.hold = t.hold || {};
    S.stock = t.stock || deep(S._real.stock) || {}; S.stockAt = t.stockAt || S._real.stockAt;
    S.testMode = true;
  } else {
    S._test = {}; TEST_KEYS.forEach(k => S._test[k] = S[k]);
    TEST_KEYS.forEach(k => S[k] = S._real[k]); delete S._real; S.testMode = false;
  }
  ui.view = null; ui.lastReq = null; save(); render();
}
function renumberReqStore(from, store, to) {
  to = String(to || '').trim(); if (!to) return false;
  if (S.lines.some(l => l.req === to)) { toast('Request No ' + to + ' already exists.'); return false; }
  const ids = new Set(S.lines.filter(l => l.req === from && l.store === store).map(l => l.id));
  S.lines.forEach(l => { if (ids.has(l.id)) l.req = to; });
  S.entries.forEach(e => e.items.forEach(i => { if (ids.has(i.lineId)) i.req = to; }));
  return true;
}
function dataIssues() {
  const out = [], by = {};
  S.lines.filter(l => l.status !== 'dropped').forEach(l => (by[l.req] = by[l.req] || []).push(l));
  Object.entries(by).forEach(([req, L]) => {
    const stores = [...new Set(L.map(l => l.store))];
    if (stores.length > 1) out.push({ kind: 'multi', req, stores: stores.map(st => ({ st, n: L.filter(l => l.store === st).length, issued: L.some(l => l.store === st && l.status === 'issued') })) });
    const seen = {}; L.filter(l => l.status === 'waiting').forEach(l => { const k = l.store + '|' + l.code; (seen[k] = seen[k] || []).push(l); });
    Object.values(seen).filter(x => x.length > 1).forEach(x => out.push({ kind: 'dupline', req, store: x[0].store, code: x[0].code, lines: x.map(l => l.id), qtys: x.map(l => l.qty) }));
    const ds = [...new Set(L.map(l => l.date))]; if (ds.length > 1) out.push({ kind: 'dates', req, dates: ds.sort() });
  });
  const bad = S.lines.filter(l => l.status !== 'dropped' && (!l.store || !l.code || !(l.qty > 0) || !l.req));
  if (bad.length) out.push({ kind: 'bad', ids: bad.map(l => l.id), n: bad.length });
  const slips = {}; S.entries.forEach(e => (slips[String(e.slip).toUpperCase()] = slips[String(e.slip).toUpperCase()] || []).push(e));
  Object.entries(slips).filter(([k, v]) => v.length > 1).forEach(([k, v]) => out.push({ kind: 'slip', slip: k, n: v.length, stores: v.map(e => e.store) }));
  const rn = {}; S.returns.forEach(r => (rn[String(r.no).toUpperCase()] = rn[String(r.no).toUpperCase()] || []).push(r));
  Object.entries(rn).filter(([k, v]) => v.length > 1).forEach(([k, v]) => out.push({ kind: 'retdup', no: k, ids: v.map(r => r.id), stores: v.map(r => r.store) }));
  const oldF = S.returns.filter(r => !RET_RE.test(String(r.no))); if (oldF.length) out.push({ kind: 'retfmt', n: oldF.length, nos: oldF.map(r => r.no) });
  const miss = S.lines.filter(l => l.status === 'waiting' && Object.keys(S.stock).length && !S.stock[l.code]);
  if (miss.length) out.push({ kind: 'nostock', n: miss.length, codes: [...new Set(miss.map(l => l.code))] });
  return out;
}
function audit(action, l, extra) { S.audit = S.audit || []; S.audit.push(Object.assign({ at: new Date().toISOString(), by: S.me.name || '', action, req: l.req, store: l.store, code: l.code, qty: l.qty }, extra || {})); if (S.audit.length > 3000) S.audit = S.audit.slice(-3000); }
function artsList() {
  const A = ui.arts, PL = plan(), q = String(A.q || '').trim().toUpperCase();
  let L = S.lines.filter(l => l.status === 'waiting').map(l => ({ l, k: S.hold[l.id] ? 'hold' : PL[l.id] }));
  const dday = artsDay(); if (dday) L = L.filter(x => x.l.date === dday);
  if (A.store) L = L.filter(x => x.l.store === A.store);
  if (A.st !== 'all') L = L.filter(x => A.st === 'ready' ? x.k === 'issue' : A.st === 'wait' ? (x.k === 'short' || x.k === 'missing') : x.k === A.st);
  if (q) L = L.filter(x => (x.l.code + ' ' + itemName(x.l.code) + ' ' + x.l.store + ' ' + x.l.req).toUpperCase().includes(q));
  return sortBy(L, getSort('arts'), x => ({ req: x.l.req, store: x.l.store, date: x.l.date, ready: x.k === 'issue' ? 1 : 0, size: x.l.qty }));
}
function artsDay() { const A = ui.arts || {}; const d = new Date(); d.setHours(12); const off = k => { const x = new Date(d); x.setDate(d.getDate() + k); return isoOf(x); };
  return A.day === 'yday' ? off(-1) : A.day === 'today' ? today() : A.day === 'tmrw' ? off(1) : A.day === 'pick' ? (A.dayPick || today()) : ''; }
function artsResults() {
  const A = ui.arts, L = artsList();
  const G = {}; L.forEach(x => (G[x.l.code] = G[x.l.code] || []).push(x));
  const groups = Object.entries(G).map(([code, xs]) => ({ code, xs, qty: xs.reduce((n, x) => n + x.l.qty, 0), stores: new Set(xs.map(x => x.l.store)).size, ready: xs.filter(x => x.k === 'issue').length }))
    .sort((a, b) => b.xs.length - a.xs.length || String(itemName(a.code)).localeCompare(String(itemName(b.code))));
  const allSel = L.length && L.every(x => A.sel[x.l.id]);
  let h = '<div class="row" style="align-items:center"><label class="chk" style="min-height:40px"><input type="checkbox" data-a="artsAll"' + (allSel ? ' checked' : '') + '> Select all</label><span class="note">' + groups.length + ' items · ' + L.length + ' articles</span></div>';
  if (!L.length) return h + '<div class="card pad note">No pending articles match.</div>';
  const rowOf = g => {
    const open = !!(A.open || {})[g.code], gsel = g.xs.every(x => A.sel[x.l.id]), some = g.xs.some(x => A.sel[x.l.id]);
    const st = S.stock[g.code], short = st && st.qty < g.qty;
    let r = '<div class="agrp' + (open ? ' on' : '') + '"><div class="agh"><input type="checkbox" data-a="artsGrp" data-v="' + esc(g.code) + '"' + (gsel ? ' checked' : '') + (some && !gsel ? ' class="part"' : '') + ' aria-label="Select all ' + esc(itemName(g.code)) + '">' +
      '<button class="agm" data-a="artsGrpOpen" data-v="' + esc(g.code) + '"><span class="agn"><b>' + esc(itemName(g.code)) + '</b><span class="mono">' + esc(g.code) + ' · ' + g.xs.length + ' request' + (g.xs.length > 1 ? 's' : '') + ' · ' + g.stores + ' store' + (g.stores > 1 ? 's' : '') + '</span></span>' +
      '<span class="agq"><b>' + num(Math.round(g.qty * 1000) / 1000) + '</b><small>' + esc(itemUom(g.code)) + '</small></span>' + ico(open ? 'up' : 'down', 18) + '</button></div>' +
      '<div class="scrow" style="padding:0 16px 12px 52px">' + (g.ready ? '<span class="sc ok">' + g.ready + ' ready</span>' : '') + (g.xs.length - g.ready ? '<span class="sc ' + (short ? 'no' : 'gd') + '">' + (g.xs.length - g.ready) + ' waiting</span>' : '') + (st ? '<span class="sc ' + (short ? 'no' : 'ok') + '">stock ' + num(st.qty) + '</span>' : '<span class="sc no">not in stock</span>') + '</div>';
    if (open && S.artsCat) r += '<div class="catmv"><span>Section</span>' + ARTS_CATS.map(([k, l, c]) => '<button data-a="artsCatMove" data-v="' + esc(g.code) + '|' + k + '" class="' + (itemCat(g.code) === k ? 'on' : '') + '" style="--c:' + c + '">' + l + '</button>').join('') + '</div>';
    if (open) r += g.xs.map(({ l, k }) => {
      const pst = k === 'later' ? pill('Scheduled', 'c-in') : k === 'issue' ? pill('Ready', 'c-ok') : k === 'short' ? pill('Short', 'c-no') : k === 'missing' ? pill('Not in stock', 'c-no') : pill('On hold', 'c-gd');
      return '<div class="art sub' + (A.sel[l.id] ? ' on' : '') + '"><input type="checkbox" data-a="artsSel" data-v="' + l.id + '"' + (A.sel[l.id] ? ' checked' : '') + ' aria-label="Select">' +
        '<div class="ab"><div class="row"><span><b class="an">' + esc(l.store) + '</b><div class="meta"><span class="reqno sm" data-req="' + esc(l.req) + '">' + esc(l.req) + '</span><i></i><span>' + fmtShort(l.date) + (days(l.date) > 0 ? ' · ' + days(l.date) + ' d' : '') + '</span></div></span>' + pst + '</div>' +
        '<div class="aa"><button class="aq" data-a="artQty" data-v="' + l.id + '" aria-label="Edit quantity">' + num(l.qty) + ' <small>' + esc(itemUom(l.code)) + '</small><svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"><path d="M4 20h4L19 9l-4-4L4 16z"/></svg></button>' +
        '<button class="btn sm ghost" data-a="artHold" data-v="' + l.id + '">' + (S.hold[l.id] ? 'Release' : 'Hold') + '</button><button class="btn sm ghost danger-t" data-a="artDel" data-v="' + l.id + '">Remove</button></div></div></div>';
    }).join('');
    return r + '</div>';
  };
  if (S.artsCat) {
    const C = {}; groups.forEach(g => (C[itemCat(g.code)] = C[itemCat(g.code)] || []).push(g));
    ARTS_CATS.forEach(([k, label, col]) => { const gs = C[k]; if (!gs || !gs.length) return;
      const op = !!(ui.artsCatOpen || {})[k], ids = gs.flatMap(g => g.xs.map(x => x.l.id)), allS = ids.every(id => A.sel[id]), someS = ids.some(id => A.sel[id]);
      const arts = gs.reduce((n, g) => n + g.xs.length, 0), ready = gs.reduce((n, g) => n + g.ready, 0);
      h += '<div class="card catcard" style="overflow:hidden;box-shadow:inset 5px 0 0 ' + col + '"><div class="cath"><input type="checkbox" data-a="artsCatSel" data-v="' + k + '"' + (allS ? ' checked' : '') + (someS && !allS ? ' class="part"' : '') + ' aria-label="Select all ' + esc(label) + '">' +
        '<button class="catm" data-a="artsCatTog" data-v="' + k + '"><span class="cdot2" style="background:' + col + '"></span><span class="catn"><b>' + esc(label) + '</b><span>' + gs.length + ' item' + (gs.length > 1 ? 's' : '') + ' · ' + arts + ' article' + (arts > 1 ? 's' : '') + (ready ? ' · ' + ready + ' ready' : '') + '</span></span>' + ico(op ? 'up' : 'down', 20) + '</button></div>' +
        (op ? gs.map(rowOf).join('') : '') + '</div>'; });
    return h;
  }
  h += '<div class="card" style="overflow:hidden">' + groups.slice(0, 200).map(rowOf).join('') + '</div>' + (groups.length > 200 ? '<div class="note">Showing 200 items. Narrow with search or filters.</div>' : '');
  return h;
}
const ARTS_CATS = [['dairy', 'Dairy & Bakery', '#5B9BFF'], ['frozen', 'Frozen - Veg & Non-Veg', '#26B5C9'], ['veg', 'Vegetables & Fruits', '#2BB673'], ['pulse', 'Pulses & Spices', '#FFB648'], ['misc', 'Miscellaneous / Other', '#9AA0A6']];
function itemCat(code) {
  const ok = k => ARTS_CATS.some(x => x[0] === k);
  const ov = (S.itemCat || {})[code]; if (ov && ok(ov)) return ov;
  S.itemCatAuto = S.itemCatAuto || {};
  const au = S.itemCatAuto[code]; if (au && ok(au)) return au;
  if (!code) return 'misc';
  const k = itemCatGuess(code); if (itemName(code) === 'Unknown item') return k;
  S.itemCatAuto[code] = k;
  clearTimeout(itemCat.t); itemCat.t = setTimeout(() => save(true), 800);
  return k;
}
function itemCatGuess(code) {
  const c = String(code || '').toUpperCase(), n = ' ' + String(itemName(code) || '').toUpperCase().replace(/[^A-Z]+/g, ' ') + ' ';
  const has = re => re.test(n);
  if (/^(HKG|EL|PL|ST|CR)-/.test(c) || has(/ (WASHING|DETERGENT|SURF|SOAP|PHENYL|HARPIC|VIM|BLEACH|CLEANER|BROOM|MOP|TISSUE|GLOVES|CAP|DUSTER|FOIL|WRAP|CYLINDER|LPG|GAS) /)) return 'misc';
  if (has(/ (FROZEN|NUGGET|NUGGETS|SAUSAGE|SAUSAGES|SALAMI|PEPPERONI|BACON|HAM|FRENCH FRIES|FRIES|SMILEY|SMILEYS|PATTY|PATTIES|SEEKH|TIKKA|CHICKEN|MUTTON|LAMB|FISH|PRAWN|PRAWNS|SHRIMP|MEAT|BASA|SURIMI|ICE CREAM) /) && !has(/ (NUTRI|SOYA|MASALA|POWDER|STOCK|CUBE) /)) return 'frozen';
  if (has(/ (BREAD|BUN|BUNS|PAV|PAO|RUSK|CAKE|COOKIE|COOKIES|BISCUIT|BISCUITS|PITA|KULCHA|MUFFIN|CROISSANT|PIZZA BASE|BURGER|TOAST|BAGUETTE|DONUT|BROWNIE|PASTRY) /) && !has(/ (CRUMB|CRUMBS) /)) return 'dairy';
  if (/^VEG-/.test(c) || has(/ (POTATO|ONION|TOMATO|CAULI|CABBAGE|CARROT|CAROT|BEANS|PEAS|CAPSICUM|PUMPKIN|BRINJAL|BHINDI|OKRA|LADY FINGER|GOURD|LAUKI|TINDA|TORI|KARELA|CUCUMBER|RADISH|MOOLI|SPINACH|PALAK|SAAG|METHI GREEN|BATHU|CORIANDER|DHANIA PATTA|MINT|PUDINA|GINGER|GARLIC|GREEN CHIL|LEMON|BEETROOT|SWEET POTATO|ARBI|TARO|KACHALU|DRUMSTICK|MUSHROOM|BROCCOLI|ZUCCHINI|LETTUCE|CELERY|PARSLEY|BASIL|CURRY PATTA|CORN|JACK FRUIT|KATHAL|SPRING ONION|POKCHOY|CHINESE CABBAGE|CHERRY TOMATO|ACHARI MIRCH|COCONUT|BANANA|APPLE|ORANGE|PAPAYA|GUAVA|GRAPES|WATERMELON|MELON|FRUIT|LOKEE|SARSO|BATHUA) /)) return 'veg';
  if (has(/ (MILK|PANEER|CURD|DAHI|BUTTER|CREAM|CHEESE|GHEE|KHOYA|KHOA|LASSI|CHHACH|BUTTERMILK|YOGURT|YOGHURT|EGG|EGGS|AMUL|MILKMAID|CONDENSED) /)) return 'dairy';
  if (has(/ (DAL|DHAL|RAJMA|RAJMAH|CHANA|CHOLE|MOONG|URAD|URD|MASOOR|ARHAR|TOOR|LOBIA|MOTH|ROONGI|MATAR|MUTTER|BESAN|SOYA CHUNK|SOYABEAN|MASALA|POWDER|MIRCH|HALDI|TURMERIC|JEERA|CUMIN|DHANIA|CORIANDER SEED|AJWAIN|AJWIN|HING|ASAFOETIDA|CLOVE|LAUNG|CARDAMOM|ELAICHI|CINNAMON|DALCHINI|BAY LEAF|TEJ PATTA|PEPPER|KALI MIRCH|JAVITRI|MACE|NUTMEG|JAIPHAL|STAR ANI|SAUNF|FENNEL|METHI DANA|KASOORI|KASURI|MUSTARD SEED|RAI|SARSON SEED|KALONJI|SABUT|WHOLE|CHILLI FLAKES|CHILLY FLAKES|OREGANO|ORGENO|MIX HERB|SEASONING|AMCHUR|SAFFRON|KESAR|KESHAR|TIL|SESAME|POPPY|KHUS|ANARDANA|KALA NAMAK|BLACK SALT) /)) return 'pulse';
  return 'misc';
}
function vArts() {
  ui.arts = ui.arts || { q: '', store: '', st: 'all', sel: {}, day: 'all' };
  if (!ui.arts.day) ui.arts.day = 'all';
  const A = ui.arts, stores = [...new Set(S.lines.filter(l => l.status === 'waiting').map(l => l.store))].sort(byStore);
  const selN = Object.keys(A.sel).length;
  let h = '<header class="top"><div><button class="btn sm ghost" data-a="back">‹ Back</button><h1 style="margin-top:10px">Pending articles</h1><div class="sub">One row per item with its total. Tap an item to see each store and request, then edit, hold or remove.</div></div></header><main>';
  h += '<div class="sbox"><svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"><circle cx="11" cy="11" r="7"/><path d="M20 20l-4-4"/></svg><input type="search" data-arts="q" value="' + esc(A.q) + '" placeholder="Item, code, store or Request No" autocomplete="off"></div>';
  const D0 = artsDay();
  h += '<div class="daychips">' + [['all', 'All days'], ['yday', 'Yesterday'], ['today', 'Today'], ['tmrw', 'Tomorrow'], ['pick', A.day === 'pick' ? fmtShort(A.dayPick || today()) : 'Pick a day']].map(([k, l]) => '<button data-a="artsDay" data-v="' + k + '" class="' + (A.day === k ? 'on' : '') + '">' + l + '</button>').join('') + '</div>';
  if (A.day === 'pick') h += '<label class="f">Request date<input type="date" data-artsday="1" value="' + esc(A.dayPick || today()) + '"></label>';
  if (D0) { const W = S.lines.filter(l => l.date === D0 && l.status !== 'dropped'); const w = W.filter(l => l.status === 'waiting'); h += '<div class="daysum"><b>' + fmtLong(D0) + '</b><span>' + w.length + ' pending of ' + W.length + ' articles · ' + new Set(w.map(l => l.store)).size + ' stores · ' + new Set(w.map(l => l.req)).size + ' requests</span></div>'; }
  h += '<div class="seg">' + [['all', 'All'], ['ready', 'Ready'], ['wait', 'Short'], ['hold', 'On hold']].map(([k, l]) => '<button data-a="artsSt" data-v="' + k + '" class="' + (A.st === k ? 'on' : '') + '">' + l + '</button>').join('') + '</div>';
  h += '<label class="chk catTog"><input type="checkbox" data-a="artsCatOn"' + (S.artsCat ? ' checked' : '') + '> Show in sections: ' + ARTS_CATS.map(x => x[1]).join(' · ') + '</label>';
  h += '<div class="grid2">' + pickBtn('artsStore', { title: 'Store', search: true, full: true, opts: [['', 'All stores']].concat(stores.map(x => [x, x])), val: A.store, set: v => { A.store = v; render(); } }) + sortPick('arts') + '</div>';
  h += '<div id="artsres">' + artsResults() + '</div>';
  h += '<button class="btn" data-a="artsExport">Download this list (PDF or Excel)</button>';
  h += '</main>';
  if (selN) h += '<div class="selbar"><b>' + selN + ' selected</b><button class="btn sm" data-a="artsBHold">Hold</button><button class="btn sm" data-a="artsBRel">Release</button><button class="btn sm danger" data-a="artsBDel">Remove</button><button class="xbtn" data-a="artsBClear" aria-label="Clear selection">' + ico('x', 16) + '</button></div>';
  return h;
}
function stockDemand() { const d = {}, t = today(); S.lines.forEach(l => { if (l.status === 'waiting' && !(l.date > t)) d[l.code] = (d[l.code] || 0) + l.qty; }); return d; }
function stockRows() {
  const K = ui.stk, q = String(K.q || '').trim().toUpperCase(), words = q.split(/\s+/).filter(Boolean), D = stockDemand();
  let L = Object.entries(S.stock).map(([c, v]) => ({ c, v, need: D[c] || 0 }));
  if (words.length) L = L.filter(x => words.every(w => x.c.includes(w) || String(x.v.name).toUpperCase().includes(w)));
  if (K.f === 'edited') L = L.filter(x => (S.stockEdits || {})[x.c]);
  else if (K.f === 'in') L = L.filter(x => x.v.qty > 0); else if (K.f === 'zero') L = L.filter(x => !(x.v.qty > 0)); else if (K.f === 'short') L = L.filter(x => x.need > x.v.qty); else if (K.f === 'need') L = L.filter(x => x.need > 0);
  L.sort((a, b) => (words.length ? (String(a.v.name).toUpperCase().startsWith(q) ? 0 : 1) - (String(b.v.name).toUpperCase().startsWith(q) ? 0 : 1) : 0) || (b.need - a.need) || String(a.v.name).localeCompare(String(b.v.name)));
  return L;
}
function stockResults() {
  const L = stockRows(), K = ui.stk;
  let h = '<div class="note" style="padding:0 4px">' + L.length.toLocaleString('en-IN') + ' items' + (L.length > 120 ? ' · showing 120, type to narrow' : '') + '</div>';
  if (!L.length) return h + '<div class="card pad note">No item matches.</div>';
  h += '<div class="card" style="overflow:hidden">' + L.slice(0, 120).map(x => {
    const free = Math.round((x.v.qty - x.need) * 1000) / 1000, open = K.open === x.c;
    let row = '<button class="stkrow" data-a="stkOpen" data-v="' + esc(x.c) + '"><span class="sn"><b>' + esc(x.v.name) + '</b><span class="mono">' + esc(x.c) + '</span></span><span class="sq"><b>' + num(x.v.qty) + '</b><small>' + esc(x.v.uom) + '</small></span></button>';
    const ed = (S.stockEdits || {})[x.c];
    row += '<div class="scrow" style="padding:0 18px 12px">' + (ed ? '<span class="sc gd">edited ' + esc(ago(ed.at)) + '</span>' : '') + (x.need ? '<span class="sc gd">needed ' + num(x.need) + '</span><span class="sc ' + (free < 0 ? 'no' : 'ok') + '">' + (free < 0 ? 'short ' + num(-free) : 'free ' + num(free)) + '</span>' : (x.v.qty > 0 ? '<span class="sc ok">in stock</span>' : '<span class="sc no">zero</span>')) + '</div>';
    if (open) {
      const W = S.lines.filter(l => l.code === x.c && l.status === 'waiting').sort((a, b) => a.date.localeCompare(b.date));
      const I = []; S.entries.slice().reverse().some(e => { e.items.forEach(i => { if (i.code === x.c && I.length < 6) I.push({ e, i }); }); return I.length >= 6; });
      row += '<div class="rqbtns" style="padding:0 18px 12px;grid-template-columns:1fr 1fr 1fr"><button class="btn sm main" data-a="stkEdit" data-v="' + esc(x.c) + '">Edit qty</button><button class="btn sm" data-a="stkRen" data-v="' + esc(x.c) + '">Name / UOM</button><button class="btn sm danger-t" data-a="stkDel" data-v="' + esc(x.c) + '">Delete</button></div>' +
        '<div style="padding:0 18px 10px"><button class="btn sm ' + (zwList().some(w => w.code === x.c) ? 'ghost' : '') + '" data-a="zwToggle" data-v="' + esc(x.c) + '" style="width:100%">' + (zwList().some(w => w.code === x.c) ? '✓ In Zero-stock watch · remove' : '+ Add to Zero-stock watch') + '</button></div>' +
        (ed ? '<div class="note" style="padding:0 18px 10px">Changed by ' + esc(ed.by || 'you') + ' from ' + num(ed.from) + ' to ' + num(ed.to) + ' · ' + esc(fmtDT(ed.at)) + '. The next stock upload replaces it.</div>' : '');
      row += '<div class="leftbox"><div class="lefthead">Waiting for it · ' + W.length + '</div>' + (W.length ? W.map(l => '<div class="leftrow"><span><b><span class="reqno sm" data-req="' + esc(l.req) + '">' + esc(l.req) + '</span> ' + esc(l.store) + '</b><span>' + fmtShort(l.date) + (l.date > today() ? ' · scheduled' : '') + '</span></span><b class="qty">' + num(l.qty) + '</b></div>').join('') : '<div class="note">No open request needs it.</div>') +
        '<div class="lefthead" style="margin-top:10px">Recent issues</div>' + (I.length ? I.map(o => '<div class="leftrow"><span><b>' + esc(o.e.store) + '</b><span>' + esc(o.e.slip) + ' · #' + esc(o.e.serial || '–') + ' · ' + fmtShort(entryDate(o.e)) + '</span></span><b class="qty">' + num(o.i.qty) + '</b></div>').join('') : '<div class="note">Not issued yet.</div>') + '</div>';
    }
    return '<div class="stkitem' + (open ? ' on' : '') + '">' + row + '</div>';
  }).join('') + '</div>';
  return h;
}
function vStock() {
  ui.stk = ui.stk || { q: '', f: 'all', open: null };
  const K = ui.stk;
  let h = '<header class="top"><div><button class="btn sm ghost" data-a="back">‹ Back</button><h1 style="margin-top:10px">Live stock</h1><div class="sub">Search any item. See what open requests need and what is free. Tap an item to edit it.</div></div></header><main>';
  h += stockCard();
  h += '<div class="sbox"><svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"><circle cx="11" cy="11" r="7"/><path d="M20 20l-4-4"/></svg><input type="search" data-stk="q" value="' + esc(K.q) + '" placeholder="Item name or code" autocomplete="off"></div>';
  h += '<div class="seg">' + [['all', 'All'], ['in', 'In stock'], ['zero', 'Zero'], ['need', 'Needed'], ['short', 'Short']].map(([k, l]) => '<button data-a="stkF" data-v="' + k + '" class="' + (K.f === k ? 'on' : '') + '">' + l + '</button>').join('') + '</div>';
  const nEd = Object.keys(S.stockEdits || {}).length;
  h += '<div class="grid2"><button class="btn" data-a="stkAdd">+ Add item</button><button class="btn" data-a="stkEdited"' + (nEd ? '' : ' disabled') + '>' + (K.f === 'edited' ? 'Show all' : 'Edited · ' + nEd) + '</button></div>';
  h += '<div id="stkres">' + stockResults() + '</div>';
  return h + '</main>';
}
function consRange() {
  const C = ui.cons, d = new Date(); d.setHours(12);
  if (C.p === 'week') { const a = new Date(d); a.setDate(d.getDate() - 6); return [isoOf(a), today()]; }
  if (C.p === 'month') return [isoOf(new Date(d.getFullYear(), d.getMonth(), 1, 12)), today()];
  if (C.p === 'last') return [isoOf(new Date(d.getFullYear(), d.getMonth() - 1, 1, 12)), isoOf(new Date(d.getFullYear(), d.getMonth(), 0, 12))];
  return [C.from || today(), C.to || today()];
}
function consData() {
  const [a, b] = consRange(), E = S.entries.filter(e => { const d = entryDate(e); return d >= a && d <= b; });
  const st = {}, it = {};
  E.forEach(e => { const so = st[e.store] = st[e.store] || { store: e.store, slips: new Set(), items: {}, n: 0 };
    so.slips.add(e.slip);
    e.items.forEach(i => { const q = Number(i.qty) || 0; so.n++; const x = so.items[i.code] = so.items[i.code] || { code: i.code, qty: 0, n: 0 }; x.qty += q; x.n++;
      const y = it[i.code] = it[i.code] || { code: i.code, qty: 0, stores: {} }; y.qty += q; y.stores[e.store] = (y.stores[e.store] || 0) + q; }); });
  return { a, b, E, stores: Object.values(st).sort((x, y) => y.n - x.n || byStore(x.store, y.store)), items: Object.values(it).sort((x, y) => Object.keys(y.stores).length - Object.keys(x.stores).length || y.qty - x.qty) };
}
function consRows() { const D = consData(), rows = []; D.stores.forEach(so => Object.values(so.items).sort((a, b) => b.qty - a.qty).forEach(x => rows.push({ Store: so.store, 'Item code': x.code, Item: itemName(x.code), UOM: itemUom(x.code), Qty: Math.round(x.qty * 1000) / 1000, Times: x.n }))); return rows; }
function bar(v, max, col) { return '<span class="cbar"><i style="width:' + Math.max(3, Math.round(v / (max || 1) * 100)) + '%;background:' + (col || '#141414') + '"></i></span>'; }
function donut(parts, size) {
  const tot = parts.reduce((n, p) => n + p.v, 0) || 1, R = size / 2 - 14, C = 2 * Math.PI * R; let off = 0;
  return '<svg viewBox="0 0 ' + size + ' ' + size + '" width="' + size + '" height="' + size + '" style="transform:rotate(-90deg)"><circle cx="' + size / 2 + '" cy="' + size / 2 + '" r="' + R + '" fill="none" stroke="#EEECF3" stroke-width="22"/>' +
    parts.map(p => { const L = p.v / tot * C, g = '<circle cx="' + size / 2 + '" cy="' + size / 2 + '" r="' + R + '" fill="none" stroke="' + p.c + '" stroke-width="22" stroke-dasharray="' + Math.max(0, L - 2).toFixed(1) + ' ' + C.toFixed(1) + '" stroke-dashoffset="' + (-off).toFixed(1) + '"/>'; off += L; return g; }).join('') + '</svg>';
}
function vCons() {
  ui.cons = ui.cons || { p: 'week', mode: 'store', open: {} };
  const C = ui.cons, D = consData();
  const COL = ['#8C7BE0', '#FFB648', '#5B9BFF', '#F27BD8', '#2BB673', '#FF7A59', '#9AA0A6'];
  let h = '<header class="top"><div><button class="btn sm ghost" data-a="back">‹ Back</button><h1 style="margin-top:10px">Consumption</h1><div class="sub">What each store took, from your issue slips.</div></div></header><main>';
  h += '<div class="seg">' + [['week', '7 days'], ['month', 'This month'], ['last', 'Last month'], ['custom', 'Custom']].map(([k, l]) => '<button data-a="consP" data-v="' + k + '" class="' + (C.p === k ? 'on' : '') + '">' + l + '</button>').join('') + '</div>';
  if (C.p === 'custom') h += '<div class="grid2"><label class="f">From<input type="date" data-cons="from" value="' + esc(C.from || today()) + '"></label><label class="f">To<input type="date" data-cons="to" value="' + esc(C.to || today()) + '"></label></div>';
  h += '<div class="note" style="text-align:center">' + fmtLong(D.a) + ' to ' + fmtLong(D.b) + '</div>';
  if (!D.E.length) return h + '<div class="card pad note">No issue slips in this period.</div></main>';
  const totalArt = D.stores.reduce((n, so) => n + so.n, 0);
  // share by store: donut + legend
  const top = D.stores.slice(0, 6).map((so, k) => ({ name: so.store, v: so.n, c: COL[k] }));
  const rest = D.stores.slice(6).reduce((n, so) => n + so.n, 0); if (rest) top.push({ name: 'Others (' + (D.stores.length - 6) + ')', v: rest, c: COL[6] });
  h += '<div class="card pad col" style="gap:14px"><div class="row"><b class="ttl">Share by store</b><span class="note">' + totalArt + ' articles · ' + D.E.length + ' slips</span></div>' +
    '<div class="donutwrap"><div class="donut">' + donut(top, 180) + '<div class="dc"><b>' + D.stores.length + '</b><span>stores</span></div></div>' +
    '<div class="legend">' + top.map(p => '<div><i style="background:' + p.c + '"></i><span>' + esc(p.name) + '</span><b>' + Math.round(p.v / totalArt * 100) + '%</b></div>').join('') + '</div></div></div>';
  // top items
  const ti = D.items.slice().sort((a, b) => Object.keys(b.stores).length - Object.keys(a.stores).length || b.qty - a.qty).slice(0, 8), mx = Math.max(...ti.map(x => Object.keys(x.stores).length));
  h += '<div class="card pad col" style="gap:4px"><div class="row" style="margin-bottom:6px"><b class="ttl">Most issued items</b><span class="note">by number of stores</span></div>' +
    ti.map((x, k) => '<div class="consrow"><span><b>' + esc(itemName(x.code)) + '</b><span>' + Object.keys(x.stores).length + ' stores</span></span>' + bar(Object.keys(x.stores).length, mx, COL[k % 6]) + '<b class="qty">' + num(Math.round(x.qty * 1000) / 1000) + ' <small>' + esc(itemUom(x.code)) + '</small></b></div>').join('') + '</div>';
  // details
  h += '<div class="shead"><div><h2>Details</h2><span>Tap a ' + (C.mode === 'store' ? 'store' : 'item') + ' to open it</span></div></div>';
  h += '<div class="seg"><button data-a="consM" data-v="store" class="' + (C.mode === 'store' ? 'on' : '') + '">Stores</button><button data-a="consM" data-v="item" class="' + (C.mode === 'item' ? 'on' : '') + '">Items</button></div>';
  h += '<div class="card" style="overflow:hidden">';
  if (C.mode === 'store') {
    const maxN = Math.max(...D.stores.map(x => x.n));
    D.stores.forEach((so, k) => { const its = Object.values(so.items).sort((a, b) => b.qty - a.qty), open = !!C.open['s' + so.store];
      h += '<button class="consh" data-a="consO" data-v="s' + esc(so.store) + '"><i class="cdot" style="background:' + COL[Math.min(k, 6)] + '"></i><span class="cn"><b>' + esc(so.store) + '</b><span>' + so.slips.size + ' slips · ' + its.length + ' items</span></span>' + bar(so.n, maxN, COL[Math.min(k, 6)]) + '<b class="cv">' + so.n + '</b>' + ico(open ? 'up' : 'down', 16) + '</button>';
      if (open) h += '<div class="leftbox" style="background:var(--soft)">' + its.map(x => '<div class="leftrow"><span><b>' + esc(itemName(x.code)) + '</b><span class="mono">' + esc(x.code) + ' · issued ' + x.n + 'x</span></span><b class="qty">' + num(Math.round(x.qty * 1000) / 1000) + ' ' + esc(itemUom(x.code)) + '</b></div>').join('') + '</div>'; });
  } else {
    D.items.slice(0, 120).forEach(x => { const sts = Object.entries(x.stores).sort((a, b) => b[1] - a[1]), open = !!C.open['i' + x.code];
      h += '<button class="consh" data-a="consO" data-v="i' + esc(x.code) + '"><span class="cn"><b>' + esc(itemName(x.code)) + '</b><span>' + esc(x.code) + ' · ' + sts.length + ' stores</span></span><b class="cv">' + num(Math.round(x.qty * 1000) / 1000) + ' <small>' + esc(itemUom(x.code)) + '</small></b>' + ico(open ? 'up' : 'down', 16) + '</button>';
      if (open) h += '<div class="leftbox" style="background:var(--soft)">' + sts.map(([st, q], k) => '<div class="consrow"><span><b>' + esc(st) + '</b></span>' + bar(q, sts[0][1], COL[k % 6]) + '<b class="qty">' + num(Math.round(q * 1000) / 1000) + '</b></div>').join('') + '</div>'; });
  }
  h += '</div><button class="btn" data-a="consExport">Download full report</button>';
  return h + '</main>';
}
function mgInit() { ui.mg = ui.mg || { type: 'req', q: '', rf: '', rt: '', if: '', it: '', stores: {}, st: {}, sel: {}, showF: false }; return ui.mg; }
function mgReqs() {
  const M = mgInit(), q = String(M.q || '').toUpperCase(), PL = plan();
  let L = requests().map(r => { const w = r.lines.filter(l => l.status === 'waiting'), iss = r.lines.filter(l => l.status === 'issued');
    const st = r.date > today() && w.length ? 'scheduled' : !w.length ? 'completed' : iss.length ? 'partly' : 'pending';
    return { kind: 'req', id: r.req, req: r.req, store: r.store, date: r.date, st, n: r.lines.filter(l => l.status !== 'dropped').length, w: w.length, slips: reqSlips(r.req) }; });
  Object.values(S.manReqs || {}).forEach(m => { if (!L.some(x => x.req === m.req)) L.push({ kind: 'req', id: m.req, req: m.req, store: m.store, date: m.date, st: 'manual', man: true, mst: m.status, n: m.total || 0, w: 0, slips: reqSlips(m.req) }); });
  return L.filter(x => (!M.rf || x.date >= M.rf) && (!M.rt || x.date <= M.rt) && (!Object.keys(M.stores).length || M.stores[x.store]) && (!Object.keys(M.st).length || M.st[x.st] || (x.man && M.st.manual))
    && (!M.if && !M.it || x.slips.some(e => (!M.if || entryDate(e) >= M.if) && (!M.it || entryDate(e) <= M.it))) && (!q || (x.req + ' ' + x.store).toUpperCase().includes(q)));
}
function mgSlips() {
  const M = mgInit(), q = String(M.q || '').toUpperCase();
  return S.entries.map(e => { const reqs = [...new Set(e.items.map(i => i.req).filter(Boolean).concat(e.reqs ? String(e.reqs).split(/\s*,\s*/) : []))]; const rd = reqs.map(reqDateOfRaw).filter(Boolean).sort()[0] || ((S.manReqs || {})[reqs[0]] || {}).date || '';
    return { kind: 'slip', id: String(e.id), e, req: reqs.join(', '), store: e.store, date: entryDate(e), rdate: rd, st: e.kind === 'manual' ? 'manual' : 'app' }; })
    .filter(x => (!M.if || x.date >= M.if) && (!M.it || x.date <= M.it) && (!M.rf || x.rdate >= M.rf) && (!M.rt || (x.rdate && x.rdate <= M.rt)) && (!Object.keys(M.stores).length || M.stores[x.store]) && (!Object.keys(M.st).length || M.st[x.st])
      && (!q || (x.req + ' ' + x.store + ' ' + x.e.slip + ' ' + (x.e.serial || '')).toUpperCase().includes(q)));
}
function mgRets() {
  const M = mgInit(), q = String(M.q || '').toUpperCase();
  return S.returns.map(r => ({ kind: 'ret', id: String(r.id), r, store: r.store, date: r.date })).filter(x => (!M.if || x.date >= M.if) && (!M.it || x.date <= M.it) && (!Object.keys(M.stores).length || M.stores[x.store]) && (!q || (x.r.no + ' ' + x.store + ' ' + (x.r.serial || '')).toUpperCase().includes(q)));
}
function mgList() { const M = mgInit(); const L = M.type === 'req' ? mgReqs() : M.type === 'slip' ? mgSlips() : mgRets(); return L.sort((a, b) => String(b.date).localeCompare(String(a.date)) || String(a.req || a.id).localeCompare(String(b.req || b.id), undefined, { numeric: true })); }
const MG_ST = { req: [['pending', 'Pending'], ['partly', 'Partly done'], ['completed', 'Completed'], ['scheduled', 'Scheduled'], ['manual', 'Manual record']], slip: [['app', 'App slips'], ['manual', 'Manual slips']], ret: [] };
function mgResults() {
  const M = mgInit(), L = mgList(), selN = L.filter(x => M.sel[x.id]).length, all = L.length && selN === L.length;
  let h = '<div class="row" style="align-items:center"><label class="chk" style="min-height:40px"><input type="checkbox" data-a="mgAll"' + (all ? ' checked' : '') + '> Select all ' + L.length + '</label><span class="note">' + selN + ' selected</span></div>';
  if (!L.length) return h + '<div class="card pad note">Nothing matches these filters.</div>';
  h += '<div class="card" style="overflow:hidden">' + L.slice(0, 400).map(x => {
    let main, tag;
    if (x.kind === 'req') { tag = x.man ? (x.mst === 'done' ? pill('Manual · done', 'c-ok') : pill('Manual · pending', 'c-gd')) : x.st === 'completed' ? pill('Completed', 'c-ok') : x.st === 'partly' ? pill(x.w + ' left', 'c-gd') : x.st === 'scheduled' ? pill('Scheduled', 'c-in') : pill('Pending', 'c-no');
      main = '<span class="reqno sm" data-req="' + esc(x.req) + '">' + esc(x.req) + '</span> <b>' + esc(x.store) + '</b><div class="meta"><span>' + fmtShort(x.date) + '</span><i></i><span>' + x.n + ' articles</span><i></i><span>' + x.slips.length + ' slip' + (x.slips.length === 1 ? '' : 's') + '</span></div>'; }
    else if (x.kind === 'slip') { tag = x.st === 'manual' ? '<span class="stag man" style="position:static">Manual</span>' : '<span class="stag appt" style="position:static">App</span>';
      main = '<b class="mono">' + esc(x.e.slip) + '</b> ' + serFmt(x.e.serial) + ' <b>' + esc(x.store) + '</b><div class="meta"><span>' + fmtShort(x.date) + ' ' + esc(entryTime(x.e)) + '</span><i></i><span>' + entryCount(x.e) + ' art.</span>' + (x.req ? '<i></i><span class="reqno sm" data-req="' + esc(x.req.split(', ')[0]) + '">' + esc(x.req) + '</span>' : '') + '</div>'; }
    else { tag = '<span class="stag ret" style="position:static">Return</span>'; main = '<b class="mono">' + esc(x.r.no) + '</b> <b>' + esc(x.store) + '</b><div class="meta"><span>' + fmtShort(x.date) + '</span><i></i><span>' + x.r.items.length + ' items</span></div>'; }
    return '<label class="mgrow' + (M.sel[x.id] ? ' on' : '') + '"><input type="checkbox" data-a="mgSel" data-v="' + esc(x.id) + '"' + (M.sel[x.id] ? ' checked' : '') + '><span class="mgm">' + main + '</span>' + tag + '</label>';
  }).join('') + '</div>' + (L.length > 400 ? '<div class="note">Showing 400. Narrow the filters to see the rest.</div>' : '');
  return h;
}
function vManage() {
  const M = mgInit(), stores = allStores();
  const nF = (M.rf || M.rt ? 1 : 0) + (M.if || M.it ? 1 : 0) + Object.keys(M.stores).length + Object.keys(M.st).length;
  let h = '<header class="top"><div><button class="btn sm ghost" data-a="back">‹ Back</button><h1 style="margin-top:10px">Manage data</h1><div class="sub">Filter, select many, then delete, complete or export in one go. Undo works for 5 seconds.</div></div></header><main>';
  h += '<div class="seg">' + [['req', 'Requests'], ['slip', 'Slips'], ['ret', 'Returns']].map(([k, l]) => '<button data-a="mgType" data-v="' + k + '" class="' + (M.type === k ? 'on' : '') + '">' + l + '</button>').join('') + '</div>';
  h += '<div class="sbox"><svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"><circle cx="11" cy="11" r="7"/><path d="M20 20l-4-4"/></svg><input type="search" data-mg="q" value="' + esc(M.q) + '" placeholder="Request No, store, slip, serial" autocomplete="off"></div>';
  h += '<div class="card" style="overflow:hidden"><button class="mgfh" data-a="mgF"><b>Filters</b>' + (nF ? pill(nF + ' on', 'c-in') : '<span class="note">none</span>') + ico(M.showF ? 'up' : 'down', 18) + '</button>';
  if (M.showF) {
    h += '<div class="pad col" style="gap:12px;padding-top:0">';
    if (M.type !== 'ret') h += '<div><div class="note" style="font-weight:600;margin-bottom:6px">Request date</div><div class="grid2"><label class="f">From<input type="date" data-mg="rf" value="' + esc(M.rf) + '"></label><label class="f">To<input type="date" data-mg="rt" value="' + esc(M.rt) + '"></label></div></div>';
    h += '<div><div class="note" style="font-weight:600;margin-bottom:6px">Issue date</div><div class="grid2"><label class="f">From<input type="date" data-mg="if" value="' + esc(M.if) + '"></label><label class="f">To<input type="date" data-mg="it" value="' + esc(M.it) + '"></label></div></div>';
    if (MG_ST[M.type].length) h += '<div><div class="note" style="font-weight:600;margin-bottom:6px">Status (pick any)</div><div class="fchips">' + MG_ST[M.type].map(([k, l]) => '<button data-a="mgSt" data-v="' + k + '" class="' + (M.st[k] ? 'on' : '') + '">' + l + '</button>').join('') + '</div></div>';
    h += '<div><div class="note" style="font-weight:600;margin-bottom:6px">Stores (pick any)</div><div class="fchips">' + stores.map(st => '<button data-a="mgStore" data-v="' + esc(st) + '" class="' + (M.stores[st] ? 'on' : '') + '">' + esc(st) + '</button>').join('') + '</div></div>';
    h += '<button class="btn sm ghost" data-a="mgClearF">Clear all filters</button></div>';
  }
  h += '</div><div id="mgres">' + mgResults() + '</div></main>';
  const selN = mgList().filter(x => M.sel[x.id]).length;
  if (selN) h += '<div class="selbar"><b>' + selN + ' selected</b>' + (M.type === 'req' ? '<button class="btn sm" data-a="mgDone">Complete</button><button class="btn sm" data-a="mgPend">Clear pending</button>' : M.type === 'slip' ? '<button class="btn sm" data-a="mgDelSlipPend">Undo issue</button>' : '') + '<button class="btn sm" data-a="mgExport">Export</button><button class="btn sm danger" data-a="mgDel">Delete</button><button class="xbtn" data-a="mgClear" aria-label="Clear selection">' + ico('x', 16) + '</button></div>';
  return h;
}
/* ---------------- Verify on CUIMS (read only) ---------------- */
function usOf(iso, add) { const d = new Date((iso || today()) + 'T12:00'); d.setDate(d.getDate() + (add || 0)); return (d.getMonth() + 1) + '/' + d.getDate() + '/' + d.getFullYear(); }
function vTargetsFor(scope) {
  const T = [], seen = new Set(); let entries = [], rets = [];
  if (scope.type === 'req') entries = reqSlips(scope.id);
  if (scope.type === 'ret') rets = S.returns.filter(r => String(r.id) === String(scope.id));
  if (scope.type === 'day') { entries = S.entries.filter(e => entryDate(e) === scope.id); rets = S.returns.filter(r => r.serial && (r.date === scope.id)); }
  entries.forEach(e => { const k = 'e' + e.id; if (seen.has(k) || (!e.serial && !e.slip)) return; seen.add(k); const d = entryDate(e); T.push({ key: k, serial: String(e.serial || '').trim(), slip: e.slip, from: usOf(d, -3), to: usOf(d, 2) }); });
  rets.forEach(r => { if (!r.serial) return; const d = r.date; T.push({ key: 'r' + r.id, serial: String(r.serial).trim(), slip: '', from: usOf(d, -3), to: usOf(d, 2) }); });
  return T;
}
async function startVerify(scope) {
  if (!N) { toast('Open this inside the JV Stock Issue app.'); return; }
  const T = vTargetsFor(scope), noSer = scope.type === 'ret' && !T.length;
  if (noSer) { toast('This return has no Serial yet, so there is nothing to check on CUIMS.'); return; }
  const title = scope.type === 'req' ? 'Request ' + scope.id : scope.type === 'ret' ? 'Return ' + ((S.returns.find(r => String(r.id) === String(scope.id)) || {}).no || '') : 'All of ' + fmtLong(scope.id);
  if (scope.type !== 'day' && !T.length) { toast('No slip or serial saved for this request yet.'); return; }
  if (!(await uiConfirm('Verify ' + title + ' on CUIMS? It only reads Show Transactions and opens each serial with SHOW. Nothing is changed or submitted. ' + T.length + ' serial' + (T.length === 1 ? '' : 's') + (scope.type === 'day' ? ' + every other transaction of that day' : '') + ' will be checked.', 'Start checking'))) return;
  const job = { id: 'V' + Date.now(), kind: 'verify', phase: 'verify', slip: 'VERIFY', store: title, title, scope, targets: T, idx: 0, res: {}, log: [], tries: {}, queue: false, autoSubmit: false, items: [] };
  if (scope.type === 'day') job.day = { us: usOf(scope.id), label: fmtLong(scope.id) };
  { const I = ignList(); job.ignore = { serials: Object.keys(I.serials), people: Object.keys(I.people) }; }
  N.startJob(jobJson(job));
}
function ignList() { S.cuimsIgnore = S.cuimsIgnore || { serials: {}, people: {} }; return S.cuimsIgnore; }
function personCode(txt) { const m = String(txt || '').match(/GA\d{6}/i); return m ? m[0].toUpperCase() : ''; }
function isIgnored(serial, entryBy) { const I = ignList(); return !!I.serials[String(serial)] || (!!personCode(entryBy) && !!I.people[personCode(entryBy)]); }
function vNorm(x) { return String(x || '').trim().toUpperCase().replace(/\s+/g, ' '); }
function buildVerifyReport(e) {
  const scope = e.scope || {}, res = e.res || {}, F = [], DT = {};
  const add = o => F.push(Object.assign({ id: 'f' + F.length + Date.now() }, o));
  Object.entries(res).forEach(([key, r]) => {
    const ent = key[0] === 'e' ? S.entries.find(x => 'e' + x.id === key) : null, ret = key[0] === 'r' ? S.returns.find(x => 'r' + x.id === key) : null;
    if (key[0] === 'x') { if (r.list && isIgnored(r.list.serial, r.list.entryBy)) return; if (r.found && r.shown) DT[key] = { serial: r.list.serial, slip: r.shown.slip || r.list.slip, date: r.list.entryDate, entryBy: r.list.entryBy, rcv: r.list.rcv || r.shown.rcv, pa: r.shown.pa, type: r.shown.type, issueType: r.shown.issueType, dept: r.shown.dept, desc: r.list.desc, items: (r.shown.items || []).map(c => ({ code: vNorm(c.code), name: c.name || itemName(c.code), qty: Number(c.qty), remark: c.remark || '', app: null })), missing: [] }; if (r.found && r.shown) { const known = S.entries.some(z => String(z.serial) === String(r.list.serial)) || S.returns.some(z => String(z.serial) === String(r.list.serial)); if (!known) add({ key, kind: 'notInApp', serial: r.list.serial, slip: r.list.slip || r.shown.slip, store: r.shown.pa, rcv: r.list.rcv || r.shown.rcv, isReturn: r.list.isReturn, items: r.shown.items, entryBy: r.list.entryBy, date: r.list.entryDate }); } return; }
    const label = ent ? ent.slip + (ent.serial ? ' · #' + ent.serial : '') : ret ? ret.no + ' · #' + ret.serial : key;
    const exp = ent ? ent.items.map(i => ({ code: vNorm(i.code), qty: Number(i.qty), remark: i.remark || '', lineId: i.lineId, req: i.req })) : ret ? ret.items.map(i => ({ code: vNorm(i.code), qty: Number(i.qty), remark: retRemark(ret) })) : [];
    if (!r.found) { add({ key, label, kind: 'notFound', serial: r.serial, slip: r.slip }); return; }
    const sh = r.shown || { items: [] };
    { const ap = {}; exp.forEach(x => { ap[x.code] = x; });
      DT[key] = { isRet: !!ret, emp: sh.emp || '', codes: (r.list || {}).codes || [], serial: (r.list || {}).serial || r.serial || '', slip: sh.slip || (r.list || {}).slip || '', date: (r.list || {}).entryDate || sh.date || '', entryBy: (r.list || {}).entryBy || '', rcv: (r.list || {}).rcv || sh.rcv || '', pa: sh.pa || '', type: sh.type || '', issueType: sh.issueType || '', dept: sh.dept || '', desc: (r.list || {}).desc || '',
        items: (sh.items || []).map(c => { const a2 = ap[vNorm(c.code)]; return { code: vNorm(c.code), name: c.name || itemName(c.code), qty: Number(c.qty), remark: c.remark || '', app: a2 ? a2.qty : null }; }),
        missing: exp.filter(x => !(sh.items || []).some(c => vNorm(c.code) === x.code)).map(x => ({ code: x.code, qty: x.qty })) }; }
    if (ent && !String(ent.serial || '').trim() && r.list && r.list.serial) add({ key, label, kind: 'serial', val: r.list.serial });
    const ms = [...new Set(r.multi || [])]; if (ms.length > 1) add({ key, label, kind: 'multi', serials: ms });
    if (ent && sh.pa && vNorm(sh.pa) !== vNorm(ent.store)) add({ key, label, kind: 'store', app: ent.store, cuims: sh.pa });
    const appR = String(ent ? ent.rcv : ret ? ret.by : '');
    const okCode = x => validRcv(String(x || ''));
    const storeSide = ret ? new Set([String(sh.rcv || ''), String((r.list && r.list.rcv) || '')].filter(okCode)) : new Set();
    const cand = ret ? [...new Set([sh.emp].concat((r.list && r.list.codes) || [], sh.allCodes || []).filter(okCode).map(String))].filter(c => !storeSide.has(c) || c === String(sh.emp))
      : [...new Set([].concat((r.list && r.list.rcv) || [], sh.rcv || []).filter(okCode).map(String))];
    const best = ret ? (okCode(sh.emp) ? sh.emp : cand[0]) : cand[0];
    if (appR && cand.length && !cand.includes(appR)) add({ key, label, kind: 'rcv', ret: !!ret, app: appR, cuims: best, all: cand });
    if (ret && sh.type && !/return/i.test(sh.type)) add({ key, label, kind: 'type', cuims: sh.type });
    const cu = {}; (sh.items || []).forEach(i => { cu[vNorm(i.code)] = i; });
    exp.forEach(x => { const c = cu[x.code];
      if (!c) add({ key, label, kind: 'missing', code: x.code, qty: x.qty, lineId: x.lineId });
      else { if (Math.abs(Number(c.qty) - x.qty) > 1e-6) add({ key, label, kind: 'qty', code: x.code, app: x.qty, cuims: Number(c.qty), lineId: x.lineId });
        if (x.remark && vNorm(c.remark) !== vNorm(x.remark)) add({ key, label, kind: 'remark', code: x.code, app: x.remark, cuims: c.remark || '(blank)' }); } });
    const ex = new Set(exp.map(x => x.code)); (sh.items || []).forEach(c => { if (!ex.has(vNorm(c.code))) add({ key, label, kind: 'extra', code: vNorm(c.code), qty: Number(c.qty), name: c.name }); });
    if (!F.some(f => f.key === key)) add({ key, label, kind: 'ok', n: exp.length });
  });
  const rep = { details: DT, id: 'VR' + Date.now(), at: new Date().toISOString(), scope, title: e.title || (scope.type === 'day' ? 'All of ' + fmtLong(scope.id) : scope.id), findings: F, checked: Object.keys(res).filter(k => k[0] !== 'x').length, dayCount: (e.dayRows || []).length };
  S.verifyReports = [rep].concat(S.verifyReports || []).slice(0, 40);
  S.verified = S.verified || {};
  const reqOf = k => { const en = S.entries.find(x => 'e' + x.id === k); return en ? [...new Set(en.items.map(i => i.req).filter(Boolean).concat(en.reqs ? String(en.reqs).split(/\s*,\s*/) : []))] : []; };
  const per = {}; F.forEach(f => reqOf(f.key).forEach(q => { per[q] = per[q] || 0; if (f.kind !== 'ok' && !fIgnored(f)) per[q]++; }));
  Object.entries(per).forEach(([q, n]) => { S.verified[q] = { at: rep.at, issues: n, rep: rep.id }; });
  F.filter(f => f.key[0] === 'r').forEach(f => { const r = S.returns.find(x => 'r' + x.id === f.key); if (r) r.verified = { at: rep.at, issues: F.filter(g => g.key === f.key && g.kind !== 'ok' && !fIgnored(g)).length }; });
  save(); ui.vrep = rep.id; ui.view = 'vreport'; render(); window.scrollTo(0, 0);
}
function fSig(f) { return [f.kind, f.label || f.serial || f.slip || f.key, f.code || ''].join('|'); }
function fIgnored(f) { return f.kind !== 'ok' && !!(S.verifyIgnore || {})[fSig(f)]; }
function vFinding(f, rep) {
  if (fIgnored(f) && !ui.showIgn) return '';
  const nm = c => esc(itemName(c));
  const T = { ok: ['All good', 'c-ok', f.n + ' article' + (f.n === 1 ? '' : 's') + ' match CUIMS exactly'],
    notFound: ['Not found on CUIMS', 'c-no', (f.serial ? 'Serial ' + f.serial : 'Slip ' + f.slip) + ' is not in Show Transactions'],
    serial: ['Serial missing in app', 'c-gd', 'CUIMS has Serial ' + f.val],
    multi: ['Slip used more than once', 'c-no', 'Serials ' + (f.serials || []).join(', ')],
    store: ['Store differs', 'c-no', 'App: ' + esc(f.app) + ' · CUIMS Project Area: ' + esc(f.cuims)],
    rcv: [f.ret ? 'By employee differs' : 'Receiver differs', 'c-no', 'App: ' + esc(rcvLabel(f.app)) + (rcvName(f.app) ? ' ' + esc(rcvName(f.app)) : '') + ' · CUIMS: ' + (validRcv(String(f.cuims || '')) ? esc(rcvLabel(f.cuims)) + (rcvName(f.cuims) ? ' ' + esc(rcvName(f.cuims)) : '') : 'not readable') + ((f.all || []).length > 1 ? ' · codes on CUIMS: ' + f.all.map(c => rcvLabel(c)).join(', ') : '')],
    type: ['Not a return on CUIMS', 'c-no', 'CUIMS type: ' + esc(f.cuims)],
    missing: ['Missing on CUIMS', 'c-no', nm(f.code) + ' (' + esc(f.code) + ') ' + num(f.qty) + ' is in the app but not in this serial'],
    qty: ['Qty differs', 'c-gd', nm(f.code) + ' · app ' + num(f.app) + ' · CUIMS ' + num(f.cuims)],
    remark: ['Remark differs', 'c-gd', nm(f.code) + ' · CUIMS: ' + esc(f.cuims)],
    extra: ['Extra on CUIMS', 'c-no', esc(f.name || itemName(f.code)) + ' (' + esc(f.code) + ') ' + num(f.qty) + ' is on CUIMS but not in the app'],
    notInApp: ['On CUIMS, not in app', 'c-no', (f.isReturn ? 'Return' : 'Issue') + ' Serial ' + esc(f.serial) + ' · Slip ' + esc(f.slip || '–') + ' · ' + esc(f.store || '') + ' · ' + esc(rcvLabel(f.rcv || '–')) + ' · ' + (f.items || []).length + ' articles · by ' + esc(f.entryBy || '')] }[f.kind] || ['Note', 'c-gy', ''];
  const fix = f.fixed ? '<span class="sc ok">fixed</span>' : ({ serial: 'Save Serial ' + f.val + ' in app', qty: 'Use CUIMS qty in app', missing: 'Make it pending again', extra: 'Add to app as issued', store: 'Use CUIMS store in app', rcv: f.ret ? 'Use CUIMS employee in app' : 'Use CUIMS receiver in app', notInApp: 'Add as manual slip' }[f.kind]);
  if (f.kind === 'notInApp' && (f.ignored || isIgnored(f.serial, f.entryBy))) return '<div class="vf"><div class="row">' + pill('Ignored', 'c-gy') + '</div><div class="vft">Serial ' + esc(f.serial) + ' is on your ignore list. It will not be checked again.</div></div>';
  const ign = f.kind === 'notInApp' && !f.fixed ? '<div class="grid2" style="margin-top:2px"><button class="btn sm ghost" data-a="vfIgn" data-v="' + rep.id + '|' + f.id + '">Ignore this serial</button>' + (personCode(f.entryBy) ? '<button class="btn sm ghost" data-a="vfIgnP" data-v="' + rep.id + '|' + f.id + '">Ignore all by ' + esc(personCode(f.entryBy)) + '</button>' : '<span></span>') + '</div>' : '';
  const igb = f.kind === 'ok' || f.fixed ? '' : fIgnored(f) ? '<div class="row" style="gap:8px"><span class="sc gd">Ignored' + ((S.verifyIgnore[fSig(f)] || {}).note ? ': ' + esc(S.verifyIgnore[fSig(f)].note) : '') + '</span><button class="btn sm ghost" data-a="vfUnIgn" data-v="' + rep.id + '|' + f.id + '">Un-ignore</button></div>' : '<button class="btn sm ghost" data-a="vfIgnF" data-v="' + rep.id + '|' + f.id + '">Ignore this error</button>';
  return '<div class="vf' + (fIgnored(f) ? ' ign' : '') + '"><div class="row">' + pill(T[0], T[1]) + (f.label ? '<span class="note mono">' + esc(f.label) + '</span>' : '') + '</div><div class="vft">' + T[2] + '</div>' + (fix && !f.fixed && !fIgnored(f) ? '<button class="btn sm" data-a="vfFix" data-v="' + rep.id + '|' + f.id + '">' + esc(fix) + '</button>' : (f.fixed ? '<span class="sc ok">Fixed in app</span>' : '')) + (fIgnored(f) ? '' : ign) + igb + '</div>';
}
function vReport() {
  const R = (S.verifyReports || []).find(r => r.id === ui.vrep) || (S.verifyReports || [])[0];
  if (R) R.findings = R.findings.filter(f => !(f.kind === 'multi' && new Set(f.serials || []).size < 2) && !(f.kind === 'rcv' && !validRcv(String(f.cuims || ''))));
  let h = '<header class="top"><div><button class="btn sm ghost" data-a="back">‹ Back</button><h1 style="margin-top:10px">Verification</h1><div class="sub">' + (R ? esc(R.title) + ' · checked ' + esc(fmtDT(R.at)) : 'No checks yet') + '</div></div></header><main>';
  if (!R) return h + '<div class="card pad note">Use "Verify on CUIMS" on a request, a return, or a whole day.</div></main>';
  const bad = R.findings.filter(f => f.kind !== 'ok' && !f.fixed && !fIgnored(f) && !(f.kind === 'notInApp' && isIgnored(f.serial, f.entryBy))), ok = R.findings.filter(f => f.kind === 'ok'), nIgn = R.findings.filter(fIgnored).length;
  h += '<div class="grid3"><div class="tile t-ok"><b>' + ok.length + '</b><span>All good</span></div><div class="tile t-pt"><b>' + bad.length + '</b><span>To check</span></div><div class="tile t-in"><b>' + R.checked + '</b><span>Serials read</span></div></div>';
  if (R.dayCount) h += '<div class="note">' + R.dayCount + ' transactions listed on CUIMS for that day.</div>';
  if (nIgn) h += '<button class="btn sm ghost" data-a="vfShowIgn">' + (ui.showIgn ? 'Hide' : 'Show') + ' ' + nIgn + ' ignored error' + (nIgn > 1 ? 's' : '') + '</button>';
  if (!bad.length) h += '<div class="okbox"><span>' + (nIgn ? 'Everything else matches CUIMS.' : 'Everything matches CUIMS.') + '</span></div>';
  const G = {}; R.findings.forEach(f => (G[f.key] = G[f.key] || []).push(f));
  Object.values(G).filter(L => ui.showIgn || !L.every(f => fIgnored(f) || (f.kind === 'notInApp' && isIgnored(f.serial, f.entryBy)))).sort((a, b) => (b.some(f => f.kind !== 'ok' && !f.fixed) ? 1 : 0) - (a.some(f => f.kind !== 'ok' && !f.fixed) ? 1 : 0)).forEach(L => {
    const en = S.entries.find(x => 'e' + x.id === L[0].key), rt = S.returns.find(x => 'r' + x.id === L[0].key);
    const head = en ? '<span class="reqno sm" data-req="' + esc((en.items[0] || {}).req || en.reqs || '') + '">' + esc((en.items[0] || {}).req || en.reqs || '–') + '</span> <b>' + esc(en.store) + '</b>' : rt ? '<span class="stag ret" style="position:static">' + esc(rt.no) + '</span> <b>' + esc(rt.store) + '</b>' : '<b>Not in the app</b>';
    const D = (R.details || {})[L[0].key], dk = R.id + ':' + L[0].key, op = !!(ui.vdOpen || {})[dk];
    let det = '';
    if (D) { det = '<button class="leftbtn retl" data-a="vdTog" data-v="' + esc(dk) + '" style="border-radius:16px"><span>' + (op ? 'Hide' : 'Show') + ' CUIMS details · ' + D.items.length + ' articles</span>' + ico(op ? 'up' : 'down', 18) + '</button>';
      if (op) det += '<div class="vdet"><div class="vdgrid">' + [['Serial', D.serial], ['Slip No', D.slip], ['Entry date', D.date], ['Entered by', D.entryBy], [D.isRet ? 'By employee (CUIMS)' : 'Received by', (D.isRet ? (D.emp || (D.codes || [])[0]) : D.rcv) ? rcvLabel(D.isRet ? (D.emp || D.codes[0]) : D.rcv) + (rcvName(D.isRet ? (D.emp || D.codes[0]) : D.rcv) ? ' ' + rcvName(D.isRet ? (D.emp || D.codes[0]) : D.rcv) : '') : ''], [D.isRet ? 'Other codes on CUIMS' : '', D.isRet ? (D.codes || []).filter(c => c !== (D.emp || D.codes[0])).map(c => rcvLabel(c)).join(', ') : ''], ['Project Area', D.pa], ['Transaction', [D.type, D.issueType].filter(Boolean).join(' · ')], ['Department', D.dept]].filter(x => x[1]).map(x => '<div><span>' + x[0] + '</span><b>' + esc(x[1]) + '</b></div>').join('') + '</div>' +
        '<div class="tblwrap"><table><tr><th>Code</th><th>Item</th><th>CUIMS qty</th><th>App qty</th><th>Remarks</th></tr>' +
        D.items.map(i => '<tr><td class="mono">' + esc(i.code) + '</td><td>' + esc(i.name) + '</td><td><b>' + num(i.qty) + '</b> ' + esc(itemUom(i.code)) + '</td><td' + (i.app == null ? ' style="color:var(--noInk);font-weight:700">not in app' : Math.abs(i.app - i.qty) > 1e-6 ? ' style="color:#B45309;font-weight:700">' + num(i.app) : ' style="color:#0B5E3D;font-weight:700">' + num(i.app) + ' ✓') + '</td><td>' + esc(i.remark || '–') + '</td></tr>').join('') +
        D.missing.map(m => '<tr style="background:#FFF0F3"><td class="mono">' + esc(m.code) + '</td><td>' + esc(itemName(m.code)) + '</td><td style="color:var(--noInk);font-weight:700">missing</td><td><b>' + num(m.qty) + '</b></td><td>–</td></tr>').join('') + '</table></div></div>'; }
    h += '<div class="card pad col" style="gap:10px"><div>' + head + '</div>' + L.map(f => vFinding(f, R)).join('') + det + '</div>';
  });
  h += '<div class="grid2"><button class="btn" data-a="vrExport">Download findings</button><button class="btn" data-a="vrExportItems">Download all articles</button></div><button class="btn ghost" data-a="vrList">All reports</button>';
  return h + '</main>';
}
/* ---------------- Link CUIMS serials to requests (entries done outside the app) ---------------- */
function cuDate(t) { const m = String(t || '').match(/(\d{1,2})\/(\d{1,2})\/(\d{4})(?:\s+(\d{1,2}):(\d{2})(?::\d{2})?\s*(AM|PM)?)?/i); if (!m) return { iso: today(), time: '' };
  let hh = +(m[4] || 0); if (m[6]) { if (/PM/i.test(m[6]) && hh < 12) hh += 12; if (/AM/i.test(m[6]) && hh === 12) hh = 0; }
  return { iso: m[3] + '-' + String(m[1]).padStart(2, '0') + '-' + String(m[2]).padStart(2, '0'), time: m[4] ? String(hh).padStart(2, '0') + ':' + m[5] : '' }; }
function addDays(iso, k) { const d = new Date(iso + 'T12:00'); d.setDate(d.getDate() + k); return isoOf(d); }
function lkRange(f) { f.rFrom = f.rFrom || f.date || today(); f.rTo = f.rTo && f.rTo >= f.rFrom ? f.rTo : f.rFrom; f.cFrom = f.cFrom || f.rFrom; f.cTo = f.cTo && f.cTo >= f.cFrom ? f.cTo : addDays(f.rTo, 1); return f; }
function linkReqs(a, b) { b = b || a; return requests().filter(r => r.date >= a && r.date <= b && r.lines.some(l => l.status === 'waiting')).sort((a, b) => String(a.req).localeCompare(String(b.req), undefined, { numeric: true })); }
function shLink() {
  const f = lkRange(ui.form), R = linkReqs(f.rFrom, f.rTo);
  const gap = Math.round((new Date(f.cTo) - new Date(f.cFrom)) / 864e5);
  let h = '<div class="row"><h2>Link CUIMS serials</h2><button class="btn sm ghost" data-a="closeSheet">Close</button></div>';
  h += '<div class="note">For issues already done on CUIMS outside the app. Type the Serial No(s) for each request (comma separated), or let the app find them for the whole day. Nothing is saved until you confirm.</div>';
  h += '<div class="card pad col" style="gap:10px"><b>Requests from these dates</b><div class="grid2"><label class="f">From<input type="date" data-lk="rFrom" value="' + esc(f.rFrom) + '"></label><label class="f">To<input type="date" data-lk="rTo" value="' + esc(f.rTo) + '"></label></div>' +
    '<div class="daychips">' + [['0', 'One day'], ['1', '2 days'], ['2', '3 days'], ['6', '7 days']].map(([k, l]) => '<button data-a="lkRspan" data-v="' + k + '" class="' + (String(Math.round((new Date(f.rTo) - new Date(f.rFrom)) / 864e5)) === k ? 'on' : '') + '">' + l + '</button>').join('') + '</div></div>';
  h += '<div class="card pad col" style="gap:10px"><b>Search CUIMS between</b><div class="grid2"><label class="f">From<input type="date" data-lk="cFrom" value="' + esc(f.cFrom) + '"></label><label class="f">To<input type="date" data-lk="cTo" value="' + esc(f.cTo) + '"></label></div>' +
    '<div class="daychips">' + [['same', 'Same as requests'], ['1', '+1 day gap'], ['2', '+2 days'], ['3', '+3 days']].map(([k, l]) => { const on = k === 'same' ? (f.cFrom === f.rFrom && f.cTo === f.rTo) : (f.cFrom === f.rFrom && f.cTo === addDays(f.rTo, +k)); return '<button data-a="lkCspan" data-v="' + k + '" class="' + (on ? 'on' : '') + '">' + l + '</button>'; }).join('') + '</div>' +
    '<div class="note">CUIMS Show Transactions will use From ' + usOf(f.cFrom) + ' To ' + usOf(f.cTo) + ' (' + (gap + 1) + ' day' + (gap ? 's' : '') + ').</div></div>';
  h += '<button class="btn ret full" data-a="lkAuto">Find serials automatically · ' + fmtShort(f.cFrom) + (f.cTo !== f.cFrom ? ' – ' + fmtShort(f.cTo) : '') + '</button>';
  if (!R.length) return h + '<div class="card pad note">No open requests on these dates.</div>';
  h += '<div class="card" style="overflow:hidden">' + R.map(r => '<div class="line" style="gap:6px"><div class="row"><span><span class="reqno sm" data-req="' + esc(r.req) + '">' + esc(r.req) + '</span> <b>' + esc(r.store) + '</b>' + (f.rFrom !== f.rTo ? ' <span class="note">' + fmtShort(r.date) + '</span>' : '') + '</span><span class="note">' + r.lines.filter(l => l.status === 'waiting').length + ' pending</span></div><input type="text" inputmode="numeric" data-lks="' + esc(r.req) + '" value="' + esc((f.map || {})[r.req] || '') + '" placeholder="Serial No(s), e.g. 21910, 21911" class="mono"></div>').join('') + '</div>';
  const n = Object.values(f.map || {}).join(',').split(/[^\d]+/).filter(x => /^\d{3,9}$/.test(x)).length;
  h += '<button class="btn main full" data-a="lkRead"' + (n ? '' : ' disabled') + '>Read ' + n + ' serial' + (n === 1 ? '' : 's') + ' on CUIMS</button>';
  return h;
}
async function startLink(auto) {
  const f = lkRange(ui.form); if (!N) { toast('Open this inside the JV Stock Issue app.'); return; }
  const map = {}, T = [], seen = new Set();
  if (!auto) Object.entries(f.map || {}).forEach(([req, txt]) => String(txt).split(/[^\d]+/).filter(x => /^\d{3,9}$/.test(x)).forEach(sn => { (map[req] = map[req] || []).push(sn); if (!seen.has(sn)) { seen.add(sn); T.push({ key: 's' + sn, serial: sn, slip: '', from: usOf(f.cFrom), to: usOf(f.cTo) }); } }));
  if (!auto && !T.length) { toast('Type at least one Serial No.'); return; }
  if (!(await uiConfirm(auto ? 'Find every CUIMS issue from ' + usOf(f.cFrom) + ' to ' + usOf(f.cTo) + ' and match it to your requests of ' + fmtShort(f.rFrom) + (f.rTo !== f.rFrom ? ' – ' + fmtShort(f.rTo) : '') + ' by store and articles? It only reads CUIMS.' : 'Read ' + T.length + ' serial' + (T.length > 1 ? 's' : '') + ' on CUIMS and match them to your requests? It only reads CUIMS.', 'Start'))) return;
  const known = S.entries.map(e => String(e.serial || '')).filter(Boolean);
  const job = { id: 'V' + Date.now(), kind: 'verify', phase: 'verify', slip: 'LINK', store: 'Link ' + fmtShort(f.date), title: (auto ? 'Find serials · ' : 'Link serials · ') + fmtShort(f.rFrom) + (f.rTo !== f.rFrom ? ' – ' + fmtShort(f.rTo) : ''), scope: { type: auto ? 'linkday' : 'link', id: f.rFrom, from: f.rFrom, to: f.rTo, map }, targets: T, idx: 0, res: {}, log: [], tries: {}, queue: false, autoSubmit: false, items: [] };
  if (auto) job.day = { us: usOf(f.cFrom), to: usOf(f.cTo), label: fmtShort(f.cFrom) + (f.cTo !== f.cFrom ? ' – ' + fmtShort(f.cTo) : '') };
  { const I = ignList(); job.ignore = { serials: Object.keys(I.serials).concat(known), people: Object.keys(I.people) }; }
  ui.sheet = null; renderSheet(); N.startJob(jobJson(job));
}
function buildLinkProposal(e) {
  const scope = e.scope || {}, res = e.res || {}, map = scope.map || {}, d = scope.id;
  const rf = scope.from || d, rt = scope.to || d;
  const reqs = requests().filter(r => (scope.type === 'link' ? Object.keys(map).includes(r.req) : r.date >= rf && r.date <= rt) && r.lines.some(l => l.status === 'waiting'));
  const txs = Object.entries(res).filter(([k, r]) => r.found && r.shown).map(([k, r]) => { const dt = cuDate((r.list || {}).entryDate);
    return { serial: (r.list || {}).serial || k.slice(1), slip: (r.shown.slip || (r.list || {}).slip || '').trim(), pa: r.shown.pa || '', rcv: (r.list || {}).rcv || r.shown.rcv || '', by: (r.list || {}).entryBy || '', iso: dt.iso, time: dt.time, isRet: !!(r.list || {}).isReturn || /return/i.test(r.shown.type || ''), items: (r.shown.items || []).map(i => ({ code: vNorm(i.code), qty: Number(i.qty), remark: i.remark || '', name: i.name || itemName(i.code) })) }; })
    .filter(t => !t.isRet && !S.entries.some(x => String(x.serial) === String(t.serial)));
  const notFound = Object.entries(res).filter(([k, r]) => !r.found).map(([k, r]) => r.serial || k.slice(1));
  const P = {}; reqs.forEach(r => { P[r.req] = { req: r.req, store: r.store, date: r.date, txs: [], on: true }; });
  txs.forEach(t => {
    let to = Object.keys(map).find(q => (map[q] || []).includes(String(t.serial)));
    if (!to) { let bestN = 0; reqs.forEach(r => { if (vNorm(r.store) !== vNorm(t.pa)) return; const w = new Set(r.lines.filter(l => l.status === 'waiting').map(l => vNorm(l.code))); const n = t.items.filter(i => w.has(i.code)).length; if (n > bestN) { bestN = n; to = r.req; } }); }
    if (to && P[to]) P[to].txs.push(t); else (P.__none = P.__none || { req: '', store: 'Not matched to a request', txs: [], on: false }).txs.push(t);
  });
  Object.values(P).forEach(p => { if (!p.req) return; const r = reqs.find(x => x.req === p.req); const W = r.lines.filter(l => l.status === 'waiting'); const used = {};
    p.rows = W.map(l => ({ lineId: l.id, code: vNorm(l.code), want: l.qty, got: 0, serials: [] }));
    p.extra = [];
    p.txs.sort((a, b) => (a.iso + a.time).localeCompare(b.iso + b.time)).forEach(t => t.items.forEach(i => { const row = p.rows.find(x => x.code === i.code && x.got < x.want + 1e-9 && !used[x.lineId + '|' + t.serial]);
      if (row) { row.got += i.qty; row.serials.push(t.serial); used[row.lineId + '|' + t.serial] = 1; } else p.extra.push(Object.assign({ serial: t.serial }, i)); }));
    if (!p.txs.length) p.on = false; });
  ui.link = { id: 'L' + Date.now(), date: d, props: Object.values(P), notFound };
  ui.view = 'linkReview'; render(); window.scrollTo(0, 0);
}
function vLinkReview() {
  const L = ui.link; if (!L) return '<main><div class="card pad note">Nothing to review.</div></main>';
  const props = L.props.filter(p => p.req), none = L.props.find(p => !p.req);
  let h = '<header class="top"><div><button class="btn sm ghost" data-a="back">‹ Back</button><h1 style="margin-top:10px">CUIMS serials found</h1><div class="sub">Check what was issued with which serial, then save. Nothing is saved until you tap Save.</div></div></header><main>';
  const nOn = props.filter(p => p.on && p.txs.length).length;
  h += '<div class="grid3"><div class="tile t-in"><b>' + props.filter(p => p.txs.length).length + '</b><span>Requests matched</span></div><div class="tile t-ok"><b>' + props.reduce((n, p) => n + p.txs.length, 0) + '</b><span>Serials</span></div><div class="tile t-pt"><b>' + props.filter(p => !p.txs.length).length + '</b><span>No serial found</span></div></div>';
  if (L.notFound.length) h += '<div class="banner" style="border:0;background:#FFE4EA;color:#8E1B3A">Not found on CUIMS: ' + esc(L.notFound.join(', ')) + '</div>';
  props.forEach((p, pi) => {
    const issued = (p.rows || []).filter(r => r.got > 0 && Math.abs(r.got - r.want) < 1e-6).length, part = (p.rows || []).filter(r => r.got > 0 && r.got < r.want - 1e-6).length, over = (p.rows || []).filter(r => r.got > r.want + 1e-6).length, left = (p.rows || []).filter(r => !r.got).length;
    h += '<div class="card pad col" style="gap:10px' + (p.on && p.txs.length ? ';box-shadow:inset 4px 0 0 #2F6FE0' : '') + '"><div class="row"><span><span class="reqno sm" data-req="' + esc(p.req) + '">' + esc(p.req) + '</span> <b>' + esc(p.store) + '</b></span>' + (p.txs.length ? '<label class="chk" style="min-height:0"><input type="checkbox" data-a="lkOn" data-v="' + pi + '"' + (p.on ? ' checked' : '') + '> Save</label>' : pill('No serial found', 'c-gd')) + '</div>';
    if (p.txs.length) {
      h += '<div class="slips" style="padding:0">' + p.txs.map(t => '<div class="slipline cu"><span class="stag cu">CUIMS</span><span class="sl">' + esc(t.slip || '–') + '</span>' + serFmt(t.serial) + '<span class="st">' + esc(fmtShort(t.iso)) + (t.time ? ' · ' + esc(t.time) : '') + ' · ' + esc(rcvLabel(t.rcv || '–')) + ' · ' + esc(String(t.by).split('(')[0].trim()) + (vNorm(t.pa) !== vNorm(p.store) ? ' · <b style="color:#B4123B">Project Area ' + esc(t.pa) + '</b>' : '') + '</span></div>').join('') + '</div>';
      h += '<div class="scrow">' + (issued ? '<span class="sc ok">' + issued + ' issued</span>' : '') + (part ? '<span class="sc gd">' + part + ' partly</span>' : '') + (over ? '<span class="sc no">' + over + ' more than asked</span>' : '') + (left ? '<span class="sc no">' + left + ' still pending</span>' : '') + (p.extra.length ? '<span class="sc no">' + p.extra.length + ' not in request</span>' : '') + '</div>';
      h += '<div class="tblwrap"><table><tr><th>Item</th><th>Asked</th><th>CUIMS</th><th>Serial</th><th>Result</th></tr>' + p.rows.map(r => '<tr><td><b>' + esc(itemName(r.code)) + '</b><div class="note mono">' + esc(r.code) + '</div></td><td>' + num(r.want) + '</td><td><b>' + (r.got ? num(r.got) : '–') + '</b></td><td class="mono">' + esc(r.serials.join(', ') || '–') + '</td><td>' + (!r.got ? '<span class="sc no">pending</span>' : r.got < r.want - 1e-6 ? '<span class="sc gd">' + num(r.want - r.got) + ' stays pending</span>' : r.got > r.want + 1e-6 ? '<span class="sc no">over by ' + num(r.got - r.want) + '</span>' : '<span class="sc ok">issued</span>') + '</td></tr>').join('') +
        p.extra.map(x => '<tr style="background:#FFF0F3"><td><b>' + esc(x.name || itemName(x.code)) + '</b><div class="note mono">' + esc(x.code) + '</div></td><td>–</td><td><b>' + num(x.qty) + '</b></td><td class="mono">' + esc(x.serial) + '</td><td><span class="sc no">not in request</span></td></tr>').join('') + '</table></div>';
    } else h += '<div class="note">Nothing on CUIMS was matched to this request. It stays pending.</div>';
    h += '</div>';
  });
  if (none && none.txs.length) h += '<div class="card pad col" style="gap:8px"><b>On CUIMS, not matched to a request (' + none.txs.length + ')</b>' + none.txs.map(t => '<div class="slipline cu"><span class="stag cu">CUIMS</span><span class="sl">' + esc(t.slip || '–') + '</span>' + serFmt(t.serial) + '<span class="st">' + esc(t.pa) + ' · ' + t.items.length + ' art. · ' + esc(String(t.by).split('(')[0].trim()) + '</span></div>').join('') + '<div class="note">Type these serials against the right request in Link CUIMS serials, or ignore them.</div></div>';
  h += '<button class="btn main full" data-a="lkSave"' + (nOn ? '' : ' disabled') + '>Save ' + nOn + ' request' + (nOn === 1 ? '' : 's') + ' with their serials</button>';
  return h + '</main>';
}
function vReportList() {
  let h = '<header class="top"><div><button class="btn sm ghost" data-a="back">‹ Back</button><h1 style="margin-top:10px">Verification reports</h1><div class="sub">Last 40 checks against CUIMS.</div></div></header><main>';
  h += '<button class="btn ret full" data-a="vfDayPick">Verify a whole day on CUIMS</button>';
  h += '<button class="btn full" data-a="lkOpen">Link CUIMS serials to requests</button>';
  { const I = ignList(), sk = Object.entries(I.serials), pk = Object.entries(I.people);
    h += '<div class="card" style="overflow:hidden"><button class="mgfh" data-a="ignTog"><b>Ignore list</b>' + pill((sk.length + pk.length + Object.keys(S.verifyIgnore || {}).length) + ' rules', 'c-gy') + ico(ui.ignOpen ? 'up' : 'down', 18) + '</button>';
    if (ui.ignOpen) { h += '<div class="pad col" style="gap:8px;padding-top:0"><div class="note">CUIMS entries on this list are never checked, reported or added to your data.</div>';
      h += sk.map(([k, v]) => '<div class="line" style="flex-direction:row;align-items:center;gap:10px;padding:10px 0"><span style="flex:1;min-width:0"><b>Serial ' + esc(k) + '</b><div class="meta"><span>' + esc([v.slip ? 'Slip ' + v.slip : '', v.store, v.by].filter(Boolean).join(' · ')) + '</span></div></span><button class="btn sm ghost" data-a="ignDel" data-v="s|' + esc(k) + '">Remove</button></div>').join('');
      h += pk.map(([k, v]) => '<div class="line" style="flex-direction:row;align-items:center;gap:10px;padding:10px 0"><span style="flex:1;min-width:0"><b>Everything entered by ' + esc(k) + '</b><div class="meta"><span>' + esc(v.name || '') + '</span></div></span><button class="btn sm ghost" data-a="ignDel" data-v="p|' + esc(k) + '">Remove</button></div>').join('');
      h += Object.entries(S.verifyIgnore || {}).map(([k, v]) => '<div class="line" style="flex-direction:row;align-items:center;gap:10px;padding:10px 0"><span style="flex:1;min-width:0"><b>Error ignored · ' + esc(v.label || '') + '</b><div class="meta"><span>' + esc(v.kind + (v.code ? ' · ' + v.code : '') + (v.note ? ' · ' + v.note : '')) + '</span></div></span><button class="btn sm ghost" data-a="ignDelE" data-v="' + esc(k) + '">Remove</button></div>').join('');
      h += '<div class="grid2"><button class="btn sm" data-a="ignAddS">+ Serial No</button><button class="btn sm" data-a="ignAddP">+ Person (GA code)</button></div></div>'; }
    h += '</div>'; }
  (S.verifyReports || []).forEach(r => { const bad = r.findings.filter(f => f.kind !== 'ok' && !f.fixed && !fIgnored(f) && !(f.kind === 'notInApp' && isIgnored(f.serial, f.entryBy))).length;
    h += '<button class="card pad tap col" style="gap:4px" data-a="vrOpen" data-v="' + r.id + '"><div class="row"><b>' + esc(r.title) + '</b>' + (bad ? pill(bad + ' to check', 'c-no') : pill('All good', 'c-ok')) + '</div><div class="note">' + esc(fmtDT(r.at)) + ' · ' + r.checked + ' serials</div></button>'; });
  if (!(S.verifyReports || []).length) h += '<div class="card pad note">No checks yet.</div>';
  return h + '</main>';
}
function verifyBadge(req) { const v = (S.verified || {})[req]; if (!v) return ''; return v.issues ? '<span class="vbadge bad">' + v.issues + ' to check</span>' : '<span class="vbadge">Verified ' + esc(fmtShort(isoOf(new Date(v.at)))) + '</span>'; }
function vCheck() {
  const I = dataIssues();
  let h = '<header class="top"><div><button class="btn sm ghost" data-a="back">‹ Back</button><h1 style="margin-top:10px">Data check</h1><div class="sub">Finds clashes and errors in your data, with a button to fix each one.</div></div></header><main>';
  if (!I.length) return h + '<div class="okbox">' + ico('right', 16).replace('M9 6l6 6-6 6', 'M5 12.5l4.5 4.5L19 7.5') + '<span>All clear. No clashes or errors found in ' + S.lines.length + ' articles and ' + S.entries.length + ' slips.</span></div></main>';
  h += '<div class="banner" style="background:#FFE4EA;color:#8E1B3A;border:0"><b>' + I.length + ' things to check.</b> Nothing changes until you tap a button.</div>';
  I.forEach(x => {
    if (x.kind === 'multi') h += '<div class="card pad col" style="gap:10px"><div class="row"><span class="reqno" data-req="' + esc(x.req) + '">' + esc(x.req) + '</span>' + pill('Used by ' + x.stores.length + ' stores', 'c-no') + '</div><div class="note">One Request No should belong to one store. Give the wrong one a new number.</div>' +
      x.stores.map(o => '<div class="row" style="align-items:center"><span><b>' + esc(o.st) + '</b><div class="meta"><span>' + o.n + ' articles</span>' + (o.issued ? '<i></i><span>has issued slips</span>' : '') + '</div></span><button class="btn sm" data-a="dcRenum" data-v="' + esc(x.req) + '" data-s="' + esc(o.st) + '">Renumber</button></div>').join('') + '</div>';
    if (x.kind === 'dupline') h += '<div class="card pad col" style="gap:10px"><div class="row"><span class="reqno" data-req="' + esc(x.req) + '">' + esc(x.req) + '</span>' + pill('Item twice', 'c-gd') + '</div><div><b>' + esc(itemName(x.code)) + '</b> <span class="mono note">' + esc(x.code) + '</span><div class="meta"><span>' + esc(x.store) + '</span><i></i><span>qty ' + x.qtys.map(num).join(' + ') + '</span></div></div><div class="grid2"><button class="btn sm" data-a="dcMerge" data-v="' + x.lines.join(',') + '">Merge into one (' + num(x.qtys.reduce((a, b) => a + b, 0)) + ')</button><button class="btn sm ghost" data-a="dcKeepFirst" data-v="' + x.lines.join(',') + '">Keep first only</button></div></div>';
    if (x.kind === 'dates') h += '<div class="card pad col" style="gap:10px"><div class="row"><span class="reqno" data-req="' + esc(x.req) + '">' + esc(x.req) + '</span>' + pill('Mixed dates', 'c-gd') + '</div><div class="note">Articles of this request have different dates: ' + x.dates.map(fmtShort).join(', ') + '.</div><div class="grid2"><button class="btn sm" data-a="dcDate" data-v="' + esc(x.req) + '" data-d="' + x.dates[0] + '">Use ' + fmtShort(x.dates[0]) + '</button><button class="btn sm ghost" data-a="dcDate" data-v="' + esc(x.req) + '" data-d="' + x.dates[x.dates.length - 1] + '">Use ' + fmtShort(x.dates[x.dates.length - 1]) + '</button></div></div>';
    if (x.kind === 'bad') h += '<div class="card pad col" style="gap:10px"><div class="row"><b>Incomplete articles</b>' + pill(x.n, 'c-no') + '</div><div class="note">Missing Request No, store, item code or qty.</div><button class="btn sm" data-a="dcBad" data-v="' + x.ids.join(',') + '">Remove ' + x.n + ' incomplete article' + (x.n > 1 ? 's' : '') + '</button></div>';
    if (x.kind === 'slip') h += '<div class="card pad col" style="gap:6px"><div class="row"><b>Slip ' + esc(x.slip) + ' used ' + x.n + ' times</b>' + pill('Check', 'c-no') + '</div><div class="note">' + esc(x.stores.join(', ')) + '. Edit the wrong one in Registers.</div><button class="btn sm ghost" data-a="dcSlip" data-v="' + esc(x.slip) + '">Show in Search</button></div>';
    if (x.kind === 'retdup') h += '<div class="card pad col" style="gap:8px"><div class="row"><b>Return No ' + esc(x.no) + ' used ' + x.ids.length + ' times</b>' + pill('Duplicate', 'c-no') + '</div><div class="note">' + esc(x.stores.join(', ')) + '</div><button class="btn sm" data-a="dcRetFix" data-v="' + x.ids.slice(1).join(',') + '">Give the extra ' + (x.ids.length - 1) + ' a new number</button></div>';
    if (x.kind === 'retfmt') h += '<div class="card pad col" style="gap:8px"><div class="row"><b>Old-style Return Nos</b>' + pill(x.n, 'c-gd') + '</div><div class="note mono">' + esc(x.nos.slice(0, 12).join(', ')) + (x.nos.length > 12 ? '…' : '') + '</div><div class="note">Renumber them to R-DDMM-NN by the date each return came.</div><button class="btn sm" data-a="dcRetFmt">Renumber all ' + x.n + '</button></div>';
    if (x.kind === 'nostock') h += '<div class="card pad col" style="gap:6px"><div class="row"><b>Items not in the stock sheet</b>' + pill(x.n, 'c-gd') + '</div><div class="note mono">' + esc(x.codes.slice(0, 20).join(', ')) + (x.codes.length > 20 ? '…' : '') + '</div><div class="note">Upload a fresh stock report, or correct the item code in the request.</div></div>';
  });
  return h + '</main>';
}
function renumberReq(from, to) {
  to = String(to || '').trim(); if (!to || to === from) return false;
  if (S.lines.some(l => l.req === to)) { toast('Request No ' + to + ' already exists.'); return false; }
  S.lines.forEach(l => { if (l.req === from) l.req = to; });
  S.entries.forEach(e => e.items.forEach(i => { if (i.req === from) i.req = to; }));
  if (ui.lastReq === from) ui.lastReq = to;
  return true;
}
const UNDO_KEYS = ['emp', 'counts', 'zeroWatch', 'lines', 'entries', 'returns', 'hold', 'corrections', 'audit', 'manReqs', 'paper', 'verifyReports'];
const UNDOABLE = { empDiscard: 'Cycle discarded', empFresh: 'Fresh round started', empDelP: 'Employee removed', eigDel: 'Rule removed', eigItemDel: 'Removed from rule', empPhotoDel: 'Photo removed', countDelOld: 'Old count deleted', cpRemove: 'Removed from count', cpRemoveAll: 'Removed from count', countClear: 'Count cycle cleared', zwDel: 'Removed from watch', zwBDel: 'Removed from watch', zwAddSave: 'Added to watch', artQty: 'Quantity changed', artHold: 'Hold changed', artDel: 'Article removed', artsBHold: 'Articles put on hold', artsBRel: 'Articles released', artsBDel: 'Articles removed', dropReq: 'Request removed', dropStore: 'Store pending removed',
  renumReq: 'Request renumbered', dcRenum: 'Request renumbered', impRenum: 'Request renumbered', impDrop: "App's request removed", corrSave: 'Correction saved', markSave: 'Slip added', dcMerge: 'Items merged', dcKeepFirst: 'Duplicate removed', dcDate: 'Date changed', dcBad: 'Incomplete removed',
  bulkSave: 'Requests edited', lkSave: 'CUIMS serials saved', vfFix: 'Fixed in app', dcRetFmt: 'Returns renumbered', dcRetFix: 'Return renumbered', clAdd: 'Count list changed', clDel: 'Count list changed', retBatchSave: 'Returns saved', stkEdit: 'Stock changed', stkRen: 'Item renamed', stkDel: 'Item deleted', stkAdd: 'Item added', mgDone: 'Requests completed', mgPend: 'Pending cleared', mgDel: 'Deleted', mgDelSlipPend: 'Slips deleted, articles pending again', delEntry: 'Entry deleted', delReturn: 'Return deleted', rsClose: 'Article closed', rsOpen: 'Article made pending', rsAll: 'Request completed', rsAdd: 'Article added', saveReq: 'Request edited', saveEntry: 'Entry saved', uploadOk: 'Import done', btSave: 'Batch saved', nrSave: 'Request added', hold: 'Hold changed' };
const UNDO_STOCK = new Set(['lkSave', 'vfFix', 'stkEdit', 'markSave', 'delEntry', 'saveEntry', 'uploadOk', 'mgDelSlipPend']);
let undoTimer = null;
function undoArm(a) { const snap = {}; UNDO_KEYS.concat(UNDO_STOCK.has(a) ? ['stock', 'stockAt', 'stockSrc'] : []).forEach(k => snap[k] = JSON.stringify(S[k] == null ? null : S[k])); ui.pendUndo = { a, label: UNDOABLE[a], snap, at: Date.now() }; }
function undoFire() { const u = ui.pendUndo; ui.pendUndo = null; if (!u || Date.now() - u.at > 120000) return; ui.undo = u; showUndo(); }
function showUndo() {
  let el = document.getElementById('undobar'); if (!el) { el = document.createElement('div'); el.id = 'undobar'; document.body.appendChild(el); }
  const u = ui.undo; if (!u) { el.innerHTML = ''; return; }
  let n = 5; const paint = () => { el.innerHTML = '<div class="undob"><span>' + esc(u.label) + '</span><button data-a="undoDo">Undo · ' + n + '</button></div>'; };
  ui.undoAt = Date.now(); paint(); clearInterval(undoTimer); undoTimer = setInterval(() => { n--; if (n <= 0 || ui.undo !== u) { clearInterval(undoTimer); if (ui.undo === u) { ui.undo = null; el.innerHTML = ''; } return; } paint(); }, 1000);
}
window.jvSaved = (name, mime) => {
  let el = document.getElementById('dlg'); if (!el) { el = document.createElement('div'); el.id = 'dlg'; document.body.appendChild(el); }
  const pdf = /pdf/i.test(mime || name), xl = /sheet|excel|xls/i.test(mime || name);
  el.innerHTML = '<div class="pkbg" data-sv="close"></div><div class="dlgbox savedbox" role="dialog" aria-modal="true"><div class="svhead"><span class="svic ' + (pdf ? 'pdf' : xl ? 'xls' : '') + '">' + (pdf ? 'PDF' : xl ? 'XLS' : 'FILE') + '</span><span><b>Saved</b><span>Downloads / JV Stock Issue</span></span></div>' +
    '<div class="svname">' + esc(name) + '</div><div class="grid3"><button class="btn" data-sv="share">Share</button><button class="btn" data-sv="close">Close</button><button class="btn main" data-sv="open">Open</button></div></div>';
  el.querySelectorAll('[data-sv]').forEach(b => b.onclick = e => { e.stopPropagation(); const k = b.dataset.sv; el.innerHTML = ''; if (k === 'open' && N && N.openLastFile) N.openLastFile(); if (k === 'share' && N && N.shareLastFile) N.shareLastFile(); });
};
function flashReq(req) {
  document.querySelectorAll('.sel,.selrow').forEach(x => x.classList.remove('sel', 'selrow'));
  document.querySelectorAll('[data-req="' + CSS.escape(req) + '"]').forEach(x => {
    const c = x.closest('.art,.leftrow,.line,.rcard,.card'); if (!c) return;
    const cls = c.classList.contains('rcard') || (c.classList.contains('card') && !c.classList.contains('line')) ? 'sel' : 'selrow';
    if (cls === 'sel') c.classList.add('rcard');
    void c.offsetWidth; c.classList.add(cls);
  });
}
function uiConfirm(msg, okLabel, danger) {
  loader(false);
  return new Promise(res => {
    let el = document.getElementById('dlg'); if (!el) { el = document.createElement('div'); el.id = 'dlg'; document.body.appendChild(el); }
    el.innerHTML = '<div class="pkbg"></div><div class="dlgbox" role="dialog" aria-modal="true"><div class="dlgic' + (danger ? ' no' : '') + '">' + ico('alert', 26) + '</div><div class="dlgmsg">' + esc(msg) + '</div><div class="grid2"><button class="btn" data-dlg="0">Cancel</button><button class="btn main' + (danger ? ' danger' : '') + '" data-dlg="1">' + esc(okLabel || 'OK') + '</button></div></div>';
    el.querySelectorAll('[data-dlg]').forEach(b => b.onclick = e => { e.stopPropagation(); el.innerHTML = ''; res(b.dataset.dlg === '1'); });
  });
}
function curFY() { const d = new Date(), y = d.getFullYear(); return d.getMonth() >= 3 ? y + '-' + (y + 1) : (y - 1) + '-' + y; }
function autoStockCfg() { S.autoStock = Object.assign({ on: true, store: 'Ration Store', fy: '' }, S.autoStock || {}); return S.autoStock; }
function openLiveStock() {
  const c = autoStockCfg();
  if (c.on && N && N.openMgrAuto) { N.openMgrAuto(JSON.stringify({ run: Date.now(), store: c.store || 'Ration Store', fy: c.fy || curFY() })); return; }
  if (N && N.openMgr) N.openMgr(); else toast('Update the app (Settings > App and updates) to use Manager CUIMS.');
}
window.jvStockFile = (b64, name) => { loader(true, 'Reading the stock file'); let n = 0; const go = () => { if (!window.XLSX && n++ < 40) { setTimeout(go, 500); return; } try { jvStockFile2(b64, name); } finally { loader(false); } }; setTimeout(go, 60); };
function jvStockFile2(b64, name) {
  try {
    if (!window.XLSX) { toast('Excel tools not loaded yet. Check internet and try again.'); return; }
    const wb = XLSX.read(b64, { type: 'base64', cellDates: false });
    ui.view = null; ui.tab = 'home';
    ui.upload = { kind: 'stock', wb, auto: true, name: name || 'Live stock' };
    ui.upload.result = parseStock(wb);
    if (ui.upload.result.error) ui.upload.error = ui.upload.result.error;
    ui.sheet = { kind: 'upload' }; render(); renderSheet();
    
  } catch (e) { toast('Could not read the downloaded stock file: ' + e.message); }
}
function rcvBook() {
  const m = {}; const put = (c, n) => { c = normRcv(c); n = String(n || '').trim(); if (c && n && !/^(GA|E)\d+$/i.test(n)) m[c] = n; };
  Object.values(S.stores || {}).forEach(x => put(x.rcv, x.rname));
  (S.entries || []).forEach(e => put(e.rcv, e.rname)); (S.returns || []).forEach(r => put(r.by, r.byName));
  Object.values(S.manReqs || {}).forEach(x => put(x.rcv, x.rname));
  Object.entries(S.rnames || {}).forEach(([c, n]) => put(c, n));
  return m;
}
function rcvName(code) { const k = normRcv(code); return (S.cuimsNames || {})[k] || rcvBook()[k] || ''; }
const RCV_SEL = 'input[data-rb$="|by"],input[data-in="rcv"],input[data-nr="rcv"],input[data-mr="rcv"],input[data-f="rcv"],input[data-store-rcv],input[data-bg$="|rcv"],input[data-br$="|rcv"],input[data-ef="rcv"],input[data-rf="by"]';
function rcvHint(inp) {
  if (!inp.dataset.rcvx) { inp.dataset.rcvx = '1'; inp.setAttribute('inputmode', 'text'); inp.setAttribute('maxlength', '8'); inp.setAttribute('autocapitalize', 'characters'); inp.setAttribute('placeholder', inp.getAttribute('placeholder') || 'e.g. 601051 or E1234'); }
  let h = inp.parentNode.querySelector('.rcvname'); if (!h) { h = document.createElement('span'); h.className = 'rcvname'; inp.insertAdjacentElement('afterend', h); }
  const raw = String(inp.value || '').trim(); if (!raw) { h.textContent = ''; h.className = 'rcvname'; return; }
  const n = normRcv(raw);
  if (!n) { h.className = 'rcvname new'; h.innerHTML = 'Type 6 digits for GA, or up to 5 digits for an E code'; return; }
  const nm = rcvName(n), ver = (S.cuimsNames || {})[n];
  h.className = 'rcvname ' + (nm ? 'ok' : 'new');
  h.innerHTML = '<span class="ckind ' + (/^E/.test(n) ? 'e' : 'ga') + '">' + rcvKind(n) + '</span> <b>' + esc(rcvLabel(n)) + '</b> · ' + (nm ? esc(nm) + (ver ? ' <span class="cver">✓ CUIMS</span>' : '') : 'name not known yet') + ' <button type="button" class="ckbtn" data-a="nameLookup" data-v="' + esc(n) + '">' + (ver ? 'Recheck on CUIMS' : 'Check on CUIMS') + '</button>';
  const mr = document.querySelector('input[data-mr="rname"]'); if (nm && mr && !mr.value && ui.form) { mr.value = nm; ui.form.rname = nm; }
}
function enhanceRcv(root) { if (root) root.querySelectorAll(RCV_SEL).forEach(rcvHint); }
document.addEventListener('input', e => { if (e.target.matches && e.target.matches(RCV_SEL)) rcvHint(e.target); }, true);
function enhanceDates(root) {
  (root || document).querySelectorAll('input[type="date"]').forEach(inp => {
    const b = document.createElement('button'); b.type = 'button'; b.className = 'datebtn'; b.dataset.dp = '1';
    const paint = () => { b.innerHTML = '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><rect x="3" y="5" width="18" height="16" rx="3"/><path d="M3 10h18M8 3v4M16 3v4"/></svg><span>' + (inp.value ? fmtLong(inp.value) : 'Choose date') + '</span>'; b.classList.toggle('empty', !inp.value); };
    inp.type = 'hidden'; inp.parentNode.insertBefore(b, inp); paint();
    b.onclick = e => { e.preventDefault(); e.stopPropagation(); openCal(inp, paint); };
  });
}
function openCal(inp, paint) {
  let el = document.getElementById('cal'); if (!el) { el = document.createElement('div'); el.id = 'cal'; document.body.appendChild(el); }
  const sel = inp.value || '', base = sel ? new Date(sel + 'T12:00') : new Date();
  let y = base.getFullYear(), m = base.getMonth();
  const draw = () => {
    const first = new Date(y, m, 1, 12), start = (first.getDay() + 6) % 7, dim = new Date(y, m + 1, 0).getDate();
    let cells = ''; for (let i = 0; i < start; i++) cells += '<span></span>';
    for (let d = 1; d <= dim; d++) { const iso = y + '-' + pad(m + 1) + '-' + pad(d); cells += '<button class="cd' + (iso === sel ? ' on' : '') + (iso === today() ? ' td' : '') + '" data-cd="' + iso + '">' + d + '</button>'; }
    el.innerHTML = '<div class="pkbg" data-cx="1"></div><div class="calbox" role="dialog" aria-label="Choose date"><div class="calhead"><button class="xbtn" data-cm="-1" aria-label="Previous month">' + ico('up', 18).replace('M6 15l6-6 6 6', 'M15 6l-6 6 6 6') + '</button><b>' + new Date(y, m, 1).toLocaleString('en-GB', { month: 'long', year: 'numeric' }) + '</b><button class="xbtn" data-cm="1" aria-label="Next month">' + ico('right', 18) + '</button></div>' +
      '<div class="calgrid wk">' + ['Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa', 'Su'].map(w => '<span>' + w + '</span>').join('') + '</div><div class="calgrid">' + cells + '</div>' +
      '<div class="grid3"><button class="btn" data-cq="clear">Clear</button><button class="btn" data-cq="today">Today</button><button class="btn main" data-cx="1">Close</button></div></div>';
  };
  const done = v => { inp.value = v; paint(); el.innerHTML = ''; inp.dispatchEvent(new Event('input', { bubbles: true })); inp.dispatchEvent(new Event('change', { bubbles: true })); };
  el.onclick = e => { const t = e.target.closest('[data-cd],[data-cm],[data-cq],[data-cx]'); if (!t) return; e.stopPropagation();
    if (t.dataset.cd) done(t.dataset.cd); else if (t.dataset.cm) { m += +t.dataset.cm; if (m < 0) { m = 11; y--; } if (m > 11) { m = 0; y++; } draw(); }
    else if (t.dataset.cq === 'today') done(today()); else if (t.dataset.cq === 'clear') done(''); else el.innerHTML = ''; };
  draw();
}
function renderPicker() {
  let el = document.getElementById('picker'); if (!el) { el = document.createElement('div'); el.id = 'picker'; document.body.appendChild(el); }
  const p = ui.picker; if (!p) { el.innerHTML = ''; return; }
  const cfg = PICKS[p.id]; if (!cfg) { el.innerHTML = ''; return; }
  const search = cfg.search || cfg.opts.length > 8;
  el.innerHTML = '<div class="pkbg" data-a="pickClose"></div><div class="pkpanel" role="dialog" aria-label="' + esc(cfg.title) + '"><div class="pkhead"><b>' + esc(cfg.title) + '</b><button class="xbtn" data-a="pickClose" aria-label="Close">' + ico('x', 18) + '</button></div>' +
    (search ? '<div style="padding:0 16px 8px"><input type="text" data-pkq="1" value="' + esc(p.q || '') + '" placeholder="Search" autocomplete="off"></div>' : '') +
    '<div class="pklist">' + pickList() + '</div></div>';
}
function pickList() {
  const p = ui.picker, cfg = PICKS[p.id]; const q = String(p.q || '').toUpperCase();
  const list = cfg.opts.filter(o => !q || String(o[1]).toUpperCase().includes(q) || String(o[0]).toUpperCase().includes(q));
  return (list.length ? list.map(o => '<button class="pkitem' + (o[0] === cfg.val ? ' on' : '') + '" data-a="pickSet" data-v="' + esc(o[0]) + '"><span>' + esc(o[1]) + (o[2] ? '<small>' + esc(o[2]) + '</small>' : '') + '</span>' + (o[0] === cfg.val ? '<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12.5l4.5 4.5L19 7.5"/></svg>' : '') + '</button>').join('') : '<div class="note" style="padding:14px 18px">No match.</div>');
}
function sortSel(k, opts) { return '<select data-sort="' + k + '" style="width:auto;min-height:38px;font-size:14px;padding:0 8px">' + opts.map(([v, l]) => '<option value="' + v + '"' + (ui.sort[k] === v ? ' selected' : '') + '>Sort: ' + l + '</option>').join('') + '</select>'; }
function storeRank(st) { const o = S.storeOrder || []; const i = o.indexOf(st); return i < 0 ? 9999 : i; }
function byStore(a, b) { return storeRank(a) - storeRank(b) || a.localeCompare(b); }
function oldestOf(L) { return L.reduce((m, l) => l.date < m ? l.date : m, '9999'); }
function bulkList() {
  const PL = plan();
  return requests().map(r => Object.assign(r, reqState(r, PL))).filter(r => r.w.length).sort((a, b) => a.date.localeCompare(b.date) || a.req.localeCompare(b.req, undefined, { numeric: true }));
}
function shBulk() {
  const f = ui.form;
  let h = '<div class="row"><h2>Edit all requests</h2><button class="btn sm ghost" data-a="closeSheet">Close</button></div>';
  h += '<div class="note">Set Slip No, date and receiver for every open request at once. Slip No is used for the next entry of that request.</div>';
  h += '<div class="card pad col"><b>Same date for all</b><div class="grid2"><input type="date" data-bulkdate="1" value="' + esc(f.allDate || today()) + '"><button class="btn" data-a="bulkDate">Apply to all</button></div></div>';
  h += '<div class="card pad col"><b>Auto-number Slip Nos</b><div class="grid2"><input type="text" data-bulkstart="1" value="' + esc(f.start) + '" class="mono" placeholder="First slip, e.g. JV/920" autocapitalize="characters"><button class="btn" data-a="bulkAuto">Fill in order</button></div><div class="note">Fills empty Slip boxes below, top to bottom, counting up.</div></div>';
  f.rows.forEach((r, i) => {
    h += '<div class="card pad col" style="gap:8px"><div class="row"><b>' + esc(r.store) + '</b><span class="note">Request ' + esc(r.req) + ' · ' + r.n + ' open</span></div>' +
      '<div class="grid2"><label class="f">Slip No<input type="text" data-br="' + i + '|slip" value="' + esc(r.slip) + '" class="mono" autocapitalize="characters"></label><label class="f">Request No<input type="text" data-br="' + i + '|newReq" value="' + esc(r.newReq) + '" class="mono"></label></div>' +
      '<div class="grid2"><label class="f">Request date<input type="date" data-br="' + i + '|date" value="' + esc(r.date) + '"></label><label class="f">Receiver (GA or E code)<input type="text" data-br="' + i + '|rcv" value="' + esc(r.rcv) + '" class="mono" inputmode="numeric" maxlength="6"></label></div></div>';
  });
  h += '<button class="btn main full" data-a="bulkSave">Save all</button>';
  return h;
}
function shMark() {
  const f = ui.form;
  let h = '<div class="row"><h2>Mark as issued</h2><button class="btn sm ghost" data-a="closeSheet">Close</button></div>';
  h += '<div class="note">Use this when the entry is already submitted on CUIMS but the app did not record it. Stock and pending update like a normal entry.</div>';
  h += '<div class="grid2"><label class="f">Slip No<input type="text" data-f="slip" value="' + esc(f.slip) + '" class="mono" autocapitalize="characters"></label><label class="f">Serial No<input type="text" data-f="serial" value="' + esc(f.serial) + '" class="mono" inputmode="numeric"></label></div>';
  h += '<div class="grid2"><label class="f">Receiver (GA or E code)<input type="text" data-f="rcv" value="' + esc(f.rcv) + '" class="mono" inputmode="numeric" maxlength="6"></label><label class="f">Date<input type="date" data-f="date" value="' + esc(f.date) + '"></label></div>';
  h += '<div class="sect">Articles in this entry</div><div class="card">' + f.lines.map(l => '<label class="line chk" style="flex-direction:row;gap:10px"><input type="checkbox" data-a="markPick" data-v="' + l.id + '"' + (f.pick[l.id] ? ' checked' : '') + '><span><b>' + esc(itemName(l.code)) + '</b><br><span class="note mono">' + esc(l.code) + ' · ' + num(l.qty) + ' ' + esc(itemUom(l.code)) + '</span></span></label>').join('') + '</div>';
  h += '<button class="btn main full" data-a="markSave">Save as issued</button>';
  return h;
}
function shEditReq() {
  const f = ui.form;
  let h = '<div class="row"><h2>Edit request ' + esc(f.req) + '</h2><button class="btn sm ghost" data-a="closeSheet">Close</button></div><div class="note">Only waiting articles can be changed. Issued ones stay as recorded.</div>';
  h += '<label class="f">Store<input type="text" data-f="store" list="areaList" value="' + esc(f.store) + '" autocapitalize="characters"></label>' + areaDatalist();
  h += '<div class="grid2"><label class="f">Request date<input type="date" data-f="date" value="' + esc(f.date) + '"></label><label class="f">Receiver for this request<input type="text" data-f="rcv" value="' + esc(f.rcv) + '" class="mono" inputmode="numeric" maxlength="6"></label></div>';
  h += '<label class="f">Slip No for the next entry<input type="text" data-f="slip" value="' + esc(f.slip || '') + '" class="mono" autocapitalize="characters" placeholder="optional"></label>';
  h += '<label class="f">Custom remark (optional)<input type="text" data-f="remark" value="' + esc(f.remark || '') + '" placeholder="Replaces Requisition Requested on …"></label>';
  h += '<div class="sect">Waiting articles</div>' + itemRowsHtml(f.items, true) + '<button class="btn ghost" data-a="addItem">+ Add article</button>';
  h += '<button class="btn main full" data-a="saveReq">Save request</button>';
  return h;
}

/* ---------------- lock ---------------- */
const GUARDED = new Set(['nameLookup', 'lkSave', 'vfIgnF', 'vfUnIgn', 'ignDelE', 'vfIgn', 'vfIgnP', 'ignDel', 'ignAddS', 'ignAddP', 'vfFix', 'retStartAll', 'dcRetFmt', 'dcRetFix', 'clClear', 'retCuims', 'saveReturnCuims', 'rbSave', 'stkEdit', 'stkRen', 'stkDel', 'stkAdd', 'mgDone', 'mgPend', 'mgDel', 'mgDelSlipPend', 'paperAddFrom', 'advIssue', 'paperAdd', 'mrSave', 'mrRemove', 'manReqToggle', 'msSave', 'artQty', 'artHold', 'artDel', 'artsBHold', 'artsBRel', 'artsBDel', 'testToggle', 'testClear', 'dcRenum', 'dcMerge', 'dcKeepFirst', 'dcDate', 'dcBad', 'renumReq', 'impRenum', 'impDrop', 'credSave', 'credDel', 'corrOpen', 'corrSave', 'bulkEdit', 'bulkSave', 'dropReq', 'dropStore', 'editReq', 'saveReq', 'markDone', 'markSave', 'newManual', 'saveEntry', 'delEntry', 'newReturn', 'saveReturn', 'delReturn',
  'rmStore', 'addStore', 'wipe', 'restore', 'bkRestore', 'bkDel', 'bkKeep', 'bkSave', 'bkNoteSave', 'photo', 'photoDel', 'mode', 'lockToggle', 'syncAuto', 'mgrToggle', 'moveStore', 'saveUrls', 'resetZoom', 'hold', 'cropSave']);
let pendingAuth = null;
function askUnlock(after) {
  pendingAuth = after || null;
  if (N && N.authenticate) N.authenticate(); else uiConfirm('Unlock editing?').then(ok => window.jvAuth(ok));
}
window.jvAuth = ok => { if (ok) { ui.locked = false; render(); renderSheet(); const f = pendingAuth; pendingAuth = null; if (f) f(); } else toast('Still locked.'); };
window.jvRelock = () => { if (!ui.locked) { ui.locked = true; render(); renderSheet(); } };

/* ---------------- actions ---------------- */
const later = fn => setTimeout(fn, 0);
function focusKey(el) { if (!el) return null; for (const a of ['data-in', 'data-f', 'data-it', 'data-set', 'data-store-rcv', 'data-store-name', 'data-nr', 'data-bt', 'data-cnt', 'data-var']) if (el.hasAttribute && el.hasAttribute(a)) return [a, el.getAttribute(a), el.selectionStart]; return null; }
function refocus(k) { if (!k) return; const el = document.querySelector('[' + k[0] + '="' + CSS.escape(k[1]) + '"]'); if (el) { el.focus(); try { if (k[2] != null) el.setSelectionRange(k[2], k[2]); else if (el.type === 'number') { const v = el.value; el.value = ''; el.value = v; } } catch (e) {} } }
function blankItem() { return { code: '', name: '', uom: '', qty: '', remark: '' }; }
function fillItemMeta(it) { it.code = String(it.code || '').trim().toUpperCase(); if (S.stock[it.code]) { it.name = S.stock[it.code].name; it.uom = S.stock[it.code].uom; } else { const f = findItemAnywhere(it.code); if (f) { it.name = f.name; it.uom = f.uom; } } }
function cleanItems(items) { return items.map(i => { fillItemMeta(i); return { code: i.code, name: i.name || '', uom: i.uom || '', qty: parseFloat(i.qty), remark: (i.remark || '').trim(), req: i.req || '', lineId: i.lineId }; }).filter(i => i.code && i.qty > 0); }

document.addEventListener('keydown', ev => {
  if (ev.key !== 'Enter') return;
  const el = ev.target;
  if (el.dataset && el.dataset.bt === 'q') { ev.preventDefault(); const f = document.querySelector('#bthits .hit'); if (f) f.click(); }
  else if (el.dataset && el.dataset.bq) { ev.preventDefault(); const [gi, ii] = el.dataset.bq.split('|'); ui.form.groups[+gi].items[+ii].qty = el.value; renderSheet(); const i = document.querySelector('[data-bt="q"]'); if (i) { i.focus(); i.scrollIntoView({ block: 'center' }); } }
  else if (el.dataset && el.dataset.nr === 'q') { ev.preventDefault(); const f = document.querySelector('[data-a=nrPick]'); if (f) f.click(); }
});
document.addEventListener('click', ev => {
  const q = ev.target.closest && ev.target.closest('[data-req]');
  if (q && q.dataset.req && q.dataset.req !== '–') { ev.preventDefault(); ev.stopPropagation(); ev.stopImmediatePropagation(); ui.lastReq = q.dataset.req; flashReq(ui.lastReq); return; }
}, true);
document.addEventListener('click', async ev => {
  const t = ev.target.closest('[data-a]'); if (!t) return;
  const a = t.dataset.a, v = t.dataset.v;
  if (a === 'undoDo') { const u = ui.undo; if (!u) return; Object.entries(u.snap).forEach(([k, j]) => { S[k] = JSON.parse(j); }); ui.undo = null; clearInterval(undoTimer); showUndo(); ui.pendUndo = null; save(true); render(); renderSheet(); toast('Undone: ' + u.label + '.'); return; }
  if (UNDOABLE[a] && !(ui.locked && GUARDED.has(a))) undoArm(a); else if (!/^(pick|pickSet|pickClose|tab|back)$/.test(a)) ui.pendUndo = null;
  if (a === 'lockTap') { if (ui.locked) askUnlock(); else { ui.locked = true; render(); renderSheet(); } return; }
  if (ui.locked && GUARDED.has(a)) { ev.preventDefault(); if (t.type === 'checkbox') t.checked = !t.checked; const sel = '[data-a="' + a + '"]' + (v != null ? '[data-v="' + CSS.escape(v) + '"]' : ''); askUnlock(() => { const el = document.querySelector(sel); if (el) el.click(); }); return; }
  if (a === 'bgClose') { if (ev.target === t) { ui.sheet = null; renderSheet(); } return; }
  if (t.type === 'checkbox' && !['hold', 'pdfSignAll', 'queueToggle', 'regItems', 'mgrToggle', 'syncAuto', 'lockToggle', 'markPick', 'stOn', 'rpTog', 'rpCol', 'autoSubToggle', 'queuePend', 'credAuto', 'artsSel', 'artsAll', 'artsGrp', 'autoStockTog', 'mgSel', 'mgAll', 'lkOn', 'sdAddNew', 'artsCatOn', 'artsCatSel', 'funToggle'].includes(a)) return;
  const _busy = BUSY[a];
  if (_busy && !(ui.locked && GUARDED.has(a))) { loader(true, _busy); await new Promise(r => setTimeout(r, 40)); }
  try {
  switch (a) {
    case 'tab': ui.tab = v; ui.view = null; if (v === 'set') ui.setPage = null; render(); window.scrollTo(0, 0); break;
    case 'openSite': if (N) N.openSite(); else toast('Open this inside the app.'); break;
    case 'goUpdate': ui.tab = 'set'; ui.view = null; render(); setTimeout(() => { const u = document.getElementById('upd'); if (u) u.scrollIntoView(); }, 50); break;
    case 'upload': ui.upload = null; ui.sheet = { kind: 'upload' }; renderSheet(); break;
    case 'template': template(); break;
    case 'openReq': { if (ui.view !== 'req') { const ids = []; document.querySelectorAll('[data-a="openReq"][data-v]').forEach(x => { if (!ids.includes(x.dataset.v)) ids.push(x.dataset.v); }); ui.reqList = ids.length > 1 ? ids : null; }
      ui.lastReq = v; ui.view = 'req'; ui.req = v; render(); window.scrollTo(0, 0); break; }
    case 'reqGo': goReq(+v); break;
    case 'funToggle': S.funMode = t.checked; save(true); toast('Kitty mode ' + (S.funMode ? 'on' : 'off') + '.'); break;
    case 'sdMode': ui.upload.stockMode = v; renderSheet(); break;
    case 'sdLink': ui.upload.linkBy = v; ui.upload.diff = stockDiff(ui.upload.result.stock, v); renderSheet(); break;
    case 'sdAddNew': ui.upload.addNew = t.checked; renderSheet(); break;
    case 'sdTog': ui.sdOpen = ui.sdOpen || {}; ui.sdOpen[v] = !ui.sdOpen[v]; renderSheet(); break;
    case 'verReq': startVerify({ type: 'req', id: v }); break;
    case 'verRet': startVerify({ type: 'ret', id: v }); break;
    case 'verDay': startVerify({ type: 'day', id: v || today() }); break;
    case 'vfDayPick': { const d = await uiPrompt('Which day? (YYYY-MM-DD)', today(), 'Verify'); if (d && /^\d{4}-\d{2}-\d{2}$/.test(d)) startVerify({ type: 'day', id: d }); break; }
    case 'vrOpen': ui.vrep = v; ui.view = 'vreport'; render(); window.scrollTo(0, 0); break;
    case 'vrList': ui.drawer = false; ui.view = 'vreports'; render(); window.scrollTo(0, 0); break;
    case 'vrExport': openExport('verify'); break;
    case 'vrExportItems': openExport('verifyItems'); break;
    case 'vfFix': { const [rid, fid] = v.split('|'); const R = (S.verifyReports || []).find(r => r.id === rid); const f = R && R.findings.find(x => x.id === fid); if (!f || f.fixed) break;
      const en = S.entries.find(x => 'e' + x.id === f.key);
      const q = { serial: 'Save Serial ' + f.val + ' on slip ' + (en ? en.slip : '') + '?', qty: 'Change ' + itemName(f.code) + ' from ' + num(f.app) + ' to ' + num(f.cuims) + ' in the app?', missing: 'Remove ' + itemName(f.code) + ' from this slip in the app and make it pending again?', extra: 'Add ' + itemName(f.code) + ' ' + num(f.qty) + ' to this slip in the app as issued?', store: 'Change the store in the app to ' + f.cuims + '?', rcv: 'Change the receiver in the app to ' + rcvLabel(f.cuims) + '?', notInApp: 'Add Serial ' + f.serial + ' to the app as a manual ' + (f.isReturn ? 'return' : 'slip') + '?' }[f.kind];
      if (!q || !(await uiConfirm(q, 'Fix in app'))) break;
      undoArm('vfFix');
      if (f.kind === 'serial' && en) { en.serial = f.val; S.lines.forEach(l => (l.issued || []).forEach(z => { if (z.slip === en.slip && !z.serial) z.serial = f.val; })); }
      if (f.kind === 'qty' && en) { en.items.forEach(i => { if (vNorm(i.code) === f.code) i.qty = f.cuims; }); const l = S.lines.find(x => x.id === f.lineId); if (l) l.qty = f.cuims; }
      if (f.kind === 'missing' && en) { en.items = en.items.filter(i => vNorm(i.code) !== f.code); const l = S.lines.find(x => x.id === f.lineId); if (l) { l.issued = (l.issued || []).filter(z => z.slip !== en.slip); if (!l.issued.length) l.status = 'waiting'; } }
      if (f.kind === 'extra' && en) { const req = (en.items[0] || {}).req || ''; const l = S.lines.find(x => x.req === req && vNorm(x.code) === f.code && x.status === 'waiting');
        if (l) { l.status = 'issued'; l.issued.push({ slip: en.slip, serial: en.serial || '', at: en.at }); }
        en.items.push({ lineId: l ? l.id : 0, req, code: f.code, name: itemName(f.code), uom: itemUom(f.code), qty: f.qty, remark: '' }); }
      if (f.kind === 'store' && en) en.store = f.cuims;
      if (f.kind === 'rcv' && !validRcv(String(f.cuims || ''))) { toast('CUIMS code is not readable, nothing changed.'); break; }
      if (f.kind === 'rcv' && en) en.rcv = f.cuims;
      if (f.kind === 'rcv' && f.ret) { const rt = S.returns.find(x => 'r' + x.id === f.key); if (rt) { rt.by = f.cuims; rt.byName = rcvName(f.cuims); } }
      if (f.kind === 'notInApp') { const d = (String(f.date || '').match(/(\d+)\/(\d+)\/(\d{4})/) || []); const iso = d.length ? d[3] + '-' + String(d[1]).padStart(2, '0') + '-' + String(d[2]).padStart(2, '0') : today();
        if (f.isReturn) S.returns.push({ id: nid(), no: nextReturnNo(iso), against: '1111', store: String(f.store || '').toUpperCase(), by: f.rcv || '', byName: rcvName(f.rcv), date: iso, recvDate: iso, time: '', serial: f.serial, remarks: 'added from CUIMS check', enteredBy: { name: f.entryBy || '' }, items: (f.items || []).map(i => ({ code: i.code, name: itemName(i.code), uom: itemUom(i.code), qty: Number(i.qty), remark: i.remark || '' })) });
        else S.entries.push({ id: nid(), slip: f.slip || ('CUIMS-' + f.serial), serial: f.serial, store: String(f.store || '').toUpperCase(), rcv: f.rcv || '', rname: rcvName(f.rcv), at: new Date(iso + 'T12:00').toISOString(), date: iso, time: '', by: { name: f.entryBy || '' }, kind: 'manual', remarks: 'added from CUIMS check', items: (f.items || []).map(i => ({ lineId: 0, req: '', code: i.code, name: itemName(i.code), uom: itemUom(i.code), qty: Number(i.qty), remark: i.remark || '' })) }); }
      f.fixed = true; save(); render(); break; }
    case 'lkOpen': ui.drawer = false; ui.form = lkRange({ rFrom: v || ui.homeDate || today(), map: {} }); ui.sheet = { kind: 'link' }; renderSheet(); break;
    case 'lkAuto': startLink(true); break;
    case 'lkRspan': { const f = lkRange(ui.form); const keepGap = Math.round((new Date(f.cTo) - new Date(f.rTo)) / 864e5); f.rTo = addDays(f.rFrom, +v); f.cFrom = f.rFrom; f.cTo = addDays(f.rTo, Math.max(0, keepGap)); f.map = {}; renderSheet(); break; }
    case 'lkCspan': { const f = lkRange(ui.form); f.cFrom = f.rFrom; f.cTo = v === 'same' ? f.rTo : addDays(f.rTo, +v); renderSheet(); break; }
    case 'lkRead': startLink(false); break;
    case 'lkOn': ui.link.props.filter(p => p.req)[+v].on = t.checked; render(); break;
    case 'lkSave': { const L = ui.link, P = L.props.filter(p => p.req && p.on && p.txs.length); if (!P.length) break;
      if (!(await uiConfirm('Save ' + P.length + ' request' + (P.length > 1 ? 's' : '') + ' with ' + P.reduce((n, p) => n + p.txs.length, 0) + ' CUIMS serials? Matched articles become issued, the rest stays pending. Stock is reduced the same way as a normal entry.', 'Save'))) break;
      undoArm('lkSave');
      P.forEach(p => {
        const byT = {}; p.txs.forEach(t => byT[t.serial] = { t, items: [] });
        p.rows.forEach(r => { if (!r.got) return; const l = S.lines.find(x => x.id === r.lineId); if (!l) return;
          if (r.got < r.want - 1e-6) { S.lines.push(Object.assign({}, l, { id: nid(), qty: Math.round((r.want - r.got) * 1000) / 1000, status: 'waiting', issued: [], remark: l.remark || '' })); l.qty = r.got; }
          l.status = 'issued'; r.serials.forEach(sn => { const t = byT[sn].t; l.issued.push({ slip: t.slip, serial: t.serial, at: new Date(t.iso + 'T' + (t.time || '12:00')).toISOString() }); });
          const t0 = byT[r.serials[0]]; t0.items.push({ lineId: l.id, req: l.req, code: l.code, name: itemName(l.code), uom: itemUom(l.code), qty: r.got, remark: '' });
          if (S.stock[l.code]) S.stock[l.code].qty = Math.round((S.stock[l.code].qty - r.got) * 1000) / 1000; });
        p.extra.forEach(x => byT[x.serial] && byT[x.serial].items.push({ lineId: 0, req: p.req, code: x.code, name: x.name || itemName(x.code), uom: itemUom(x.code), qty: x.qty, remark: x.remark || '' }));
        Object.values(byT).forEach(({ t, items }) => { const by = String(t.by || ''); S.entries.push({ id: nid(), slip: t.slip || ('CUIMS-' + t.serial), serial: t.serial, store: p.store, rcv: t.rcv, rname: rcvName(t.rcv), at: new Date(t.iso + 'T' + (t.time || '12:00')).toISOString(), date: t.iso, time: t.time, by: { name: by.split('(')[0].trim(), emp: (by.match(/GA\d{6}/i) || [''])[0].toUpperCase() }, kind: 'cuims', remarks: 'linked from CUIMS', reqs: p.req, items }); });
      });
      save(); ui.view = null; ui.tab = 'reg'; ui.reg.type = 'issue'; render(); toast(P.length + ' requests saved with their CUIMS serials.'); break; }
    case 'nameLookup': { const codes = v === '*' ? [...new Set([].concat(Object.values(S.stores).map(x => x.rcv), S.returns.map(r => r.by), S.entries.map(e => e.rcv)).map(normRcv).filter(Boolean))] : [normRcv(v)].filter(Boolean);
      if (!codes.length || !N) break;
      if (!(await uiConfirm('Check ' + (codes.length === 1 ? rcvLabel(codes[0]) : codes.length + ' codes') + ' on CUIMS? The app only types the code in Received By and reads the names in the list. Nothing is selected or saved on CUIMS.', 'Check names'))) break;
      N.startJob(jobJson({ id: 'N' + Date.now(), kind: 'names', phase: 'names', slip: 'NAMES', store: 'Receiver names', title: 'Receiver names from CUIMS', codes, idx: 0, names: {}, log: [], tries: {}, queue: false, autoSubmit: false, items: [] })); break; }
    case 'vfIgnF': { const [rid, fid] = v.split('|'); const R = (S.verifyReports || []).find(r => r.id === rid); const f = R && R.findings.find(x => x.id === fid); if (!f) break;
      const note = await uiPrompt('Ignore this error in all future checks? Add a short reason (optional).', '', 'Ignore'); if (note == null) break;
      S.verifyIgnore = S.verifyIgnore || {}; S.verifyIgnore[fSig(f)] = { at: new Date().toISOString(), note: note.trim(), kind: f.kind, label: f.label || f.serial || '', code: f.code || '' }; save(); render(); break; }
    case 'vfUnIgn': { const [rid, fid] = v.split('|'); const R = (S.verifyReports || []).find(r => r.id === rid); const f = R && R.findings.find(x => x.id === fid); if (!f) break; delete (S.verifyIgnore || {})[fSig(f)]; save(); render(); break; }
    case 'vfShowIgn': ui.showIgn = !ui.showIgn; render(); break;
    case 'vdTog': ui.vdOpen = ui.vdOpen || {}; ui.vdOpen[v] = !ui.vdOpen[v]; render(); break;
    case 'ignDelE': delete (S.verifyIgnore || {})[v]; save(); render(); break;
    case 'ignTog': ui.ignOpen = !ui.ignOpen; render(); break;
    case 'vfIgn': case 'vfIgnP': { const [rid, fid] = v.split('|'); const R = (S.verifyReports || []).find(r => r.id === rid); const f = R && R.findings.find(x => x.id === fid); if (!f) break; const I = ignList();
      if (a === 'vfIgn') { if (!(await uiConfirm('Ignore CUIMS Serial ' + f.serial + ' forever? It will never be checked or added to your data.', 'Ignore'))) break; I.serials[f.serial] = { at: new Date().toISOString(), slip: f.slip || '', store: f.store || '', by: f.entryBy || '' }; }
      else { const pc = personCode(f.entryBy); if (!(await uiConfirm('Ignore every CUIMS entry made by ' + pc + ' (' + String(f.entryBy).split('(')[0].trim() + ')? Their entries will never be checked or added.', 'Ignore person'))) break; I.people[pc] = { at: new Date().toISOString(), name: String(f.entryBy).split('(')[0].trim() }; }
      f.ignored = true; save(); render(); break; }
    case 'ignDel': { const [t2, k] = v.split('|'); const I = ignList(); if (!(await uiConfirm('Remove this rule from the ignore list?', 'Remove'))) break; if (t2 === 's') delete I.serials[k]; else delete I.people[k]; save(); render(); break; }
    case 'ignAddS': { const k = await uiPrompt('CUIMS Serial No to ignore', '', 'Ignore'); if (!k || !/^\d{3,9}$/.test(k.trim())) break; ignList().serials[k.trim()] = { at: new Date().toISOString(), slip: '', store: '', by: 'added by hand' }; save(); render(); break; }
    case 'ignAddP': { const k = await uiPrompt('Employee code to ignore (e.g. GA600301)', 'GA', 'Ignore'); const pc = personCode(k); if (!pc) { toast('Enter GA + 6 digits.'); break; } ignList().people[pc] = { at: new Date().toISOString(), name: '' }; save(); render(); break; }
    case 'retSt': ui.reg.rst = v; render(); break;
    case 'retStartAll': { const Q = retQueue(); if (Q[0]) startReturnJob(Q[0]); break; }
    case 'retCuims': { const r = S.returns.find(x => String(x.id) === v); if (r) startReturnJob(r); break; }
    case 'retBatch': ui.drawer = false; ui.form = { mode: 'return', date: today(), groups: [], act: 0, q: '', paste: '' }; ui.sheet = { kind: 'batch' }; renderSheet(); break;
    case 'retBatchOld': ui.form = { recvDate: today(), groups: [{ store: '', by: '', rows: [{ code: '', qty: '' }] }], paste: '' }; ui.sheet = { kind: 'retBatch' }; renderSheet(); break;
    case 'rbAddG': ui.form.groups.push({ store: '', by: '', rows: [{ code: '', qty: '' }] }); renderSheet(); break;
    case 'rbDelG': ui.form.groups.splice(+v, 1); if (!ui.form.groups.length) ui.form.groups.push({ store: '', by: '', rows: [{ code: '', qty: '' }] }); renderSheet(); break;
    case 'rbAddR': ui.form.groups[+v].rows.push({ code: '', qty: '' }); renderSheet(); break;
    case 'rbDelR': { const [g, r] = v.split('|').map(Number); ui.form.groups[g].rows.splice(r, 1); if (!ui.form.groups[g].rows.length) ui.form.groups[g].rows.push({ code: '', qty: '' }); renderSheet(); break; }
    case 'rbPaste': { const f = ui.form; const G = {}; String(f.paste || '').split(/\r?\n/).forEach(line => { const c = line.split(/\t|,|;/).map(x => x.trim()); if (c.length < 4 || !c[0] || !validRcv(c[1].replace(/^GA/i, ''))) return; const k = c[0].toUpperCase() + '|' + c[1].replace(/^GA/i, ''); (G[k] = G[k] || { store: c[0].toUpperCase(), by: c[1].replace(/^GA/i, ''), rows: [] }).rows.push({ code: c[2].toUpperCase(), qty: c[3] }); });
      const add = Object.values(G); if (!add.length) { toast('Paste rows as: Store, Employee code, Item code, Qty'); break; }
      f.groups = f.groups.filter(g => g.store || g.by || g.rows.some(r => r.code)).concat(add); f.paste = ''; renderSheet(); break; }
    case 'rbSave': { const f = ui.form; const G = f.groups.map(g => ({ store: String(g.store || '').trim().toUpperCase(), by: String(g.by || '').trim(), rows: g.rows.filter(r => r.code && parseFloat(r.qty) > 0) })).filter(g => g.store || g.rows.length);
      const bad = G.find(g => !g.store || !validRcv(g.by) || !g.rows.length); if (bad) { toast('Each return needs a store, a 6-digit employee and at least one item.'); break; }
      if (!G.length) { toast('Add at least one return.'); break; }
      if (!(await uiConfirm('Save ' + G.length + ' return' + (G.length > 1 ? 's' : '') + ' (' + G.reduce((n, g) => n + g.rows.length, 0) + ' items), came on ' + cuimsDate(f.recvDate) + '?', 'Save returns'))) break;
      undoArm('retBatchSave');
      G.forEach((g, i) => S.returns.push({ id: nid(), no: nextReturnNo(f.recvDate || today()), against: '1111', store: g.store, by: g.by, byName: rcvName(g.by), date: today(), recvDate: f.recvDate || today(), time: timeNow(), serial: '', remarks: '', enteredBy: { name: S.me.name || '', emp: S.me.emp || '' },
        items: g.rows.map(r => ({ code: r.code.toUpperCase(), name: itemName(r.code.toUpperCase()), uom: itemUom(r.code.toUpperCase()), qty: parseFloat(r.qty), remark: '' })) }));
      ui.reg.type = 'return'; ui.reg.date = today(); save(); ui.sheet = null; renderSheet(); ui.tab = 'reg'; render(); break; }
    case 'mgOpen': ui.drawer = false; mgInit(); ui.view = 'manage'; render(); window.scrollTo(0, 0); break;
    case 'mgType': ui.mg.type = v; ui.mg.sel = {}; ui.mg.st = {}; render(); break;
    case 'mgF': ui.mg.showF = !ui.mg.showF; render(); break;
    case 'mgSt': if (ui.mg.st[v]) delete ui.mg.st[v]; else ui.mg.st[v] = 1; ui.mg.sel = {}; render(); break;
    case 'mgStore': if (ui.mg.stores[v]) delete ui.mg.stores[v]; else ui.mg.stores[v] = 1; ui.mg.sel = {}; render(); break;
    case 'mgClearF': Object.assign(ui.mg, { rf: '', rt: '', if: '', it: '', stores: {}, st: {}, sel: {} }); render(); break;
    case 'mgSel': if (t.checked) ui.mg.sel[v] = 1; else delete ui.mg.sel[v]; render(); break;
    case 'mgAll': { const L = mgList(); if (t.checked) L.forEach(x => ui.mg.sel[x.id] = 1); else ui.mg.sel = {}; render(); break; }
    case 'mgClear': ui.mg.sel = {}; render(); break;
    case 'mgExport': { const X = mgList().filter(x => ui.mg.sel[x.id]); const rows = X.map(x => x.kind === 'req' ? { 'Request No': x.req, Store: x.store, 'Request date': fmtLong(x.date), Status: x.man ? 'Manual · ' + (x.mst === 'done' ? 'completed' : 'pending') : x.st, Articles: x.n, Pending: x.w, Slips: x.slips.map(e => e.slip + (e.serial ? ' #' + e.serial : '')).join(', ') } : x.kind === 'slip' ? { Slip: x.e.slip, Serial: x.e.serial || '', Store: x.store, 'Issue date': fmtLong(x.date), Time: entryTime(x.e), 'Request No': x.req, Articles: entryCount(x.e), Type: x.st } : { 'Return No': x.r.no, Store: x.store, Date: fmtLong(x.date), Serial: x.r.serial || '', Items: x.r.items.length });
      saveWb([['Selected', rows]], 'Selected-' + ui.mg.type + '-' + today() + '.xlsx'); break; }
    case 'mgDone': case 'mgPend': { const X = mgList().filter(x => ui.mg.sel[x.id] && x.kind === 'req'); if (!X.length) break;
      if (!(await uiConfirm((a === 'mgDone' ? 'Mark ' : 'Clear pending of ') + X.length + ' request' + (X.length > 1 ? 's' : '') + (a === 'mgDone' ? ' as completed? Their pending articles are closed (not issued).' : '? Their pending articles are removed; issued slips stay.'), a === 'mgDone' ? 'Mark completed' : 'Clear pending', true))) break;
      X.forEach(x => { if (x.man) { if (a === 'mgDone') S.manReqs[x.req].status = 'done'; return; } S.lines.forEach(l => { if (l.req === x.req && l.status === 'waiting') { audit(a === 'mgDone' ? 'close' : 'remove', l); l.status = 'dropped'; } }); });
      ui.mg.sel = {}; save(); render(); break; }
    case 'mgDelSlipPend': { const X = mgList().filter(x => ui.mg.sel[x.id] && x.kind === 'slip'); if (!X.length) break;
      if (!(await uiConfirm('Delete ' + X.length + ' slip' + (X.length > 1 ? 's' : '') + ' and make their articles pending again? Use this only if they were NOT really submitted on CUIMS.', 'Delete & make pending', true))) break;
      X.forEach(x => { const ids = new Set(x.e.items.map(i => i.lineId)); S.lines.forEach(l => { if (ids.has(l.id) && l.status === 'issued') { l.issued = l.issued.filter(z => z.slip !== x.e.slip); if (!l.issued.length) { l.status = 'waiting'; if (S.stock[l.code]) S.stock[l.code].qty = Math.round((S.stock[l.code].qty + l.qty) * 1000) / 1000; } } }); });
      const del = new Set(X.map(x => x.id)); S.entries = S.entries.filter(e => !del.has(String(e.id))); ui.mg.sel = {}; save(); render(); break; }
    case 'mgDel': { const M = ui.mg, X = mgList().filter(x => M.sel[x.id]); if (!X.length) break;
      const what = M.type === 'req' ? 'request' : M.type === 'slip' ? 'slip' : 'return';
      const extra = M.type === 'req' ? ' Their articles, manual records and slips made only for them are deleted. Stock is not changed.' : M.type === 'slip' ? ' Pending and stock are not changed.' : '';
      if (!(await uiConfirm('Delete ' + X.length + ' ' + what + (X.length > 1 ? 's' : '') + '?' + extra, 'Delete ' + X.length, true))) break;
      if (M.type === 'req') { const R = new Set(X.map(x => x.req)); const lineIds = new Set(S.lines.filter(l => R.has(l.req)).map(l => l.id));
        S.lines = S.lines.filter(l => !R.has(l.req)); X.forEach(x => { if (S.manReqs) delete S.manReqs[x.req]; if (S.paper) delete S.paper[x.req]; });
        S.entries = S.entries.map(e => { const items = e.items.filter(i => !lineIds.has(i.lineId) && !R.has(i.req)); const reqs = e.reqs ? String(e.reqs).split(/\s*,\s*/).filter(q => !R.has(q)).join(', ') : e.reqs; return Object.assign({}, e, { items, reqs }); }).filter(e => e.items.length || (e.reqs && e.reqs.length)); }
      else if (M.type === 'slip') { const del = new Set(X.map(x => x.id)); S.entries = S.entries.filter(e => !del.has(String(e.id))); }
      else { const del = new Set(X.map(x => x.id)); S.returns = S.returns.filter(r => !del.has(String(r.id))); }
      M.sel = {}; save(); render(); break; }
    case 'paperAddFrom': { ui.paperBack = ui.sheet; ui.paperFor = v; const pi = document.getElementById('paperIn'); pi.value = ''; pi.click(); break; }
    case 'paperOpenReq': ui.sheet = null; renderSheet(); ui.lastReq = v; ui.view = 'req'; ui.req = v; render(); window.scrollTo(0, 0); break;
    case 'paperDay': ui.sheet = { kind: 'paperDay', day: v }; renderSheet(); break;
    case 'advIssue': { const r = requests().find(x => x.req === v); if (!r) break; const L = advLines(r);
      if (!L.length) { toast('Nothing of this request is in stock right now.'); break; }
      openStart(r.store, L.map(l => l.id), r.store + ' · ' + r.req + ' (advance)', true); break; }
    case 'back': ui.view = null; render(); break;
    case 'hold': if (t.checked) S.hold[v] = 1; else delete S.hold[v]; save(); render(); break;
    case 'fillReq': { ui.lastReq = v; const PL = plan(); const r = requests().find(x => x.req === v); const ids = r.lines.filter(l => l.status === 'waiting' && PL[l.id] === 'issue').map(l => l.id); openStart(r.store, ids, r.store + ', request ' + r.req); break; }
    case 'fillReqPend': { ui.lastReq = v; const PL = plan(); const r = requests().find(x => x.req === v); const ids = r.lines.filter(l => isPending(l) && PL[l.id] === 'issue').map(l => l.id); if (!ids.length) break; openStart(r.store, ids, r.store + ' · ' + r.req); break; }
    case 'fltClear': { const [k, key] = v.split('|'); const f = fltGet(k); f[key] = ''; if ((k === 'done' || k === 'reg') && !f.rd && !f.id) { f.id = today(); toast('At least one date is needed. Issue date set to today.'); } if (k === 'reg') ui.reg.date = f.id || ui.reg.date; render(); break; }
    case 'fillStore': { const PL = plan(); const ids = S.lines.filter(l => isPending(l) && l.store === v && PL[l.id] === 'issue').map(l => l.id); openStart(v, ids, v + ', pending clearance'); break; }
    case 'editReq': { const r = requests().find(x => x.req === v); const w = r.lines.filter(l => l.status === 'waiting');
      ui.form = { req: v, store: r.store, date: r.date, rcv: (r.lines.find(l => l.rcv) || {}).rcv || '', slip: (w.find(l => l.slip) || {}).slip || '', remark: (w.find(l => l.remark) || {}).remark || '', items: w.map(l => ({ lineId: l.id, code: l.code, qty: l.qty, name: itemName(l.code), uom: itemUom(l.code) })) };
      ui.sheet = { kind: 'editReq' }; renderSheet(); break; }
    case 'dropReq': if (await uiConfirm('Remove request ' + v + ' (' + ((requests().find(x => x.req === v) || {}).store || '') + ') from the list? Waiting articles are removed; issued ones stay in the records.')) { S.lines.forEach(l => { if (l.req === v && l.status === 'waiting') l.status = 'dropped'; }); save(); ui.view = null; render(); } break;
    case 'saveReq': { const f = ui.form; if (f.rcv && !validRcv(f.rcv)) { toast('Receiver must be a GA or E code, or blank.'); break; }
      const items = cleanItems(f.items); const keep = new Set(items.filter(i => i.lineId).map(i => i.lineId));
      const sl = (f.slip || '').trim().toUpperCase(); if (sl && !SLIP_RE.test(sl)) { toast('Slip No must be 2–10 characters with a digit.'); break; }
      S.lines.forEach(l => { if (l.req !== f.req) return; l.store = f.store.trim().toUpperCase(); l.date = f.date || l.date; l.rcv = f.rcv || ''; if (l.status === 'waiting') { l.slip = sl; l.remark = (f.remark || '').trim(); } if (l.status === 'waiting' && !keep.has(l.id)) l.status = 'dropped'; });
      items.forEach(i => { if (i.lineId) { const l = S.lines.find(x => x.id === i.lineId); l.code = i.code; l.qty = i.qty; } else S.lines.push({ id: nid(), req: f.req, store: f.store.trim().toUpperCase(), date: f.date, code: i.code, qty: i.qty, rcv: f.rcv || '', slip: sl, src: 'new', earlier: '', status: 'waiting', issued: [] }); });
      save(); ui.sheet = null; renderSheet(); render(); toast('Request saved.'); break; }
    case 'bulkEdit': ui.form = { start: nextSlip(), allDate: today(), rows: bulkList().map(r => ({ req: r.req, newReq: r.req, store: r.store, n: r.w.length, slip: (r.w.find(l => l.slip) || {}).slip || '', date: r.date, rcv: (r.lines.find(l => l.rcv) || {}).rcv || (S.stores[r.store] || {}).rcv || '' })) }; ui.sheet = { kind: 'bulk' }; renderSheet(); break;
    case 'bulkAuto': { const f = ui.form; const m = String(f.start || '').trim().toUpperCase().match(/^(.*?)(\d+)$/); if (!m) { toast('Type the first Slip No, ending in a number, e.g. JV/920'); break; }
      const used = allSlips(); f.rows.forEach(r => used.has((r.slip || '').toUpperCase()) || r.slip ? used.add(r.slip.toUpperCase()) : 0);
      let n = parseInt(m[2], 10);
      f.rows.forEach(r => { if (r.slip) return; let sl; do { sl = m[1] + String(n).padStart(m[2].length, '0'); n++; } while (used.has(sl.toUpperCase())); used.add(sl.toUpperCase()); r.slip = sl; });
      renderSheet(); break; }
    case 'bulkDate': ui.form.rows.forEach(r => r.date = ui.form.allDate || today()); renderSheet(); break;
    case 'bulkSave': { const f = ui.form; const bad = f.rows.find(r => (r.slip && !SLIP_RE.test(r.slip)) || (r.rcv && !validRcv(r.rcv)) || !String(r.newReq || '').trim());
      const reqClash = f.rows.find(r => r.newReq.trim() !== r.req && S.lines.some(l => l.req === r.newReq.trim()));
      if (reqClash) { toast('Request No ' + reqClash.newReq + ' already exists. Use another.'); break; }
      if (bad) { toast('Check ' + bad.store + ': Slip 2–10 chars with a digit, receiver 6 digits.'); break; }
      const seen = {}; const used = allSlips(); const clash = f.rows.find(r => r.slip && (seen[r.slip] || used.has(r.slip)) ? true : (seen[r.slip] = 1, false));
      if (clash) { toast('Slip ' + clash.slip + ' is used twice or already used. Change it.'); break; }
      f.rows.forEach(r => S.lines.forEach(l => { if (l.req !== r.req) return; if (r.date) l.date = r.date; l.rcv = r.rcv || ''; if (l.status === 'waiting') l.slip = r.slip || ''; l.req = r.newReq.trim(); }));
      S.entries.forEach(e => e.items.forEach(i => { const r = f.rows.find(x => x.req === i.req); if (r) i.req = r.newReq.trim(); }));
      save(); ui.sheet = null; renderSheet(); render(); toast('All requests updated.'); break; }
    case 'markDone': { const PL = plan(); const r = requests().find(x => x.req === v); const w = r.lines.filter(l => l.status === 'waiting'); const pick = {}; w.forEach(l => { if (PL[l.id] === 'issue') pick[l.id] = 1; });
      ui.form = { req: v, store: r.store, slip: plannedSlip(w.map(l => l.id)) || '', serial: '', rcv: (r.lines.find(l => l.rcv) || {}).rcv || (S.stores[r.store] || {}).rcv || '', date: today(), lines: w, pick };
      ui.sheet = { kind: 'mark' }; renderSheet(); break; }
    case 'markPick': if (t.checked) ui.form.pick[v] = 1; else delete ui.form.pick[v]; break;
    case 'markSave': { const f = ui.form; const slip = (f.slip || '').trim().toUpperCase(); const sp = slipProblem(slip);
      if (sp) { toast(sp); break; } if (!validRcv(f.rcv)) { toast('Receiver must be 6 digits (GA) or up to 5 digits (E code).'); break; }
      const ls = f.lines.filter(l => f.pick[l.id]); if (!ls.length) { toast('Tick at least one article.'); break; }
      const at = new Date(f.date + 'T' + timeNow()).toISOString();
      S.entries.push({ id: nid(), slip, serial: (f.serial || '').trim(), store: f.store, rcv: f.rcv, rname: rname(f.rcv), at, date: f.date, time: timeNow(), by: meTag(), kind: 'manual', remarks: 'marked by hand',
        items: ls.map(l => ({ lineId: l.id, req: l.req, code: l.code, name: itemName(l.code), uom: itemUom(l.code), qty: l.qty, remark: remarkFor(l.date) })) });
      ls.forEach(l => { const x = S.lines.find(y => y.id === l.id); x.status = 'issued'; x.issued.push({ slip, serial: (f.serial || '').trim(), at }); if (S.stock[l.code]) S.stock[l.code].qty = Math.round((S.stock[l.code].qty - l.qty) * 1000) / 1000; });
      save(); ui.sheet = null; renderSheet(); render(); toast('Recorded ' + slip + ' as issued.'); break; }
    case 'expPendPdf': openExport('pending'); break;
    case 'setPage': ui.setPage = v; render(); window.scrollTo(0, 0); break;
    case 'setBack': ui.setPage = null; render(); window.scrollTo(0, 0); break;
    case 'goProfile': ui.tab = 'set'; ui.view = null; ui.setPage = 'profile'; render(); window.scrollTo(0, 0); break;
    case 'togStore': ui.openStore[v] = !ui.openStore[v]; render(); break;
    case 'dropStore': { const n = S.lines.filter(l => isPending(l) && l.store === v).length;
      if (await uiConfirm('Remove all ' + n + ' pending articles of ' + v + '? Issued records stay. (You can restore from a cloud backup if needed.)')) { S.lines.forEach(l => { if (isPending(l) && l.store === v) l.status = 'dropped'; }); save(); render(); toast(v + ' removed from Pending.'); } break; }
    case 'photo': document.getElementById('photoIn').click(); break;
    case 'openMgr': openLiveStock(); break;
    case 'openMgrManual': if (N && N.openMgr) N.openMgr(); break;
    case 'autoStockTog': S.autoStock = autoStockCfg(); S.autoStock.on = !S.autoStock.on; save(true); render(); toast('Auto update ' + (S.autoStock.on ? 'on' : 'off') + '.'); break;
    case 'saveUrls': { const e = ui.urlEmp != null ? ui.urlEmp : INFO.urlEmp, m = ui.urlMgr != null ? ui.urlMgr : INFO.urlMgr;
      if (N && N.setUrls) { N.setUrls(e || '', m || ''); INFO.urlEmp = e; INFO.urlMgr = m; toast('Pages saved.'); } else toast('Update the app to use this.'); break; }
    case 'resetZoom': if (N && N.resetZoom) { N.resetZoom(); toast('Zoom reset. Reopen CUIMS.'); } break;
    case 'moveStore': { const allSt = [...new Set([...(S.storeOrder || []), ...Object.keys(S.stores), ...S.lines.map(l => l.store)])].sort(byStore); const i = allSt.indexOf(v), j = i + (+t.dataset.d);
      if (j < 0 || j >= allSt.length) break; [allSt[i], allSt[j]] = [allSt[j], allSt[i]]; S.storeOrder = allSt; save(); render(); break; }
    case 'cropSave': { const c = ui.sheet; const out = document.createElement('canvas'); out.width = out.height = 320; const g = out.getContext('2d');
      const img = c.img; const V = 280; const base = Math.max(V / img.width, V / img.height) * c.zoom;
      const dw = img.width * base, dh = img.height * base; const dx = (V - dw) / 2 + c.x, dy = (V - dh) / 2 + c.y; const k = 320 / V;
      const png = /^data:image\/(png|webp)/.test(c.src); if (!png) { g.fillStyle = '#fff'; g.fillRect(0, 0, 320, 320); } g.drawImage(img, dx * k, dy * k, dw * k, dh * k);
      S.me.photo = png ? out.toDataURL('image/png') : out.toDataURL('image/jpeg', 0.88); S.me.photoCut = png; save(); ui.sheet = null; renderSheet(); render(); toast('Photo updated.'); break; }
    case 'photoDel': delete S.me.photo; save(); render(); break;
    case 'expPendXlsx': openExport('pending'); break;
    case 'closeSheet': ui.sheet = null; renderSheet(); break;
    case 'pick': ui.picker = { id: v, q: '' }; renderPicker(); { const i = document.querySelector('[data-pkq]'); if (i && PICKS[v] && PICKS[v].search) i.focus(); } break;
    case 'pickClose': ui.picker = null; renderPicker(); break;
    case 'pickSet': { const cfg = PICKS[ui.picker.id]; ui.picker = null; renderPicker(); if (cfg) cfg.set(v); break; }
    case 'newReq': ui.drawer = false; renderDrawer(); ui.form = { store: '', req: nextReqNo(), date: today(), rcv: '', slip: '', q: '', items: [] }; ui.sheet = { kind: 'newReq' }; renderSheet(); break;
    case 'nrPick': { const st = S.stock[v]; ui.form.items.push({ code: v, name: st.name, uom: st.uom, qty: '' }); ui.form.q = ''; renderSheet(); const el = document.querySelector('[data-nrq="' + (ui.form.items.length - 1) + '"]'); if (el) el.focus(); break; }
    case 'nrDel': ui.form.items.splice(+v, 1); renderSheet(); break;
    case 'nrSave': { const f = ui.form; const st = f.store.trim().toUpperCase();
      f.items.forEach(it => S.lines.push({ id: nid(), req: f.req.trim(), store: st, date: f.date || today(), code: it.code, qty: parseFloat(it.qty), rcv: f.rcv || '', slip: (f.slip || '').trim().toUpperCase(), remark: (f.remark || '').trim(), src: 'new', earlier: '', status: 'waiting', issued: [] }));
      if (!S.stores[st]) S.stores[st] = { rcv: f.rcv || '', rname: '' };
      save(); ui.sheet = null; renderSheet(); render(); toast('Request ' + f.req + ' saved for ' + st + '.'); break; }
    case 'doneOpenDay': { const f = fltGet('done'); f.id = v; f.rd = ''; ui.view = 'done'; render(); window.scrollTo(0, 0); break; }
    case 'doneOpen': ui.drawer = false; ui.view = 'done'; render(); window.scrollTo(0, 0); break;
    case 'doneExport': openExport('done'); break;
    case 'doneMode': ui.doneMode = v; render(); break;
    case 'batchReq': ui.drawer = false; renderDrawer(); ui.form = { date: today(), slipStart: '', groups: [], act: 0, q: '', paste: '' }; ui.sheet = { kind: 'batch' }; renderSheet(); break;
    case 'btAct': ui.form.act = +v; ui.form.q = ''; renderSheet(); break;
    case 'btDel': ui.form.groups.splice(+v, 1); ui.form.act = Math.max(0, ui.form.groups.length - 1); renderSheet(); break;
    case 'btItemDel': { const [a1, b1] = v.split('|').map(Number); ui.form.groups[a1].items.splice(b1, 1); renderSheet(); break; }
    case 'btPick': { const g = ui.form.groups[ui.form.act]; const st = S.stock[v]; g.items.push({ code: v, name: st.name, uom: st.uom, qty: '' }); ui.form.q = ''; renderSheet(); const el = document.querySelector('[data-bq="' + ui.form.act + '|' + (g.items.length - 1) + '"]'); if (el) { el.focus(); el.scrollIntoView({ block: 'center' }); } break; }
    case 'btPaste': { const f = ui.form; let n = 0, skip = 0;
      String(f.paste || '').split(/\r?\n/).forEach(line => { const c = line.split(/	|,/).map(x => x.trim()); if (c.length < 3 || !c[0] || !c[1]) return; const q = parseFloat(c[2]); if (!(q > 0)) { skip++; return; }
        const store = c[0].toUpperCase(), code = c[1].toUpperCase(); let g = f.groups.find(x => x.store === store && (!c[3] || x.req === c[3]));
        if (!g) { batchAddGroup(store); g = f.groups[f.groups.length - 1]; if (c[3]) { g.req = c[3].toUpperCase(); g._auto = false; } }
        g.items.push({ code, name: itemName(code), uom: itemUom(code), qty: String(q) }); n++; });
      f.paste = ''; renderSheet(); toast(n + ' rows added' + (skip ? ', ' + skip + ' skipped (no qty)' : '') + '.'); break; }
    case 'btSave': if (ui.form.mode === 'return') { const f = ui.form; const tm = timeNow(); const made = [];
        if (!(await uiConfirm('Save ' + f.groups.length + ' return' + (f.groups.length > 1 ? 's' : '') + ', came on ' + cuimsDate(f.date) + '?', 'Save'))) break;
        undoArm('retBatchSave');
        f.groups.forEach(g => { const rec = { id: nid(), no: String(g.req).trim().toUpperCase(), against: '1111', store: g.store.toUpperCase(), by: g.rcv, byName: rcvName(g.rcv), date: today(), recvDate: f.date || today(), time: tm, serial: '', remarks: '', enteredBy: { name: S.me.name || '', emp: S.me.emp || '' },
          items: g.items.map(it => ({ code: it.code, name: it.name || itemName(it.code), uom: it.uom || itemUom(it.code), qty: parseFloat(it.qty), remark: '' })) }; S.returns.push(rec); made.push(rec); });
        ui.tab = 'reg'; ui.reg.type = 'return'; save(); ui.sheet = null; renderSheet(); render(); if (v === 'cuims' && made[0]) startReturnJob(made[0]); break; }
      { const f = ui.form; let n = 0;
      f.groups.forEach(g => { const st = g.store.toUpperCase(); g.items.forEach(it => { S.lines.push({ id: nid(), req: g.req.trim(), store: st, date: f.date || today(), code: it.code, qty: parseFloat(it.qty), rcv: g.rcv || '', slip: (g.slip || '').toUpperCase(), remark: (g.remark || '').trim(), src: 'new', earlier: '', status: 'waiting', issued: [] }); n++; });
        if (!S.stores[st]) S.stores[st] = { rcv: g.rcv || '', rname: '' }; });
      save(); ui.sheet = null; renderSheet(); render(); toast(n + ' articles saved in ' + f.groups.length + ' requests.'); break; }
    case 'doneTog': ui.doneOpen[v] = !ui.doneOpen[v]; render(); break;
    case 'noop': break;
    case 'consOpen': ui.drawer = false; ui.view = 'cons'; render(); window.scrollTo(0, 0); break;
    case 'consP': ui.cons.p = v; render(); break;
    case 'consM': ui.cons.mode = v; render(); break;
    case 'consO': ui.cons.open[v] = !ui.cons.open[v]; render(); break;
    case 'consExport': openExport('cons'); break;
    case 'stockOpen': ui.drawer = false; ui.view = 'stock'; render(); window.scrollTo(0, 0); break;
    case 'stkF': ui.stk.f = v; ui.stk.open = null; render(); break;
    case 'stkEdited': ui.stk.f = ui.stk.f === 'edited' ? 'all' : 'edited'; ui.stk.open = null; render(); break;
    case 'stkEdit': { const it = S.stock[v]; if (!it) break; const nv = await uiPrompt('New quantity for ' + it.name + ' (' + v + '). Now ' + num(it.qty) + ' ' + it.uom + '.', String(it.qty), 'Save');
      if (nv == null) break; const q = parseFloat(nv); if (isNaN(q) || q < 0) { toast('Enter 0 or more.'); break; }
      if (!(await uiConfirm('Change ' + it.name + ' stock from ' + num(it.qty) + ' to ' + num(q) + ' ' + it.uom + '?', 'Change'))) break;
      undoArm('stkEdit'); S.stockEdits = S.stockEdits || {}; const prev = S.stockEdits[v]; S.stockEdits[v] = { from: prev ? prev.from : it.qty, to: q, at: new Date().toISOString(), by: S.me.name || '' };
      S.stockLog = (S.stockLog || []).concat([{ at: new Date().toISOString(), src: 'edit', code: v, from: it.qty, to: q, by: S.me.name || '' }]).slice(-300);
      it.qty = q; save(); render(); break; }
    case 'stkRen': { const it = S.stock[v]; if (!it) break; const nm = await uiPrompt('Item name for ' + v, it.name, 'Next'); if (nm == null) break; const um = await uiPrompt('Unit (UOM) for ' + v, it.uom, 'Save'); if (um == null) break;
      undoArm('stkEdit'); it.name = nm.trim() || it.name; it.uom = um.trim().toUpperCase() || it.uom; save(); render(); break; }
    case 'stkDel': { const it = S.stock[v]; if (!it) break; if (!(await uiConfirm('Delete ' + it.name + ' (' + v + ') from the stock list? Requests that need it will show "Not in stock".', 'Delete', true))) break;
      undoArm('stkEdit'); delete S.stock[v]; if (S.stockEdits) delete S.stockEdits[v]; ui.stk.open = null; save(); render(); break; }
    case 'stkAdd': { const c = await uiPrompt('Item code (e.g. GR-198)', '', 'Next'); if (!c) break; const code = c.trim().toUpperCase(); if (S.stock[code]) { toast(code + ' already exists. Use Edit qty.'); ui.stk.q = code; render(); break; }
      const nm = await uiPrompt('Item name', '', 'Next'); if (nm == null) break; const um = await uiPrompt('Unit (KG, NOS, LTR…)', 'KG', 'Next'); if (um == null) break; const qq = await uiPrompt('Quantity in stock', '0', 'Add'); if (qq == null) break;
      const q = parseFloat(qq); if (isNaN(q) || q < 0) { toast('Enter 0 or more.'); break; }
      undoArm('stkEdit'); S.stock[code] = { name: nm.trim() || code, uom: um.trim().toUpperCase() || 'NOS', qty: q }; S.stockEdits = S.stockEdits || {}; S.stockEdits[code] = { from: 0, to: q, at: new Date().toISOString(), by: S.me.name || '', added: true };
      save(); ui.stk.q = code; ui.stk.open = code; render(); break; }
    case 'stkOpen': ui.stk.open = ui.stk.open === v ? null : v; { const b = document.getElementById('stkres'); if (b) b.innerHTML = stockResults(); } break;
    case 'regSt': ui.reg.st = v; render(); break;
    case 'rqTog': ui.rqOpen = ui.rqOpen || {}; ui.rqOpen[v] = !ui.rqOpen[v]; render(); break;
    case 'regTog': ui.regOpen = ui.regOpen || {}; ui.regOpen[v] = !ui.regOpen[v]; render(); break;
    case 'reqStatus': ui.form = { req: v }; ui.sheet = { kind: 'reqStatus' }; renderSheet(); break;
    case 'mslips': { const r = requests().find(x => x.req === v); if (!r) break; const W = r.lines.filter(l => l.status === 'waiting'); const pick = {}; W.forEach(l => pick[l.id] = 1);
      ui.form = { req: v, store: r.store, slip: plannedSlip(W.map(l => l.id)) || nextSlip(), serial: '', rcv: (r.lines.find(l => l.rcv) || {}).rcv || (S.stores[r.store] || {}).rcv || '', date: today(), time: timeNow(), pick, byName: S.me.name || '', byEmp: S.me.emp || '' };
      ui.sheet = { kind: 'mslips' }; renderSheet(); break; }
    case 'msAll': { const r = requests().find(x => x.req === ui.form.req); const W = r.lines.filter(l => l.status === 'waiting'); const all = W.every(l => ui.form.pick[l.id]); ui.form.pick = {}; if (!all) W.forEach(l => ui.form.pick[l.id] = 1); renderSheet(); break; }
    case 'msSave': { const f = ui.form; const slip = String(f.slip || '').trim().toUpperCase(); const sp = slipProblem(slip); if (sp) { toast(sp); break; }
      if (!validRcv(f.rcv)) { toast('Receiver must be 6 digits (GA) or up to 5 digits (E code).'); break; }
      const ls = S.lines.filter(l => l.req === f.req && l.status === 'waiting' && f.pick[l.id]); if (!ls.length) { toast('Tick at least one article.'); break; }
      if (!(await uiConfirm('Save ' + slip + (f.serial ? ' (Serial ' + f.serial + ')' : '') + ' for ' + ls.length + ' article' + (ls.length > 1 ? 's' : '') + ' of ' + f.req + '?', 'Save slip'))) break;
      undoArm('markSave');
      const at = new Date((f.date || today()) + 'T' + (f.time || timeNow())).toISOString();
      S.entries.push({ id: nid(), slip, serial: String(f.serial || '').trim(), store: f.store, rcv: f.rcv, rname: rname(f.rcv), at, date: f.date || today(), time: f.time || timeNow(), by: { name: f.byName || '', emp: f.byEmp || '' }, kind: 'manual', remarks: '',
        items: ls.map(l => ({ lineId: l.id, req: l.req, code: l.code, name: itemName(l.code), uom: itemUom(l.code), qty: l.qty, remark: l.remark || remarkFor(l.date) })) });
      ls.forEach(l => { l.status = 'issued'; l.issued.push({ slip, serial: String(f.serial || '').trim(), at }); if (S.stock[l.code]) S.stock[l.code].qty = Math.round((S.stock[l.code].qty - l.qty) * 1000) / 1000; });
      save(); toast(slip + ' saved. Add the next slip if there is one.');
      const W2 = S.lines.filter(l => l.req === f.req && l.status === 'waiting'); f.pick = {}; W2.forEach(l => f.pick[l.id] = 1); f.slip = nextSlip(); f.serial = ''; renderSheet(); render(); break; }
    case 'paperAdd': { const r = requests().find(x => x.req === v); if (!r || !paperOpen(r.date)) { toast('Photos can only be added on the request date or the next day.'); break; } ui.paperFor = v; const pi = document.getElementById('paperIn'); pi.value = ''; pi.click(); break; }
    case 'paperView': { const [rq, i] = v.split('|'); const p = paperList(rq)[+i]; if (p && !paperSrc(p.id) && p.cloud) { loader(true, 'Loading the photo from the cloud'); await loadCloudPhoto(p); loader(false); render(); } openPaperViewer(rq, +i); break; }
    case 'photoSync': syncPhotos(false); break;
    case 'rsClose': { const l = S.lines.find(x => String(x.id) === v); if (!l) break; if (!(await uiConfirm('Close ' + itemName(l.code) + ' ' + num(l.qty) + ' ' + itemUom(l.code) + '? It stops being pending.', 'Close', true))) break; audit('close', l); l.status = 'dropped'; save(); renderSheet(); render(); break; }
    case 'rsOpen': { const l = S.lines.find(x => String(x.id) === v); if (!l) break; if (!(await uiConfirm('Make ' + itemName(l.code) + ' ' + num(l.qty) + ' ' + itemUom(l.code) + ' pending again?', 'Make pending'))) break; audit('reopen', l); l.status = 'waiting'; save(); renderSheet(); render(); break; }
    case 'rsAll': { const req = ui.form.req; const W = S.lines.filter(l => l.req === req && l.status === 'waiting'); if (!W.length) break; if (!(await uiConfirm('Mark request ' + req + ' as completed? ' + W.length + ' pending article' + (W.length > 1 ? 's are' : ' is') + ' closed (not issued).', 'Mark completed', true))) break; W.forEach(l => { audit('close', l); l.status = 'dropped'; }); save(); renderSheet(); render(); toast(req + ' marked completed.'); break; }
    case 'rsAdd': { const f = ui.form; const c = String(f.addCode || '').trim().toUpperCase(), q = parseFloat(f.addQty); if (!c || !(q > 0)) { toast('Enter item code and qty.'); break; } const base = S.lines.find(l => l.req === f.req); if (!base) break;
      if (!(await uiConfirm('Add ' + itemName(c) + ' ' + num(q) + ' as pending to ' + f.req + '?', 'Add'))) break;
      const nl = { id: nid(), req: f.req, store: base.store, date: base.date, code: c, qty: q, rcv: base.rcv || '', slip: '', remark: base.remark || '', src: base.src, earlier: '', status: 'waiting', issued: [] }; S.lines.push(nl); audit('add', nl); f.addCode = ''; f.addQty = ''; save(); renderSheet(); render(); break; }
    case 'testToggle': { ui.drawer = false; renderDrawer(); const on = !S.testMode; if (!(await uiConfirm(on ? 'Turn on Test mode? Your real requests, slips and stock are put aside and a separate test copy starts. Nothing you do in test mode touches real data.' : 'Leave Test mode? Your real data comes back exactly as it was. Test data is kept for next time.', on ? 'Start testing' : 'Leave test mode'))) break; setTestMode(on); break; }
    case 'testClear': if (await uiConfirm('Delete all test data?', 'Delete', true)) { S.lines = []; S.entries = []; S.returns = []; S.counts = []; S.taskLog = {}; S.corrections = []; S.hold = {}; S.stock = deep((S._real || {}).stock) || S.stock; save(); render(); } break;
    case 'cMode': S.countMode = v === 'fixed' ? 'fixed' : 'random'; if (S.countMode === 'fixed' && !(S.countList || []).length) { save(); ui.view = 'countList'; render(); toast('Add your high-value items first.'); break; } save(); render(); break;
    case 'clOpen': ui.view = 'countList'; render(); window.scrollTo(0, 0); break;
    case 'clAdd': S.countList = S.countList || []; if (!S.countList.includes(v)) S.countList.push(v); save(); { const b = document.getElementById('clres'); if (b) b.innerHTML = clResults(); } render(); break;
    case 'clDel': S.countList = (S.countList || []).filter(k => k !== v); save(); render(); break;
    case 'clMove': { const [i, d] = v.split('|').map(Number); const L = S.countList; const j = i + d; if (j < 0 || j >= L.length) break; [L[i], L[j]] = [L[j], L[i]]; save(true); render(); break; }
    case 'clClear': if (await uiConfirm('Remove all ' + (S.countList || []).length + ' items from your count list?', 'Clear', true)) { undoArm('clDel'); S.countList = []; save(); render(); } break;
    case 'dcRetFix': { const ids = v.split(',').map(String); S.returns.filter(r => ids.includes(String(r.id))).forEach(r => { r.no = nextReturnNo(r.recvDate || r.date); }); save(); render(); break; }
    case 'dcRetFmt': { if (!(await uiConfirm('Renumber all old-style returns to R-DDMM-NN, in date and time order?', 'Renumber'))) break; undoArm('dcRetFmt');
      S.returns.filter(r => !RET_RE.test(String(r.no))).sort((a, b) => String(a.recvDate || a.date).localeCompare(String(b.recvDate || b.date)) || String(a.time || '').localeCompare(String(b.time || ''))).forEach(r => { r.no = nextReturnNo(r.recvDate || r.date); }); save(); render(); break; }
    case 'dcOpen': ui.drawer = false; ui.view = 'check'; render(); window.scrollTo(0, 0); break;
    case 'dcRenum': { const st = t.dataset.s; const to = await uiPrompt('New Request No for ' + st + ' (now ' + v + ')', v + '-' + st.replace(/[^A-Z0-9]/gi, '').slice(0, 4), 'Renumber'); if (to && renumberReqStore(v, st, to)) { save(); render(); toast(st + ' is now ' + to + '.'); } break; }
    case 'dcMerge': { const ids = v.split(',').map(Number); const L = S.lines.filter(l => ids.includes(l.id)); L[0].qty = L.reduce((a, l) => a + l.qty, 0); L.slice(1).forEach(l => l.status = 'dropped'); save(); render(); break; }
    case 'dcKeepFirst': { const ids = v.split(',').map(Number); S.lines.filter(l => ids.slice(1).includes(l.id)).forEach(l => l.status = 'dropped'); save(); render(); break; }
    case 'dcDate': S.lines.forEach(l => { if (l.req === v) l.date = t.dataset.d; }); save(); render(); break;
    case 'dcBad': { const ids = v.split(',').map(Number); S.lines.forEach(l => { if (ids.includes(l.id)) l.status = 'dropped'; }); save(); render(); break; }
    case 'dcSlip': ui.view = null; ui.tab = 'find'; ui.search.q = v; ui.search.type = 'all'; render(); break;
    case 'artsOpen': ui.drawer = false; ui.view = 'arts'; render(); window.scrollTo(0, 0); break;
    case 'artsSt': ui.arts.st = v; render(); break;
    case 'artsExport': { const d = artsDay(); rptPref('arts').sub = (S.me.storeName || '') + (d ? ' · requested ' + fmtLong(d) : ' · all days'); openExport('arts'); break; }
    case 'artsDay': ui.arts.day = v; if (v === 'pick' && !ui.arts.dayPick) ui.arts.dayPick = today(); ui.arts.sel = {}; render(); break;
    case 'artsOpenDay': ui.drawer = false; ui.arts = ui.arts || { q: '', store: '', st: 'all', sel: {} }; ui.arts.day = v === today() ? 'today' : 'pick'; ui.arts.dayPick = v; ui.view = 'arts'; render(); window.scrollTo(0, 0); break;
    case 'artsSel': if (t.checked) ui.arts.sel[v] = 1; else delete ui.arts.sel[v]; render(); break;
    case 'artsAll': { const L = artsList(); if (t.checked) L.forEach(x => ui.arts.sel[x.l.id] = 1); else L.forEach(x => delete ui.arts.sel[x.l.id]); render(); break; }
    case 'artsBClear': ui.arts.sel = {}; render(); break;
    case 'artsCatOn': S.artsCat = t.checked; ui.artsCatOpen = {}; save(true); render(); break;
    case 'artsCatTog': ui.artsCatOpen = ui.artsCatOpen || {}; ui.artsCatOpen[v] = !ui.artsCatOpen[v]; { const b = document.getElementById('artsres'); if (b) b.innerHTML = artsResults(); } break;
    case 'artsCatSel': { const xs = artsList().filter(x => itemCat(x.l.code) === v); if (t.checked) xs.forEach(x => ui.arts.sel[x.l.id] = 1); else xs.forEach(x => delete ui.arts.sel[x.l.id]); render(); break; }
    case 'artsCatMove': { const [code, to] = v.split('|'); S.itemCat = S.itemCat || {}; S.itemCat[code] = to; save(true); render(); break; }
    case 'artsGrpOpen': ui.arts.open = ui.arts.open || {}; ui.arts.open[v] = !ui.arts.open[v]; { const b = document.getElementById('artsres'); if (b) b.innerHTML = artsResults(); } break;
    case 'artsGrp': { const xs = artsList().filter(x => x.l.code === v); if (t.checked) xs.forEach(x => ui.arts.sel[x.l.id] = 1); else xs.forEach(x => delete ui.arts.sel[x.l.id]); render(); break; }
    case 'artQty': { const l = S.lines.find(x => String(x.id) === v); if (!l) break; const nv = await uiPrompt('New quantity for ' + itemName(l.code) + ' (' + l.store + ', ' + l.req + '). Now ' + num(l.qty) + ' ' + itemUom(l.code) + '.', String(l.qty), 'Save');
      if (nv == null) break; const q = parseFloat(nv); if (!(q > 0)) { toast('Enter a quantity above 0.'); break; }
      if (!(await uiConfirm('Change ' + itemName(l.code) + ' from ' + num(l.qty) + ' to ' + num(q) + ' ' + itemUom(l.code) + '?', 'Change'))) break;
      audit('qty', l, { from: l.qty, to: q }); l.qty = q; save(); render(); toast('Quantity updated.'); break; }
    case 'artHold': { const l = S.lines.find(x => String(x.id) === v); if (!l) break; const on = !S.hold[l.id];
      if (!(await uiConfirm((on ? 'Keep ' : 'Release ') + itemName(l.code) + ' (' + l.store + ') ' + (on ? 'on hold? It stays pending but is not filled until you release it.' : 'from hold?'), on ? 'Keep on hold' : 'Release'))) break;
      if (on) S.hold[l.id] = true; else delete S.hold[l.id]; audit(on ? 'hold' : 'release', l); save(); render(); break; }
    case 'artDel': { const l = S.lines.find(x => String(x.id) === v); if (!l) break;
      if (!(await uiConfirm('Remove ' + itemName(l.code) + ' ' + num(l.qty) + ' ' + itemUom(l.code) + ' (' + l.store + ', ' + l.req + ') from pending?', 'Remove', true))) break;
      audit('remove', l); l.status = 'dropped'; delete ui.arts.sel[l.id]; save(); render(); toast('Removed.'); break; }
    case 'artsBHold': case 'artsBRel': case 'artsBDel': { const ids = Object.keys(ui.arts.sel); const L = S.lines.filter(l => ids.includes(String(l.id)) && l.status === 'waiting'); if (!L.length) break;
      const stores = [...new Set(L.map(l => l.store))];
      const what = a === 'artsBDel' ? 'Remove' : a === 'artsBHold' ? 'Keep on hold' : 'Release';
      if (!(await uiConfirm(what + ' ' + L.length + ' article' + (L.length > 1 ? 's' : '') + ' from ' + stores.length + ' store' + (stores.length > 1 ? 's' : '') + ' (' + stores.slice(0, 4).join(', ') + (stores.length > 4 ? '…' : '') + ')?', what, a === 'artsBDel'))) break;
      L.forEach(l => { if (a === 'artsBDel') { audit('remove', l); l.status = 'dropped'; } else if (a === 'artsBHold') { S.hold[l.id] = true; audit('hold', l); } else { delete S.hold[l.id]; audit('release', l); } });
      ui.arts.sel = {}; save(); render(); toast(what + ': ' + L.length + ' done.'); break; }
    case 'renumReq': { const to = await uiPrompt('New Request No for ' + v, v, 'Renumber'); if (to && renumberReq(v, to)) { save(); render(); toast('Renumbered to ' + to + '.'); } break; }
    case 'impRenum': { const to = await uiPrompt('Give the app\'s request ' + v + ' a new Request No. Your file\'s ' + v + ' will then import normally.', v + '-T', 'Renumber'); if (to && renumberReq(v, to)) { save(); reparseUpload(); toast(v + ' in the app is now ' + to + '.'); } break; }
    case 'impDrop': { if (!(await uiConfirm('Remove the waiting articles of the app\'s request ' + v + '? Issued records stay. Your file\'s ' + v + ' will then import.', 'Remove', true))) break; S.lines.forEach(l => { if (l.req === v && l.status === 'waiting') l.status = 'dropped'; }); S.lines = S.lines.filter(l => !(l.req === v && l.status === 'dropped' && !l.issued.length)); save(); reparseUpload(); break; }
    case 'impOpenReq': ui.sheet = null; renderSheet(); ui.lastReq = v; ui.view = 'req'; ui.req = v; render(); window.scrollTo(0, 0); break;
    case 'credAuto': ui.cred = ui.cred || {}; ui.cred[v] = ui.cred[v] || {}; ui.cred[v].auto = t.checked; break;
    case 'credSave': { if (!N || !N.setCred) { toast('Update the app to use this.'); break; } let ci = {}; try { ci = JSON.parse(N.credInfo()); } catch (e) {} const c = ci[v] || {}, f = (ui.cred || {})[v] || {};
      const u = (f.u != null ? f.u : c.u || '').trim(); if (!u) { toast('Enter the User ID.'); break; }
      if (!f.p && !c.has) { toast('Enter the password.'); break; }
      N.setCred(v, u, f.p ? f.p : '__keep__', f.auto != null ? f.auto : c.auto !== false); ui.cred[v] = {}; render(); toast('Login saved on this phone.'); break; }
    case 'credDel': if (N && N.setCred && await uiConfirm('Remove the saved login?', 'Delete', true)) { N.setCred(v, '', '', false); ui.cred = ui.cred || {}; ui.cred[v] = {}; render(); toast('Login removed.'); } break;
    case 'homeDate': ui.homeDate = v === today() ? null : v; ui.tab = 'home'; ui.view = null; render(); window.scrollTo(0, 0); break;
    case 'corrOpen': ui.form = { req: v, rows: corrRows(v).map(o => Object.assign(o, { final: String(Math.round((o.issued + o.waiting) * 1000) / 1000) })), addCode: '', addQty: '' }; ui.sheet = { kind: 'corr' }; renderSheet(); break;
    case 'corrAdd': { const f = ui.form; const c = String(f.addCode || '').trim().toUpperCase(), q = parseFloat(f.addQty); if (!c || !(q > 0)) { toast('Enter item code and qty.'); break; } const ex = f.rows.find(o => o.code === c); if (ex) ex.final = String(q); else f.rows.push({ code: c, issued: 0, waiting: 0, slips: [], final: String(q) }); f.addCode = ''; f.addQty = ''; renderSheet(); break; }
    case 'corrSave': { const f = ui.form; const base = S.lines.find(l => l.req === f.req); if (!base) break; let changed = 0, over = [];
      S.corrections = S.corrections || [];
      f.rows.forEach(o => { const F = parseFloat(o.final); if (isNaN(F) || F === o.issued + o.waiting) return;
        const W = S.lines.filter(l => l.req === f.req && l.code === o.code && l.status === 'waiting'); const rem = Math.round((F - o.issued) * 1000) / 1000;
        if (rem > 0) { if (W.length) { W[0].qty = rem; W.slice(1).forEach(l => l.status = 'dropped'); } else S.lines.push({ id: nid(), req: f.req, store: base.store, date: base.date, code: o.code, qty: rem, rcv: base.rcv || '', slip: '', remark: base.remark || '', src: base.src, earlier: o.slips.join(', '), status: 'waiting', issued: [], corr: true }); }
        else { W.forEach(l => l.status = 'dropped'); if (rem < 0) over.push(itemName(o.code) + ' ' + num(-rem)); }
        S.corrections.push({ req: f.req, code: o.code, from: o.issued + o.waiting, to: F, issued: o.issued, at: new Date().toISOString(), by: S.me.name || '' }); changed++; });
      save(); ui.sheet = null; renderSheet(); render(); toast(changed ? 'Correction saved for ' + changed + ' article' + (changed > 1 ? 's' : '') + '.' + (over.length ? ' Over-issued: ' + over.join(', ') + '.' : '') : 'No changes.'); break; }
    case 'sRdClear': ui.search.rd = ''; render(); break;
    case 'drawer': ui.drawer = true; renderDrawer(); break;
    case 'drawerClose': ui.drawer = false; renderDrawer(); break;
    case 'dCount': openCountCycle(); break;
    case 'countLog': ui.drawer = false; ui.view = 'countLog'; render(); window.scrollTo(0, 0); break;
    case 'empOpen': case 'empHome': ui.drawer = false; EMP(); ui.view = 'emp'; render(); window.scrollTo(0, 0); break;
    case 'empHow': EMP().how = v; save(true); render(); break;
    case 'empStockF': EMP().stockF = v === 'pos' ? 'pos' : 'nz'; save(true); render(); toast(v === 'pos' ? 'Only articles above zero.' : 'All articles that are not zero.'); break;
    case 'empPickP': { const E = EMP(), i = E.pick.map(String).indexOf(String(v)); if (i >= 0) E.pick.splice(i, 1); else E.pick.push(isNaN(+v) ? v : +v); save(true); render(); break; }
    case 'empStaff': ui.view = 'empStaff'; render(); window.scrollTo(0, 0); break;
    case 'empAddP': { const F = ui.empNew || {}; if (!String(F.name || '').trim()) { toast('Type the name first.'); break; } EMP().staff.push({ id: nid(), name: F.name.trim(), code: String(F.code || '').trim().toUpperCase(), desig: String(F.desig || '').trim() }); ui.empNew = { name: '', code: '', desig: '' }; save(); render(); toast('Employee added.'); break; }
    case 'empEditP': { const x = EMP().staff.find(k => String(k.id) === String(v)); if (!x) break; const nm = await uiPrompt('Name', x.name, 'Next'); if (nm === null) break; const cd = await uiPrompt('Employee code', x.code || '', 'Next'); if (cd === null) break; const dg = await uiPrompt('Designation', x.desig || '', 'Save'); if (dg === null) break; x.name = nm.trim() || x.name; x.code = cd.trim().toUpperCase(); x.desig = dg.trim(); save(); render(); break; }
    case 'empDelP': { const x = EMP().staff.find(k => String(k.id) === String(v)); if (!x) break; if (!(await uiConfirm('Remove ' + x.name + '? Old results keep their name.', 'Remove', true))) { ui.pendUndo = null; break; } const E = EMP(); E.staff = E.staff.filter(k => k !== x); E.pick = E.pick.filter(k => String(k) !== String(v)); save(); render(); break; }
    case 'empIgnore': ui.view = 'empIgnore'; ui.ign = { t: 'pre', v: '', off: {} }; ui.ignOpen = null; render(); window.scrollTo(0, 0); break;
    case 'eigT': ui.ign.t = v; ui.ign.off = {}; render(); break;
    case 'eigOpen': ui.ignOpen = ui.ignOpen === +v ? null : +v; render(); break;
    case 'eigPrev': { const o = ui.ign.off = ui.ign.off || {}; if (o[v]) delete o[v]; else o[v] = 1; const b = document.getElementById('ignprev'); if (b) b.innerHTML = ignPreview(); break; }
    case 'eigPrevAll': { const o = ui.ign.off = {}; if (v === 'off') ruleAll(ui.ign).forEach(c => o[c] = 1); const b = document.getElementById('ignprev'); if (b) b.innerHTML = ignPreview(); break; }
    case 'eigItemDel': { const [ri, ...rest] = v.split('|'), code = rest.join('|'), r = EMP().ignore[+ri]; if (!r) break; r.ex = r.ex || []; if (!r.ex.includes(code)) r.ex.push(code); save(); render(); toast(itemName(code) + ' removed from this rule.'); break; }
    case 'eigItemBack': { const [ri, ...rest] = v.split('|'), code = rest.join('|'), r = EMP().ignore[+ri]; if (!r) break; r.ex = (r.ex || []).filter(c => c !== code); save(); render(); break; }
    case 'eigSave': { const F = ui.ign, A = ruleAll(F), L = A.filter(c => !(F.off || {})[c]); if (!String(F.v || '').trim() || !L.length) break; EMP().ignore.push({ t: F.t, v: String(F.v).trim(), ex: A.filter(c => (F.off || {})[c]), at: new Date().toISOString() }); ui.ign = { t: F.t, v: '', off: {} }; ui.ignOpen = EMP().ignore.length - 1; save(); render(); toast(L.length + ' article' + (L.length === 1 ? '' : 's') + ' added to the ignore list.'); break; }
    case 'eigDel': { const E = EMP(), r = E.ignore[+v]; if (!r) break; if (!(await uiConfirm('Remove the whole rule "' + EMP_RULE[r.t] + ' ' + r.v + '"? Its ' + ruleCodes(r).length + ' articles can be given to employees again.', 'Remove rule', true))) { ui.pendUndo = null; break; } E.ignore.splice(+v, 1); ui.ignOpen = null; save(); render(); break; }
    case 'empMake': { const E = EMP(), sel = empSel(), n = empHow(); if (!sel.length || !n) break; const codes = empPick(n); if (!codes.length) { toast('No articles left to give out.'); break; }
      const sz = empSplitSizes(codes.length, sel.length); let k = 0;
      const x = { id: nid(), round: E.round.n, createdAt: new Date().toISOString(), status: 'print', by: meTag(), people: sel.map((q, i) => { const cs = codes.slice(k, k + sz[i]); k += sz[i]; return { sid: q.id, name: q.name, code: q.code, desig: q.desig, codes: cs, vals: {}, photos: [], subDate: '', subTime: '' }; }).filter(q => q.codes.length) };
      E.sessions.push(x); ui.empId = x.id; ui.view = 'empSess'; save(); render(); window.scrollTo(0, 0); break; }
    case 'empOpenSess': { const x = EMP().sessions.find(k => String(k.id) === String(v)); if (!x) break; ui.empId = x.id; if (x.status === 'draft' && x.countId) { ui.countId = x.countId; ui.view = 'count'; } else { ui.view = 'empSess'; ui.empTab = 0; } render(); window.scrollTo(0, 0); break; }
    case 'empPrint': ui.sheet = null; openExport('empSheet'); break;
    case 'empPhysDone': { const x = empCur(); if (!x) break; x.status = 'entry'; ui.empTab = 0; save(); render(); window.scrollTo(0, 0); break; }
    case 'empBackPrint': { const x = empCur(); if (!x) break; x.status = 'print'; save(); render(); window.scrollTo(0, 0); break; }
    case 'empSys': openLiveStock(); break;
    case 'empLog': ui.view = 'empLog'; render(); window.scrollTo(0, 0); break;
    case 'empLogNo': toast('This cycle was discarded.'); break;
    case 'empDraftSave': { const x = empCur(); if (!x) break; x.draftAt = new Date().toISOString(); save(); render(); toast('Draft saved.'); break; }
    case 'empDiscard': { const x = EMP().sessions.find(k => String(k.id) === String(v)); if (!x) break; const a = x.people.reduce((t, q) => t + q.codes.length, 0);
      if (!(await uiConfirm('Discard this employee cycle? Its ' + a + ' articles go back into the round' + (x.status !== 'print' ? ', and the values typed so far are removed' : '') + '. It stays in Count history as Discarded.', 'Discard', true))) { ui.pendUndo = null; break; }
      empDiscard(x); save(); ui.view = 'emp'; render(); window.scrollTo(0, 0); break; }
    case 'empFresh': { const E = EMP(), act = empActive(), st = empStat();
      if (!(await uiConfirm('Start a fresh round? Round ' + E.round.n + ' progress (' + st.counted + ' counted, ' + st.left + ' left) is cleared and all articles can be given out again.' + (act.length ? ' ' + act.length + ' open cycle' + (act.length === 1 ? ' is' : 's are') + ' discarded too.' : '') + ' Saved results are kept.', 'Start fresh', true))) { ui.pendUndo = null; break; }
      act.forEach(empDiscard); E.round = { n: E.round.n + 1, start: new Date().toISOString(), counted: {}, missed: {} }; save(); render(); toast('Round ' + E.round.n + ' started.'); break; }
    case 'empCancel': { const x = empCur(); if (!x) break; if (!(await uiConfirm('Cancel these sheets? Their articles go back into the round.', 'Cancel sheets', true))) break; x.status = 'void'; save(); ui.view = 'emp'; render(); window.scrollTo(0, 0); break; }
    case 'empTab': ui.empTab = +v; render(); window.scrollTo(0, 0); break;
    case 'empDates': { ui.empDates = ui.empDates || {}; ui.empDates[v] = 1; render(); break; }
    case 'empNext': { const x = empCur(); if (!x) break; save(); if ((ui.empTab || 0) < x.people.length - 1) { ui.empTab = (ui.empTab || 0) + 1; render(); window.scrollTo(0, 0); } else toast('Saved.'); break; }
    case 'empPhoto': { ui.empPhotoFor = +v; const pi = document.getElementById('empPhotoIn'); pi.value = ''; pi.click(); break; }
    case 'empPhotoDel': { const x = empCur(); if (!x) break; const [a1, b1] = v.split('|').map(Number); if (!(await uiConfirm('Remove this photo?', 'Remove', true))) break; x.people[a1].photos.splice(b1, 1); save(); render(); break; }
    case 'empZoom': { const src = paperSrc(v); if (!src) break; ui.sheet = { kind: 'empZoom', src }; renderSheet(); break; }
    case 'empMakeDraft': { const x = empCur(); if (!x) break; const blank = x.people.reduce((t, q) => t + q.codes.filter(c => !q.vals[c] || q.vals[c].cnt === '' || q.vals[c].cnt == null).length, 0);
      const noPh = x.people.filter(q => !q.photos.length).length;
      if (blank || noPh) { if (!(await uiConfirm([blank ? blank + ' article' + (blank === 1 ? ' has' : 's have') + ' no count yet (they will show as Not counted)' : '', noPh ? noPh + ' sheet' + (noPh === 1 ? ' has' : 's have') + ' no photo' : ''].filter(Boolean).join(' and ') + '. Make the draft anyway?', 'Make draft'))) break; }
      const c = empMakeDraft(x); ui.countId = c.id; ui.view = 'count'; render(); window.scrollTo(0, 0); toast('Draft ready. Check it like your own count, then save.'); break; }
    case 'empResult': ui.countExportId = v; openExport('empResult'); break;
    case 'pdfSignAll': { const k = t.dataset.k, on = !!t.checked; if (k === 'sign') S.pdfSign = on; else { S.pdfMgr = on; S.mgr.on = on; } Object.keys(REPORTS).filter(t => REPORTS[t].pdf).forEach(t => { rptPref(t)[k] = on; }); save(true); toast((k === 'sign' ? 'My signature box' : 'Manager signature box') + (on ? ' on' : ' off') + ' for all PDFs.'); break; }
    case 'countOpen': ui.countId = v; ui.view = 'count'; render(); window.scrollTo(0, 0); break;
    case 'countDelOld': { if (!(await uiConfirm('Delete this old random count?', 'Delete', true))) { ui.pendUndo = null; break; } S.counts = S.counts.filter(c => String(c.id) !== String(v)); save(); ui.view = 'countLog'; render(); break; }
    case 'taskLog': ui.drawer = false; ui.view = 'taskLog'; render(); window.scrollTo(0, 0); break;
    case 'dUpload': ui.drawer = false; renderDrawer(); ui.upload = null; ui.sheet = { kind: 'upload' }; renderSheet(); break;
    case 'dBulk': ui.drawer = false; renderDrawer(); document.querySelector('[data-a=bulkEdit]') ? document.querySelector('[data-a=bulkEdit]').click() : (ui.tab = 'home', render()); break;
    case 'dSite': ui.drawer = false; renderDrawer(); if (N) N.openSite(); break;
    case 'dMgr': ui.drawer = false; renderDrawer(); openLiveStock(); break;
    case 'dBackup': ui.drawer = false; renderDrawer(); if (S.sync.url) { ui.sheet = { kind: 'backups' }; loadBackups(); } else { ui.tab = 'set'; ui.setPage = 'cloud'; ui.view = null; render(); } break;
    case 'dData': ui.drawer = false; ui.tab = 'set'; ui.setPage = 'data'; ui.view = null; render(); window.scrollTo(0, 0); break;
    case 'taskOpen': if (v === 'count') { openCountCycle(); } else if (v === 'stock' || v === 'requests') { ui.upload = null; ui.sheet = { kind: 'upload' }; renderSheet(); } else if (v === 'backup') { if (S.sync.url) syncNow(false); else { ui.tab = 'set'; ui.setPage = 'cloud'; render(); } } break;
    case 'taskTog': { const d = today(); S.taskLog = S.taskLog || {}; S.taskLog[d] = S.taskLog[d] || {}; const cur = taskStatus(v, d);
      S.taskLog[d][v] = cur === 'done' ? { status: 'pending', at: new Date().toISOString(), by: S.me.name || '' } : { status: 'done', at: new Date().toISOString(), by: S.me.name || '' }; save(); render(); break; }
    case 'taskAdd': { const tt = String(ui.newTask || '').trim(); if (!tt) break; S.customTasks = S.customTasks || []; S.customTasks.push({ id: 'c' + nid(), title: tt }); ui.newTask = ''; save(); render(); break; }
    case 'taskDel': if (await uiConfirm('Delete this task? Its history stays.', 'Delete', true)) { S.customTasks = (S.customTasks || []).filter(x => x.id !== v); save(); render(); } break;
    case 'countDone': { const c = curCount(); if (!c || countLocked(c)) break; countLive(c); const sm = countSummary(c);
      if (!(await uiConfirm((sm.left ? sm.left + ' article' + (sm.left === 1 ? ' is' : 's are') + ' not counted yet. ' : '') + 'Save this count? System stock (' + (c.stockAt ? fmtDT(c.stockAt) : '–') + ') and counted values will be locked and cannot be changed.', 'Save & lock'))) break;
      c.items.forEach(i => { i.system = Number(i.system) || 0; i.physical = i.physical === '' || i.physical == null ? '' : String(i.physical); });
      c.status = 'done'; c.doneAt = new Date().toISOString(); c.savedBy = meTag(); S.taskLog = S.taskLog || {}; S.taskLog[c.date] = S.taskLog[c.date] || {}; S.taskLog[c.date].count = { status: 'done', at: c.doneAt, by: S.me.name || '' };
      if (c.mode === 'emp') { empLock(c); save(); render(); toast('Employee count saved and locked.'); ui.countExportId = c.id; openExport('empResult'); break; }
      save(); render(); toast('Count saved and locked.'); ui.countExportId = c.id; openExport('counts'); break; }
    case 'countNew': { const c = newCount(v); if (!c) { ui.view = 'countStart'; render(); break; } ui.countId = c.id; ui.view = 'count'; render(); window.scrollTo(0, 0); toast(v === 'blank' ? 'New count started with blank values.' : 'New count started with values copied.'); break; }
    case 'countStart': { const d = countDraft(); if (d) { ui.countId = d.id; ui.view = 'count'; render(); toast('Finish or clear the draft first.'); break; } ui.view = 'countStart'; render(); window.scrollTo(0, 0); break; }
    case 'countSys': { const c = curCount(); if (!c || countLocked(c)) break; openLiveStock(); break; }
    case 'cpKeep': case 'cpUndo': { const c = curCount(); if (!c || countLocked(c)) break; const i = c.items[+v]; if (!i) break; if (a === 'cpKeep') i.pendKeep = true; else delete i.pendKeep; save(); render(); break; }
    case 'cpRemove': { const c = curCount(); if (!c || countLocked(c)) break; const i = c.items[+v]; if (!i) break; c.items.splice(+v, 1); save(); render(); break; }
    case 'cpKeepAll': { const c = curCount(); if (!c || countLocked(c)) break; countPendOpen(c).forEach(x => x.i.pendKeep = true); save(); render(); break; }
    case 'cpRemoveAll': { const c = curCount(); if (!c || countLocked(c)) break; const PO = countPendOpen(c); if (!PO.length) break; if (!(await uiConfirm('Remove ' + PO.length + ' pending article' + (PO.length === 1 ? '' : 's') + ' from this count?', 'Remove', true))) { ui.pendUndo = null; break; } const del = new Set(PO.map(x => x.i)); c.items = c.items.filter(i => !del.has(i)); save(); render(); break; }
    case 'countDraftSave': { const c = curCount(); if (!c || countLocked(c)) break; countLive(c); c.draftAt = new Date().toISOString(); save(); render(); toast('Draft saved.'); break; }
    case 'countClear': { const c = curCount(); if (!c || countLocked(c)) break;
      if (c.mode === 'emp') { if (!(await uiConfirm('Go back to entering results? This draft is removed, but the values typed from the sheets are kept so you can fix them and make the draft again.', 'Back to entry'))) { ui.pendUndo = null; break; } const x = EMP().sessions.find(k => String(k.id) === String(c.emp)); S.counts = S.counts.filter(k => k !== c); if (x) { x.status = 'entry'; delete x.countId; ui.empId = x.id; } save(); ui.view = 'empSess'; render(); window.scrollTo(0, 0); break; }
      if (!(await uiConfirm('Clear this count cycle? All values entered in this draft will be removed.', 'Clear', true))) { ui.pendUndo = null; break; } S.counts = S.counts.filter(x => x !== c); ui.countId = null; save(); ui.view = 'countStart'; render(); window.scrollTo(0, 0); break; }
    case 'countExport': ui.countExportId = v; openExport('counts'); break;
    case 'rpRowF': { const p = rptPref('counts'); p.rowF = v; save(true); renderSheet(); break; }
    case 'rpRow': { const o = ui.sheet.rowOff = ui.sheet.rowOff || {}; if (o[v]) delete o[v]; else o[v] = 1; renderSheet(); break; }
    case 'rpRowAll': { const ty = ui.sheet.type, p = rptPref(ty), o = ui.sheet.rowOff = ui.sheet.rowOff || {}; reportDef(ty).all.filter(r => ty !== 'counts' || countFOk(p.rowF || 'all', r._res)).forEach(r => { if (v === 'on') delete o[r._k]; else o[r._k] = 1; }); renderSheet(); break; }
    case 'countExportAll': ui.countExportId = null; openExport('counts'); break;
    case 'varAdd': { const c = curCount(); if (!c || countLocked(c)) break; const it = c.items[+v]; it.variants = it.variants || []; if (!it.variants.length && it.physical !== '' && it.physical != null) it.variants.push({ qty: it.physical, mfd: '', exp: '' }); else it.variants.push({ qty: '', mfd: '', exp: '' }); syncPhysical(it); save(); render(); break; }
    case 'varDel': { const c = curCount(); if (!c || countLocked(c)) break; const [a1, k] = v.split('|').map(Number); const it = c.items[a1]; it.variants.splice(k, 1); syncPhysical(it); if (!it.variants.length) it.physical = ''; save(); render(); break; }
    case 'zwOpen': ui.drawer = false; ui.view = 'zwatch'; ui.zw = ui.zw || { f: 'all', q: '', open: null, sel: null }; render(); window.scrollTo(0, 0); break;
    case 'zwF': ui.zw.f = v; render(); break;
    case 'zwOpenRow': ui.zw.open = ui.zw.open === v ? null : v; { const b = document.getElementById('zwres'); if (b) b.innerHTML = zwResults(); } break;
    case 'zwSel': ui.zw.sel = ui.zw.sel ? null : []; ui.zw.open = null; render(); break;
    case 'zwPick': { const i = ui.zw.sel.indexOf(v); if (i < 0) ui.zw.sel.push(v); else ui.zw.sel.splice(i, 1); render(); } break;
    case 'zwBDel': { const L = ui.zw.sel.slice(); if (!L.length) break; if (!(await uiConfirm('Remove ' + L.length + ' article' + (L.length === 1 ? '' : 's') + ' from Zero-stock watch? Stock and requests are not changed.', 'Remove', true))) { ui.pendUndo = null; break; }
      S.zeroWatch = zwList().filter(w => !L.includes(w.code)); ui.zw.sel = null; save(); render(); } break;
    case 'zwDel': { if (!(await uiConfirm('Remove ' + itemName(v) + ' from Zero-stock watch?', 'Remove', true))) { ui.pendUndo = null; break; } S.zeroWatch = zwList().filter(w => w.code !== v); ui.zw.open = null; save(); render(); } break;
    case 'zwAck': { const w = zwList().find(x => x.code === v); if (!w) break; const r = zwRow(w); if (r.acked) delete w.ack; else w.ack = { qty: r.qty, at: new Date().toISOString(), by: S.me.name || '' }; save(); render(); } break;
    case 'zwNote': { const w = zwList().find(x => x.code === v); if (!w) break; const t = await uiPrompt('Note for ' + itemName(v) + ' (for example: comes only for Event orders)', w.note || '', 'Save'); if (t === null) break; w.note = t; save(); render(); } break;
    case 'zwExport': openExport('zwatch'); break;
    case 'zwAdd': ui.sheet = { kind: 'zwAdd', q: '', by: 'both', sel: [] }; renderSheet(); setTimeout(() => { const i = document.querySelector('[data-zwadd]'); if (i) i.focus(); }, 60); break;
    case 'zwBy': ui.sheet.by = v; ui.sheet.q = ''; renderSheet(); break;
    case 'zwAddPick': { const L = ui.sheet.sel, i = L.indexOf(v); if (i < 0) L.push(v); else L.splice(i, 1); const b = document.getElementById('zwaddres'); if (b) b.innerHTML = zwAddResults(); const sb = document.querySelector('[data-a="zwAddSave"]'); if (sb) { sb.disabled = !L.length; sb.textContent = L.length ? 'Add ' + L.length + ' article' + (L.length === 1 ? '' : 's') : 'Select articles'; } } break;
    case 'zwAddSave': { const L = ui.sheet.sel.filter(c => !zwList().some(w => w.code === c)); L.forEach(c => zwList().push({ code: c, name: (S.stock[c] || {}).name || '', uom: (S.stock[c] || {}).uom || '', at: new Date().toISOString(), by: S.me.name || '' }));
      ui.sheet = null; renderSheet(); save(); render(); toast(L.length + ' article' + (L.length === 1 ? '' : 's') + ' added to Zero-stock watch.'); } break;
    case 'zwToggle': { const i = zwList().findIndex(w => w.code === v); if (i >= 0) zwList().splice(i, 1); else zwList().push({ code: v, name: itemName(v), uom: itemUom(v), at: new Date().toISOString(), by: S.me.name || '' }); save(); toast(i >= 0 ? 'Removed from Zero-stock watch.' : 'Added to Zero-stock watch.'); { const b = document.getElementById('stkres'); if (b) b.innerHTML = stockResults(); } } break;
    case 'stockOpenCode': ui.view = 'stock'; ui.stk = { q: v, f: 'all', open: v }; render(); window.scrollTo(0, 0); break;
    case 'expOpen': ui.drawer = false; ui.view = 'expiry'; render(); window.scrollTo(0, 0); break;
    case 'expExport': openExport('expiry'); break;
    case 'expClear': { const [cid, idx, k] = v.split('|'); const c = (S.counts || []).find(x => String(x.id) === cid); if (c && await uiConfirm('Mark this batch as cleared (used, issued or removed)? It leaves the tracker.')) { c.items[+idx].variants[+k].cleared = true; save(); render(); } break; }
    case 'countRepick': { const c = (S.counts || []).find(x => String(x.id) === String(ui.countId)); if (c && c.items.every(i => i.physical === '' || i.physical == null)) { S.counts = S.counts.filter(x => x !== c); const n = todayCount(true); if (n) ui.countId = n.id; save(); render(); toast('New list picked.'); } break; }
    case 'tasksTog': S.uiPrefs = S.uiPrefs || {}; S.uiPrefs.tasksOpen = !S.uiPrefs.tasksOpen; writeLocal(); render(); break;
    case 'syncTap': if (S.sync.url) syncNow(false); else { ui.tab = 'set'; ui.setPage = 'cloud'; ui.view = null; render(); } break;
    case 'rpSet': rptPref(ui.sheet.type)[t.dataset.k] = v; save(true); renderSheet(); break;
    case 'rpTog': rptPref(ui.sheet.type)[t.dataset.k] = t.checked; save(true); renderSheet(); break;
    case 'rpCol': rptPref(ui.sheet.type).cols[t.dataset.k] = t.checked; save(true); renderSheet(); break;
    case 'rpMove': { const p = rptPref(ui.sheet.type), D = reportDef(ui.sheet.type); const keys = orderedCols(p, D).map(c => c[0]); const i = keys.indexOf(t.dataset.k), j = i + (+t.dataset.d);
      if (j >= 0 && j < keys.length) { [keys[i], keys[j]] = [keys[j], keys[i]]; p.order = keys; save(true); renderSheet(); } break; }
    case 'rpPdf': rpPdf(ui.sheet.type); break;
    case 'rpXlsx': rpXlsx(ui.sheet.type); break;
    case 'queueToggle': S.queue = t.checked; save(true); if (ui.sheet && ui.sheet.kind === 'start') renderSheet(); else render(); break;
    case 'queuePend': S.queuePend = t.checked; save(true); if (ui.sheet && ui.sheet.kind === 'start') renderSheet(); else render(); break;
    case 'autoSubToggle': S.autoSubmit = t.checked; save(true); break;
    case 'startFill': { const s = ui.sheet; if (slipProblem(s.slip) || !validRcv(s.rcv)) break;
      if (!S.stores[s.store]) S.stores[s.store] = { rcv: s.rcv, rname: '' }; else if (!S.stores[s.store].rcv) S.stores[s.store].rcv = s.rcv;
      const ids = s.lineIds.filter(id => !s.off[id]);
      if (!ids.length) { toast('Select at least one article.'); break; }
      for (const id of ids) { if (s.qty[id] == null) continue; const q = parseFloat(s.qty[id]); const l = S.lines.find(x => x.id === id); if (!(q > 0)) { toast('Qty must be above 0 for ' + l.code); return; } l.qty = q; }
      save(true); ui.sheet = null; renderSheet(); startJob(s.store, s.slip, s.rcv, ids, s.adv ? { remark: String(s.advRemark || '').trim() } : null); break; }
    case 'stOn': if (t.checked) delete ui.sheet.off[v]; else ui.sheet.off[v] = 1; renderSheet(); break;
    case 'stAdd': { const s = ui.sheet; const code = String(s.addCode || '').trim().toUpperCase(), q = parseFloat(s.addQty);
      if (!code || !(q > 0)) { toast('Enter item code and qty.'); break; }
      const base = S.lines.find(l => l.id === s.lineIds[0]);
      const nl = { id: nid(), req: base ? base.req : s.req || 'MANUAL', store: s.store, date: base ? base.date : today(), code, qty: q, rcv: base ? base.rcv : '', slip: base ? base.slip : '', src: 'new', earlier: '', status: 'waiting', issued: [] };
      S.lines.push(nl); s.lineIds.push(nl.id); s.addCode = ''; s.addQty = ''; save(true); renderSheet(); if (!S.stock[code]) toast(code + ' is not in the stock sheet; CUIMS will check it.'); break; }
    case 'upPick': ui.upload = { kind: v }; document.getElementById('fileIn').click(); break;
    case 'uploadCancel': ui.upload = null; renderSheet(); break;
    case 'uploadOk': { const u = ui.upload; if (u && u.kind === 'stock' && u.diff && Object.keys(S.stock).length) { const D = u.diff;
        const msg = u.stockMode === 'fresh' ? 'Replace the whole stock list with this report? ' + u.result.count + ' items · ' + D.up.length + ' qty up · ' + D.down.length + ' qty down · ' + D.fresh.length + ' new · ' + D.gone.length + ' removed (not in file).'
          : 'Update closing qty only? Linked by ' + ({ code: 'item code', name: 'exact item name', both: 'code, then exact name' }[D.linkBy || 'both']) + '. ' + (D.code.length + D.name.length) + ' items matched (' + D.code.length + ' by code, ' + D.name.length + ' by name) · ' + D.up.length + ' up · ' + D.down.length + ' down · ' + D.same.length + ' same' + (u.addNew ? ' · ' + D.fresh.length + ' new added' : ' · ' + D.fresh.length + ' new skipped') + ' · ' + D.gone.length + ' not in file kept as they are.';
        if (!(await uiConfirm(msg, u.stockMode === 'fresh' ? 'Replace stock' : 'Update closing'))) { ui.pendUndo = null; break; } }
      doImport(); break; }
    case 'regType': ui.reg.type = v; render(); break;
    case 'regItems': ui.reg.items = t.checked; break;
    case 'pdfIssue': openExport('issue'); break;
    case 'pdfReturn': openExport('ret'); break;
    case 'newManual': {
      const R = requests().filter(r => r.lines.some(l => l.status === 'waiting'));
      PICKS.manReq = { title: 'Manual slip for which request?', search: true, opts: [['__free', 'Request not in the app (free entry)', 'type everything by hand']].concat(sortBy(R, 'reqdate', r => ({ req: r.req, store: r.store, date: r.date })).map(r => [r.req, r.req + ' · ' + r.store, fmtShort(r.date) + ' · ' + r.lines.filter(l => l.status === 'waiting').length + ' pending'])), val: '',
        set: x => { if (x === '__free') { const b = document.createElement('button'); b.dataset.a = 'newManualFree'; document.body.appendChild(b); b.click(); b.remove(); } else { const b = document.createElement('button'); b.dataset.a = 'mslips'; b.dataset.v = x; document.body.appendChild(b); b.click(); b.remove(); } } };
      ui.picker = { id: 'manReq', q: '' }; renderPicker(); break; }
    case 'newManualFree': ui.form = { _new: true, req: nextReqNo(), date: today(), store: '', rcv: '', rname: '', byName: S.me.name || '', byEmp: S.me.emp || '', total: '', status: 'pending', slips: [{ slip: nextSlip(), serial: '', date: today(), time: timeNow(), count: '' }] }; ui.sheet = { kind: 'manReq' }; renderSheet(); break;
    case 'manReqEdit': { const m = (S.manReqs || {})[v]; if (!m) break; const sl = reqSlips(v).map(e => ({ id: e.id, slip: e.slip, serial: e.serial || '', date: entryDate(e), time: entryTime(e), count: String(entryCount(e, v)), byName: (e.by || {}).name || '', byEmp: (e.by || {}).emp || '' }));
      ui.form = Object.assign({ _new: false }, JSON.parse(JSON.stringify(m)), { slips: sl.length ? sl : [{ slip: nextSlip(), serial: '', date: today(), time: timeNow(), count: '' }], total: m.total ? String(m.total) : '' }); ui.sheet = { kind: 'manReq' }; renderSheet(); break; }
    case 'manReqToggle': { const m = (S.manReqs || {})[v]; if (!m) break; const to = m.status === 'done' ? 'pending' : 'done'; if (!(await uiConfirm('Mark request ' + v + ' as ' + (to === 'done' ? 'completed' : 'pending') + '?', to === 'done' ? 'Mark completed' : 'Mark pending'))) break; m.status = to; save(); render(); break; }
    case 'mrAdd': { const f = ui.form; const last = f.slips[f.slips.length - 1]; let nx = ''; const mm = last && String(last.slip).match(/^(.*?)(\d+)$/); if (mm) nx = mm[1] + String(parseInt(mm[2], 10) + 1).padStart(mm[2].length, '0'); f.slips.push({ slip: nx || nextSlip(), serial: '', date: last ? last.date : today(), time: timeNow(), count: '', byName: last && last.byName != null ? last.byName : f.byName, byEmp: last && last.byEmp != null ? last.byEmp : f.byEmp }); renderSheet(); break; }
    case 'mrDel': ui.form.slips.splice(+v, 1); renderSheet(); break;
    case 'mrSt': ui.form.status = v; renderSheet(); break;
    case 'mrRemove': { const f = ui.form; if (!(await uiConfirm('Delete manual request ' + f.req + ' and its ' + f.slips.length + ' slip(s)?', 'Delete', true))) break; undoArm('delEntry'); S.entries = S.entries.filter(e => !(e.kind === 'manual' && !e.items.length && entryHasReq(e, f.req))); delete S.manReqs[f.req]; save(); ui.sheet = null; renderSheet(); render(); break; }
    case 'mrSave': { const f = ui.form; const req = String(f.req || '').trim();
      if (!req) { toast('Enter the Request No.'); break; } if (!f.store) { toast('Choose the store.'); break; } if (f.rcv && !validRcv(f.rcv)) { toast('Issued to must be 6 digits.'); break; }
      if (f._new && (S.lines.some(l => l.req === req) || (S.manReqs || {})[req])) { toast('Request No ' + req + ' already exists.'); break; }
      const keep = new Set(f.slips.filter(x => x.id).map(x => String(x.id)));
      const used = allSlips(); const mine = new Set(S.entries.filter(e => keep.has(String(e.id))).map(e => String(e.slip).toUpperCase()));
      const seen = {}; let bad = '';
      f.slips.forEach((x, i) => { const sl = String(x.slip || '').trim().toUpperCase(); if (!sl) bad = bad || 'Slip ' + (i + 1) + ' needs a Slip No.'; else if (!SLIP_RE.test(sl)) bad = bad || 'Slip ' + sl + ' is not valid.'; else if (seen[sl] || (used.has(sl) && !mine.has(sl))) bad = bad || 'Slip ' + sl + ' is already used.'; seen[sl] = 1; });
      if (bad) { toast(bad); break; }
      if (!(await uiConfirm('Save request ' + req + ' with ' + f.slips.length + ' slip' + (f.slips.length > 1 ? 's' : '') + ' as ' + (f.status === 'done' ? 'Completed' : 'Pending') + '?', 'Save'))) break;
      undoArm('saveEntry');
      S.manReqs = S.manReqs || {};
      S.manReqs[req] = { req, store: f.store, date: f.date || today(), rcv: f.rcv || '', rname: f.rname || '', total: parseInt(f.total, 10) || 0, status: f.status === 'done' ? 'done' : 'pending', by: { name: f.byName || '', emp: f.byEmp || '' } };
      S.entries = S.entries.filter(e => !(e.kind === 'manual' && !e.items.length && entryHasReq(e, req)));
      f.slips.forEach(x => { const d = x.date || today(), tm = x.time || timeNow();
        S.entries.push({ id: x.id || nid(), slip: String(x.slip).trim().toUpperCase(), serial: String(x.serial || '').trim(), store: f.store, rcv: f.rcv || '', rname: f.rname || '', at: new Date(d + 'T' + tm).toISOString(), date: d, time: tm, by: { name: (x.byName != null ? x.byName : f.byName) || '', emp: (x.byEmp != null ? x.byEmp : f.byEmp) || '' }, kind: 'manual', reqs: req, count: parseInt(x.count, 10) || 0, remarks: '', items: [] }); });
      save(); ui.sheet = null; renderSheet(); render(); toast('Request ' + req + ' saved.'); break; }
    case 'newManualFreeOld': ui.form = { _new: true, kind: 'manual', slip: '', serial: '', store: '', rcv: '', rname: '', date: ui.reg.date, time: timeNow(), reqs: '', remarks: '', byName: S.me.name, byEmp: S.me.emp, items: [blankItem()] }; ui.sheet = { kind: 'entry' }; renderSheet(); break;
    case 'editEntry': { const e = S.entries.find(x => String(x.id) === v); ui.form = Object.assign(JSON.parse(JSON.stringify(e)), { date: entryDate(e), time: entryTime(e), reqs: e.reqs || [...new Set(e.items.map(i => i.req).filter(Boolean))].join(', '), byName: (e.by || {}).name || '', byEmp: (e.by || {}).emp || '' }); ui.sheet = { kind: 'entry' }; renderSheet(); break; }
    case 'saveEntry': { const f = ui.form; const items = cleanItems(f.items);
      if (!f.slip.trim() || !f.store.trim() || !validRcv(f.rcv)) { toast('Slip No, store and a 6-digit receiver are needed.'); break; }
      const clash = S.entries.find(e => e.id !== f.id && String(e.slip).toUpperCase() === f.slip.trim().toUpperCase());
      if (clash && !await uiConfirm('Slip ' + f.slip + ' is already used for ' + clash.store + '. Save anyway?')) break;
      if (!items.length) { toast('Add at least one item with code and qty.'); break; }
      const rec = { id: f.id || nid(), slip: f.slip.trim().toUpperCase(), serial: (f.serial || '').trim(), store: f.store.trim().toUpperCase(), rcv: f.rcv, rname: (f.rname || '').trim(), at: f.at || new Date(f.date + 'T' + (f.time || '00:00')).toISOString(), date: f.date, time: f.time, reqs: (f.reqs || '').trim(), remarks: (f.remarks || '').trim(), by: { name: f.byName.trim(), emp: f.byEmp.trim() }, kind: f.kind || 'manual', items };
      if (rec.rname) { S.rnames = S.rnames || {}; S.rnames[rec.rcv] = rec.rname; }
      const i = S.entries.findIndex(e => e.id === rec.id); if (i >= 0) S.entries[i] = rec; else S.entries.push(rec);
      save(); ui.sheet = null; renderSheet(); render(); toast('Entry saved.'); break; }
    case 'delEntry': if (await uiConfirm('Delete this register entry? Stock and pending are not changed.', 'Delete', true)) { S.entries = S.entries.filter(e => e.id !== ui.form.id); save(); ui.sheet = null; renderSheet(); render(); } break;
    case 'newReturn': ui.form = { mode: 'return', single: true, date: today(), groups: [], act: 0, q: '', paste: '' }; ui.sheet = { kind: 'batch' }; renderSheet(); break;
    case 'newReturnOld': ui.form = { _new: true, _autoNo: true, no: nextReturnNo(today()), against: '1111', store: '', by: '', byName: '', recvDate: today(), date: ui.reg.date, time: timeNow(), serial: '', remarks: '', ebName: S.me.name, ebEmp: S.me.emp, items: [blankItem()] }; ui.sheet = { kind: 'return' }; renderSheet(); break;
    case 'editReturn': { const r = S.returns.find(x => String(x.id) === v); ui.form = Object.assign(JSON.parse(JSON.stringify(r)), { ebName: (r.enteredBy || {}).name || '', ebEmp: (r.enteredBy || {}).emp || '' }); ui.sheet = { kind: 'return' }; renderSheet(); break; }
    case 'saveReturn': case 'saveReturnCuims': { const f = ui.form; const items = cleanItems(f.items);
      if (!f.store.trim() || !validRcv(f.by)) { toast('Store and a 6-digit "Returned by" are needed.'); break; }
      if (!items.length) { toast('Add at least one item with code and qty.'); break; }
      if (S.returns.some(x => String(x.no).toUpperCase() === String(f.no || '').trim().toUpperCase() && x.id !== f.id)) { toast('Return No ' + f.no + ' is already used. Next free: ' + nextReturnNo(f.recvDate || today()) + '.'); break; }
      const rec = { id: f.id || nid(), no: f.no.trim().toUpperCase(), against: (f.against || '1111').trim(), store: f.store.trim().toUpperCase(), by: f.by, byName: (f.byName || '').trim() || rcvName(f.by), date: f.date, recvDate: f.recvDate || f.date, time: f.time, serial: (f.serial || '').trim(), remarks: (f.remarks || '').trim(), enteredBy: { name: f.ebName.trim(), emp: f.ebEmp.trim() }, items };
      if (rec.byName) { S.rnames = S.rnames || {}; S.rnames[rec.by] = rec.byName; }
      const i = S.returns.findIndex(x => x.id === rec.id); if (i >= 0) S.returns[i] = rec; else S.returns.push(rec);
      save(); ui.sheet = null; renderSheet(); render(); if (a === 'saveReturnCuims') startReturnJob(rec); else toast('Return saved.'); break; }
    case 'delReturn': if (await uiConfirm('Delete this return?', 'Delete', true)) { S.returns = S.returns.filter(x => x.id !== ui.form.id); save(); ui.sheet = null; renderSheet(); render(); } break;
    case 'rmItem': ui.form.items.splice(+v, 1); if (!ui.form.items.length) ui.form.items.push(blankItem()); renderSheet(); break;
    case 'addItem': ui.form.items.push(blankItem()); renderSheet(); break;
    case 'sType': ui.search.type = v; render(); break;
    case 'sOpen': ui.search.open = ui.search.open === v ? null : v; render(); break;
    case 'expSearch': openExport('search'); break;
    case 'expSearchOld': { const res = searchRecords(); const rows = []; res.forEach(x => x.items.forEach(i => rows.push({ Type: x.type, Date: x.date ? fmtLong(x.date) : '', Time: x.time || '', 'Slip / Return No': x.no, 'Serial No': x.serial, Store: x.store, 'Issued to / Returned by': x.who, 'Request / Against': x.reqs, 'Item code': i.code, Item: i.name || itemName(i.code), Qty: Number(i.qty), UOM: i.uom || '', 'Item remark': i.remark || '', 'Entered by': x.by.name || '', 'Emp code': x.by.emp || '' })));
      saveWb([['Search results', rows]], 'Search-' + today() + '.xlsx'); break; }
    case 'mgrToggle': S.mgr.on = t.checked; save(); render(); break;
    case 'rmStore': if (await uiConfirm('Remove ' + v + ' from your store list? Records stay.')) { delete S.stores[v]; save(); render(); } break;
    case 'addStore': { const el = document.getElementById('newStore'); const nm = (el.value || '').trim().toUpperCase(); if (!nm) break; if (!S.stores[nm]) S.stores[nm] = { rcv: '', rname: '' }; save(); render(); break; }
    case 'syncAuto': S.sync.auto = t.checked; save(true); break;
    case 'syncNow': syncNow(false); break;
    case 'restore': restoreNow(); break;
    case 'backups': ui.sheet = { kind: 'backups' }; loadBackups(); break;
    case 'openUrl': if (N) N.openUrl(v); else window.open(v); break;
    case 'bkSave': { const note = ui.sheet.note || ''; await syncNow(false, 'manual', note); ui.sheet.note = ''; loadBackups(); break; }
    case 'bkRestore': { if (!await uiConfirm('Replace ALL data on this phone with this backup? (Tip: save a backup of the current data first.)')) break;
      try { const j = await apiGet('action=get&id=' + encodeURIComponent(v)); const url = S.sync.url; S = Object.assign(blank(), JSON.parse(j.backup)); S.sync.url = url; save(true); ui.sheet = null; renderSheet(); render(); toast('Backup restored.'); } catch (e) { toast('Restore failed: ' + e.message); } break; }
    case 'bkKeep': try { await apiPost({ action: 'meta', id: v, keep: t.dataset.k === '1' }); loadBackups(); } catch (e) { toast('Failed: ' + e.message); } break;
    case 'bkDel': if (await uiConfirm('Delete this backup copy from Drive?', 'Delete', true)) { try { await apiPost({ action: 'delete', id: v }); loadBackups(); } catch (e) { toast('Failed: ' + e.message); } } break;
    case 'bkNote': { const b = (ui.sheet.items || []).find(x => x.id === v); ui.sheet.editing = v; ui.sheet.rename = b ? b.note : ''; renderSheet(); break; }
    case 'bkNoteCancel': ui.sheet.editing = null; renderSheet(); break;
    case 'bkNoteSave': try { await apiPost({ action: 'meta', id: v, note: ui.sheet.rename || '' }); ui.sheet.editing = null; loadBackups(); } catch (e) { toast('Failed: ' + e.message); } break;
    case 'expRequests': openExport('requests'); break;
    case 'expEntries': openExport('entries'); break;
    case 'expItems': openExport('items'); break;
    case 'expStock': openExport('stock'); break;
    case 'expReturns': openExport('returns'); break;
    case 'expAll': saveWb([['Requests register', rowsRequests()], ['Request lines', rowsAllLines()], ['Entries log', rowsEntries()], ['Entry items', rowsItems()], ['Pending', rowsPending()], ['Returns', rowsReturns()], ['Stock now', rowsStock()]], 'JV-Stock-Issue-backup-' + today() + '.xlsx'); break;
    case 'lockToggle': if (N) { N.setLock(t.checked); INFO.lock = t.checked; toast(t.checked ? 'Lock on. Fingerprint or PIN needed when opening.' : 'Lock off.'); } break;
    case 'checkUpdate': checkUpdate(true); break;
    case 'installUpdate': if (S.updateInfo && S.updateInfo.url && N) N.installUpdate(S.updateInfo.url); break;
    case 'mode': if (N && INFO.mode !== v) { if (await uiConfirm(v === 'bundled' ? 'Use the built-in screens from the installed APK? (rollback)' : 'Use the latest screens from GitHub?')) N.setMode(v); } break;
    case 'wipe': if (await uiConfirm('Delete ALL requests, entries, returns, stock and settings on this phone?') && await uiConfirm('Really delete everything? Back up first if unsure.')) { const url = S.sync.url; S = blank(); S.sync.url = url; save(true); render(); toast('All data cleared.'); } break;
  }
  } finally { if (_busy) setTimeout(() => loader(false), /CUIMS/.test(_busy) ? 1400 : 0); }
});

document.addEventListener('input', ev => {
  const el = ev.target;
  if (el.dataset.in === 'slip' || el.dataset.in === 'rcv') { const k = focusKey(el); ui.sheet[el.dataset.in] = el.dataset.in === 'slip' ? el.value.trim().toUpperCase() : el.value.toUpperCase().replace(/[^A-Z0-9]/g, ''); renderSheet(); refocus(k); return; }
  if (el.dataset.in === 'q') { ui.search.q = el.value; clearTimeout(ui.sT); ui.sT = setTimeout(() => { const box = document.getElementById('sres'); if (box) box.innerHTML = sResults(searchRecords()); }, 120); return; }
  if (el.dataset.pkq) { ui.picker.q = el.value; const box = document.querySelector('#picker .pklist'); if (box) box.innerHTML = pickList(); return; }
  if (el.dataset.bk) { ui.sheet[el.dataset.bk] = el.value; return; }
  if (el.dataset.cr) { const [w, k] = el.dataset.cr.split('|'); ui.cred = ui.cred || {}; ui.cred[w] = ui.cred[w] || {}; ui.cred[w][k] = el.value; return; }
  if (el.dataset.corr != null) { ui.form.rows[+el.dataset.corr].final = el.value; return; }
  if (el.dataset.cadd) { ui.form[el.dataset.cadd === 'code' ? 'addCode' : 'addQty'] = el.value; return; }
  if (el.dataset.cons) { ui.cons[el.dataset.cons] = el.value; render(); return; }
  if (el.dataset.pdfall) { S.pdfStore = el.value; S.me.storeName = el.value; Object.keys(REPORTS).filter(t => REPORTS[t].pdf).forEach(t => { rptPref(t).sub = el.value; }); EMP().store = el.value; save(true); return; }
  if (el.dataset.pdfhead) { const t = el.dataset.pdfhead; rptPref(t).title = el.value; if (t === 'empSheet' || t === 'empResult') { EMP().title = el.value; } save(true); return; }
  if (el.dataset.emp) { const E = EMP(), k = el.dataset.emp; E[k] = el.value; if (k === 'title' || k === 'store') ['empSheet', 'empResult'].forEach(t => { const pp = rptPref(t); pp[k === 'title' ? 'title' : 'sub'] = el.value; }); save(true); if (k === 'per') { clearTimeout(ui.kT); ui.kT = setTimeout(() => { const y = window.scrollY, f = focusKey(el); render(); window.scrollTo(0, y); refocus(f); }, 500); } return; }
  if (el.dataset.empnew) { ui.empNew = ui.empNew || {}; ui.empNew[el.dataset.empnew] = el.value; return; }
  if (el.dataset.ign) { ui.ign.v = el.value; clearTimeout(ui.kT); ui.kT = setTimeout(() => { const b = document.getElementById('ignprev'); if (b) b.innerHTML = ignPreview(); }, 150); return; }
  if (el.dataset.empc) { const x = empCur(); if (!x) return; const parts = el.dataset.empc.split('|'), pi = +parts[0], f = parts[parts.length - 1], code = parts.slice(1, -1).join('|'); const q = x.people[pi]; q.vals[code] = q.vals[code] || {}; q.vals[code][f] = el.value; save(true); return; }
  if (el.dataset.empv) { const x = empCur(); if (!x) return; const [pi, f] = el.dataset.empv.split('|'); x.people[+pi][f] = el.value; save(true); return; }
  if (el.dataset.zw) { ui.zw.q = el.value; clearTimeout(ui.kT); ui.kT = setTimeout(() => { const b = document.getElementById('zwres'); if (b) b.innerHTML = zwResults(); }, 120); return; }
  if (el.dataset.zwadd) { ui.sheet.q = el.value; clearTimeout(ui.kT); ui.kT = setTimeout(() => { const b = document.getElementById('zwaddres'); if (b) b.innerHTML = zwAddResults(); }, 120); return; }
  if (el.dataset.stk) { ui.stk.q = el.value; clearTimeout(ui.kT); ui.kT = setTimeout(() => { const b = document.getElementById('stkres'); if (b) b.innerHTML = stockResults(); }, 120); return; }
  if (el.dataset.retno) { ui.form._autoNo = false; ui.form.no = el.value.toUpperCase(); const sp = el.parentNode.querySelector('.rcvname'); if (sp) { const d = S.returns.some(x => String(x.no).toUpperCase() === el.value.trim().toUpperCase() && x.id !== ui.form.id); sp.className = 'rcvname ' + (d ? 'new' : 'ok'); sp.textContent = d ? 'Already used. Next free: ' + nextReturnNo(ui.form.recvDate || today()) : RET_RE.test(el.value.trim()) ? 'Free to use' : 'Format R-DDMM-NN'; } return; }
  if (el.dataset.f === 'recvDate' && ui.sheet && ui.sheet.kind === 'return') { ui.form.recvDate = el.value; renderSheet(); return; }
  if (el.dataset.clq) { ui.clq = el.value; clearTimeout(ui.clT); ui.clT = setTimeout(() => { const b = document.getElementById('clres'); if (b) b.innerHTML = clResults(); }, 120); return; }
  if (el.dataset.cperday) { S.countPerDay = el.value ? Math.max(1, parseInt(el.value, 10) || 0) : 0; save(true); return; }
  if (el.dataset.lk) { const k = el.dataset.lk, f = ui.form; f[k] = el.value; if (k === 'rFrom' || k === 'rTo') { f.map = {}; if (k === 'rFrom' && f.rTo < f.rFrom) f.rTo = f.rFrom; f.cFrom = f.rFrom; f.cTo = addDays(f.rTo, 1); } if (k === 'cFrom' && f.cTo < f.cFrom) f.cTo = f.cFrom; renderSheet(); return; }
  if (el.dataset.lks) { ui.form.map = ui.form.map || {}; ui.form.map[el.dataset.lks] = el.value; const b = document.querySelector('[data-a="lkRead"]'); if (b) { const n = Object.values(ui.form.map).join(',').split(/[^\d]+/).filter(x => /^\d{3,9}$/.test(x)).length; b.disabled = !n; b.textContent = 'Read ' + n + ' serial' + (n === 1 ? '' : 's') + ' on CUIMS'; } return; }
  if (el.dataset.rbf) { ui.form[el.dataset.rbf] = el.value; if (el.dataset.rbf === 'recvDate') renderSheet(); return; }
  if (el.dataset.rb) { const [g, k] = el.dataset.rb.split('|'); ui.form.groups[+g][k] = k === 'by' ? el.value.toUpperCase().replace(/[^A-Z0-9]/g, '') : el.value; return; }
  if (el.dataset.rbr) { const [g, r, k] = el.dataset.rbr.split('|'); ui.form.groups[+g].rows[+r][k] = k === 'code' ? el.value.toUpperCase() : el.value;
    if (k === 'code') { const c = el.value.trim().toUpperCase(), sp = el.parentNode.querySelector('.rbname'); if (sp) sp.textContent = c ? (S.stock[c] ? itemName(c) + ' · ' + itemUom(c) : 'code not in stock list') : ''; } return; }
  if (el.dataset.mg) { const k = el.dataset.mg; ui.mg[k] = el.value; ui.mg.sel = {}; if (k === 'q') { clearTimeout(ui.mgT); ui.mgT = setTimeout(() => { const b = document.getElementById('mgres'); if (b) b.innerHTML = mgResults(); }, 120); } else render(); return; }
  if (el.dataset.artsday) { ui.arts.dayPick = el.value || today(); ui.arts.sel = {}; render(); return; }
  if (el.dataset.arts) { ui.arts.q = el.value; clearTimeout(ui.aT); ui.aT = setTimeout(() => { const b = document.getElementById('artsres'); if (b) b.innerHTML = artsResults(); }, 120); return; }
  if (el.dataset.asc) { autoStockCfg()[el.dataset.asc] = el.value.trim(); save(true); return; }
  if (el.dataset.mr) { const k = el.dataset.mr; ui.form[k] = k === 'rcv' ? el.value.toUpperCase().replace(/[^A-Z0-9]/g, '') : el.value; return; }
  if (el.dataset.ms) { const [i, k] = el.dataset.ms.split('|'); ui.form.slips[+i][k] = k === 'slip' ? el.value.toUpperCase() : el.value; return; }
  if (el.dataset.tk) { ui.newTask = el.value; return; }
  if (el.dataset.nr) { const k = el.dataset.nr; ui.form[k] = k === 'rcv' ? el.value.toUpperCase().replace(/[^A-Z0-9]/g, '') : el.value;
    if (k === 'store') { const d = (S.stores[el.value] || {}).rcv; if (d && !ui.form.rcv) ui.form.rcv = d; }
    if (k === 'q') { const box = document.getElementById('nrhits'); if (box) box.innerHTML = nrHits(); return; }
    if (k === 'req' || k === 'slip') { const fk = focusKey(el); renderSheet(); refocus(fk); } return; }
  if (el.dataset.bt) { const k = el.dataset.bt; ui.form[k] = el.value; if (k === 'date' && ui.form.mode === 'return') { renderSheet(); return; } if (k === 'q') { const box = document.getElementById('bthits'); if (box) box.innerHTML = batchHits(ui.form.act); } return; }
  if (el.dataset.bg) { const [gi, k] = el.dataset.bg.split('|'); if (k === 'req') ui.form.groups[+gi]._auto = false; ui.form.groups[+gi][k] = k === 'rcv' ? el.value.toUpperCase().replace(/[^A-Z0-9]/g, '') : k === 'slip' ? el.value.toUpperCase() : el.value; return; }
  if (el.dataset.bq) { const [gi, ii] = el.dataset.bq.split('|').map(Number); ui.form.groups[gi].items[ii].qty = el.value; return; }
  if (el.dataset.nrq != null) { ui.form.items[+el.dataset.nrq].qty = el.value; const b = document.querySelector('[data-a=nrSave]'); if (b) { const f = ui.form; b.disabled = !(f.store && f.req && f.items.length && f.items.every(x => parseFloat(x.qty) > 0)); } return; }
  if (el.dataset.var) { const c = curCount(); if (c && !countLocked(c)) { const [a1, k, f] = el.dataset.var.split('|'); const it = c.items[+a1]; it.variants[+k][f] = el.value; syncPhysical(it); save(true); } return; }
  if (el.dataset.expdays) { const n = parseInt(el.value, 10); if (n > 0) { S.expiryDays = n; save(true); } return; }
  if (el.dataset.cx) { countExcl()[el.dataset.cx] = el.value.split(',').map(x => x.trim()).filter(Boolean); save(true); return; }
  if (el.dataset.cnt != null) { const c = (S.counts || []).find(x => String(x.id) === String(ui.countId)); if (c && !countLocked(c)) { c.items[+el.dataset.cnt].physical = el.value; save(true); } return; }
  if (el.dataset.rp) { rptPref(ui.sheet.type)[el.dataset.rp] = el.value; save(true); if (el.tagName === 'SELECT') renderSheet(); return; }
  if (el.dataset.crop) { ui.sheet.zoom = parseFloat(el.value); const im = document.querySelector('#cropBox img'); if (im) { const V = 280, c = ui.sheet, base = Math.max(V / c.img.width, V / c.img.height) * c.zoom, dw = c.img.width * base, dh = c.img.height * base; im.style.width = dw + 'px'; im.style.height = dh + 'px'; im.style.left = ((V - dw) / 2 + c.x) + 'px'; im.style.top = ((V - dh) / 2 + c.y) + 'px'; } return; }
  if (el.dataset.url) { ui[el.dataset.url === 'emp' ? 'urlEmp' : 'urlMgr'] = el.value.trim(); return; }
  if (el.dataset.adv) { ui.sheet.advRemark = el.value; return; }
  if (el.dataset.stq) { ui.sheet.qty[el.dataset.stq] = el.value; return; }
  if (el.dataset.stadd) { ui.sheet[el.dataset.stadd === 'code' ? 'addCode' : 'addQty'] = el.value; return; }
  if (el.dataset.f) { ui.form[el.dataset.f] = el.value; return; }
  if (el.dataset.br) { const [i, f] = el.dataset.br.split('|'); ui.form.rows[+i][f] = f === 'slip' ? el.value.trim().toUpperCase() : f === 'rcv' ? el.value.toUpperCase().replace(/[^A-Z0-9]/g, '') : el.value; return; }
  if (el.dataset.bulkstart) { ui.form.start = el.value; return; }
  if (el.dataset.bulkdate) { ui.form.allDate = el.value; return; }
  if (el.dataset.it) { const [i, f] = el.dataset.it.split('|'); ui.form.items[+i][f] = el.value; return; }
});
document.addEventListener('change', async ev => {
  const el = ev.target;
  if (ui.locked && (el.dataset.set || el.dataset.storeRcv || el.dataset.storeName)) { render(); askUnlock(); return; }
  if (el.id === 'empPhotoIn') {
    const f = el.files[0]; el.value = ''; const x = empCur(), pi = ui.empPhotoFor; if (!f || !x || pi == null || !x.people[pi]) return;
    loader(true, 'Saving the sheet photo');
    const img = new Image(), fr = new FileReader();
    fr.onload = () => { img.onload = () => { try {
      const M = 2000, k = Math.min(1, M / Math.max(img.width, img.height)); const c = document.createElement('canvas'); c.width = Math.round(img.width * k); c.height = Math.round(img.height * k);
      const g = c.getContext('2d'); g.fillStyle = '#fff'; g.fillRect(0, 0, c.width, c.height); g.drawImage(img, 0, 0, c.width, c.height);
      const url = c.toDataURL('image/jpeg', 0.85), id = 'e' + Date.now() + Math.floor(Math.random() * 1000);
      let ok = false; if (N && N.paperSave) ok = N.paperSave(id, url.split(',')[1]);
      if (!ok) { S.paperImg = S.paperImg || {}; S.paperImg[id] = url; }
      PAPER_MEM[id] = url; x.people[pi].photos.push({ id, at: new Date().toISOString() }); save(); render();
    } finally { loader(false); } }; img.onerror = () => { loader(false); toast('Could not read this image.'); }; img.src = fr.result; };
    fr.readAsDataURL(f); return;
  }
  if (el.id === 'paperIn') {
    const f = el.files[0]; el.value = ''; const req = ui.paperFor; if (!f || !req) return;
    loader(true, 'Saving the paper photo');
    const img = new Image(), fr = new FileReader();
    fr.onload = () => { img.onload = () => { try {
      const M = 2000, k = Math.min(1, M / Math.max(img.width, img.height)); const c = document.createElement('canvas'); c.width = Math.round(img.width * k); c.height = Math.round(img.height * k);
      const g = c.getContext('2d'); g.fillStyle = '#fff'; g.fillRect(0, 0, c.width, c.height); g.drawImage(img, 0, 0, c.width, c.height);
      const url = c.toDataURL('image/jpeg', 0.85), id = 'p' + Date.now() + Math.floor(Math.random() * 1000);
      let ok = false; if (N && N.paperSave) ok = N.paperSave(id, url.split(',')[1]);
      if (!ok) { S.paperImg = S.paperImg || {}; S.paperImg[id] = url; }
      PAPER_MEM[id] = url; S.paper = S.paper || {}; (S.paper[req] = S.paper[req] || []).push({ id, at: new Date().toISOString(), by: S.me.name || '' });
      save(); render(); if (ui.paperBack) { ui.sheet = ui.paperBack; ui.paperBack = null; renderSheet(); } setTimeout(() => syncPhotos(true), 1200);
    } finally { loader(false); } }; img.onerror = () => { loader(false); toast('Could not read this image.'); }; img.src = fr.result; };
    fr.readAsDataURL(f); return;
  }
  if (el.id === 'photoIn') {
    const f = el.files[0]; el.value = ''; if (!f) return;
    const img = new Image(); const fr = new FileReader();
    fr.onload = () => { img.onload = () => { ui.sheet = { kind: 'crop', img, src: fr.result, zoom: 1, x: 0, y: 0 }; renderSheet(); }; img.src = fr.result; };
    fr.readAsDataURL(f); return;
  }
  if (el.id === 'fileIn') {
    loader(true, 'Reading your file');
    const f = el.files[0]; el.value = ''; if (!f || !ui.upload) { loader(false); return; }
    if (!window.XLSX) { loader(false); ui.upload.error = 'Excel tools not loaded yet. Check internet and try again.'; renderSheet(); return; }
    try {
      const wb = await readWorkbook(f); ui.upload.wb = wb;
      const r = ui.upload.kind === 'stock' ? parseStock(wb) : parseRequests(wb, ui.upload.kind);
      if (r.error) ui.upload.error = r.error; else ui.upload.result = r;
    } catch (e) { ui.upload.error = 'Could not read this file. Use .xlsx or .csv.'; }
    loader(false); renderSheet(); return;
  }
  if (el.dataset.sort) { ui.sort[el.dataset.sort] = el.value; render(); return; }
  if (el.dataset.rp) { later(() => renderSheet()); return; }
  if (el.dataset.ms && el.dataset.ms.endsWith('|count')) { later(() => { const k = focusKey(document.activeElement); renderSheet(); refocus(k); }); return; }
  if (el.dataset.bq || el.dataset.bg || el.dataset.corr != null) { later(() => { const k = focusKey(document.activeElement); renderSheet(); refocus(k); }); return; }
  if (el.dataset.cnt != null || el.dataset.var || el.dataset.expdays) { later(() => { const k = focusKey(document.activeElement), y = window.scrollY; render(); window.scrollTo(0, y); refocus(k); }); return; }
  if (el.dataset.flt) { const [k, key] = el.dataset.flt.split('|'); const f = fltGet(k); f[key] = el.value; if ((k === 'done' || k === 'reg') && !f.rd && !f.id) f.id = today(); if (k === 'reg' && key === 'id' && el.value) ui.reg.date = el.value; render(); return; }
  if (el.dataset.in === 'sRd') { ui.search.rd = el.value; render(); return; }
  if (el.dataset.in === 'doneDate') { ui.doneDate = el.value || today(); render(); return; }
  if (el.dataset.in === 'regDate') { ui.reg.date = el.value || today(); render(); if (ui.sheet && ui.sheet.kind === 'export') renderSheet(); return; }
  if (el.dataset.in === 'sFrom') { ui.search.from = el.value; render(); return; }
  if (el.dataset.in === 'sTo') { ui.search.to = el.value; render(); return; }
  if (el.dataset.in === 'sStore') { ui.search.store = el.value; render(); return; }
  if (el.dataset.set) { const [o, k] = el.dataset.set.split('.'); S[o][k] = el.value.trim(); save(true); return; }
  if (el.dataset.storeRcv) { const s = el.dataset.storeRcv; S.stores[s].rcv = el.value.toUpperCase().replace(/[^A-Z0-9]/g, ''); save(); later(() => { const k = focusKey(document.activeElement); render(); refocus(k); }); return; }
  if (el.dataset.storeName) { const s = el.dataset.storeName; S.stores[s].rname = el.value.trim(); S.rnames = S.rnames || {}; if (S.stores[s].rcv) S.rnames[S.stores[s].rcv] = el.value.trim(); save(); return; }
  if (el.dataset.it && el.dataset.it.endsWith('|code')) { const i = +el.dataset.it.split('|')[0]; fillItemMeta(ui.form.items[i]); later(() => { const k = focusKey(document.activeElement); renderSheet(); refocus(k); }); return; }
  if (el.dataset.f === 'rcv' || el.dataset.f === 'by') { const nm = rname(el.value.toUpperCase().replace(/[^A-Z0-9]/g, '')); const key = el.dataset.f === 'rcv' ? 'rname' : 'byName'; if (nm && !ui.form[key]) { ui.form[key] = nm; later(() => { const k = focusKey(document.activeElement); renderSheet(); refocus(k); }); } }
});

function doImport() {
  const u = ui.upload, r = u.result;
  if (u.kind === 'stock' && u.diff && u.stockMode === 'update' && Object.keys(S.stock).length) {
    const D = u.diff; D.code.concat(D.name).forEach(x => { if (S.stock[x.code]) { S.stock[x.code].qty = x.to; if (S.stock[x.code].raw == null && (u.result.stock[x.fileCode] || {}).raw != null && x.how === 'code') S.stock[x.code].raw = u.result.stock[x.fileCode].raw; } if (S.stockEdits) delete S.stockEdits[x.code]; });
    if (u.addNew) D.fresh.forEach(x => { if (!/^#NOCODE/.test(x.code)) S.stock[x.code] = Object.assign({}, x.v); });
    S.stockAt = new Date().toISOString(); S.stockSrc = u.auto ? 'auto' : 'file';
    S.stockLog = (S.stockLog || []).concat([{ at: S.stockAt, src: S.stockSrc, mode: 'update', n: D.code.length + D.name.length, up: D.up.length, down: D.down.length, added: u.addNew ? D.fresh.length : 0, by: S.me.name || '' }]).slice(-60);
    save(); ui.upload = null; ui.sheet = null; renderSheet(); render(); toast('Closing updated for ' + (D.code.length + D.name.length) + ' items' + (u.addNew && D.fresh.length ? ', ' + D.fresh.length + ' added' : '') + '. Everything re-planned.'); return; }
  if (u.kind === 'stock' && r.noCode) { toast('This report has no Item Codes, so it cannot replace your stock.'); return; }
  if (u.kind === 'stock') { S.stock = r.stock; S.stockEdits = {}; S.stockAt = new Date().toISOString(); S.stockSrc = u.auto ? 'auto' : 'file'; S.stockLog = (S.stockLog || []).concat([{ at: S.stockAt, src: S.stockSrc, n: r.count, by: S.me.name || '' }]).slice(-60); save(); toast('Stock replaced: ' + r.count + ' items. Everything re-planned.'); }
  else {
    r.rows.forEach(x => {
      S.lines.push({ fromFile: true, id: nid(), req: x.req, store: x.store, date: x.date, code: x.code, qty: x.qty, rcv: x.rcv, slip: x.slip || '', src: x.src, earlier: x.earlier || '', status: 'waiting', issued: [] });
      if (!S.stores[x.store]) S.stores[x.store] = { rcv: '', rname: '' };
    });
    save(); toast(r.rows.length + ' articles imported.');
  }
  ui.upload = null; ui.sheet = null; renderSheet(); render();
}

/* ---------------- start ---------------- */
render();
setTimeout(() => { const b = document.getElementById('boot'); if (b) { b.style.transition = 'opacity .35s'; b.style.opacity = '0'; setTimeout(() => b.remove(), 400); } }, 650);
if (S.sync.url && S.sync.auto && (S.sync.dirty || !S.sync.at)) setTimeout(() => syncNow(true), 5000);
if (Date.now() - (S.lastUpdateCheck || 0) > 12 * 3600e3) setTimeout(() => checkUpdate(false), 3000);
